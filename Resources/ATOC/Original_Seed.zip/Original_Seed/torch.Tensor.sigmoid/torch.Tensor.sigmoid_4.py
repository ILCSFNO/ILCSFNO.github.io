import torch
import numpy as np
import random

# Generate random input data
random_input_data = torch.randn(10, 10)

# Generate random labels
random_labels = torch.randn(10, 1)

# Call the API torch.Tensor.sigmoid
output = random_input_data.sigmoid()

print("Input Data:")
print(random_input_data)
print("\nOutput:")
print(output)
print("\nLabels:")
print(random_labels)