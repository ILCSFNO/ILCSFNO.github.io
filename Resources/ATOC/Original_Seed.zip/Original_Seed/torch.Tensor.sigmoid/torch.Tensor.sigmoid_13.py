import torch
import numpy as np
import random

def generate_random_data():
    # Generate random input data
    inputs = np.random.rand(10, 5)
    targets = np.random.rand(10, 5)
    return inputs, targets

def main():
    # Generate random input data
    inputs, targets = generate_random_data()

    # Convert inputs and targets to PyTorch tensors
    inputs = torch.from_numpy(inputs).float()
    targets = torch.from_numpy(targets).float()

    # Call the API torch.Tensor.sigmoid
    outputs = inputs.sigmoid()

    # Print the outputs
    print(outputs)

if __name__ == "__main__":
    main()