import torch
import numpy as np
import random

def generate_input_data(size):
    """Generate random input data"""
    inputs = np.random.rand(size, 10)
    labels = np.random.rand(size)
    return inputs, labels

def main():
    size = 100
    inputs, labels = generate_input_data(size)

    # Convert input and label to PyTorch tensors
    inputs = torch.from_numpy(inputs)
    labels = torch.from_numpy(labels)

    # Apply sigmoid function to the input data
    sigmoid_inputs = inputs.sigmoid()

    # Print the result
    print(sigmoid_inputs)

if __name__ == "__main__":
    main()