import torch
import torch.nn as nn
import torch.utils.data as data
import numpy as np
import random

# Generate input data
def generate_input_data(size):
    inputs = np.random.rand(size, 5)
    labels = np.random.rand(size)
    return inputs, labels

# Generate random data for testing
input_size = 10
inputs, labels = generate_input_data(input_size)

# Create a PyTorch tensor from the input data
input_tensor = torch.tensor(inputs, dtype=torch.float32)

# Create a PyTorch tensor from the labels
label_tensor = torch.tensor(labels, dtype=torch.float32)

# Apply sigmoid function to the input tensor
output = input_tensor.sigmoid()

# Print the output
print(output)