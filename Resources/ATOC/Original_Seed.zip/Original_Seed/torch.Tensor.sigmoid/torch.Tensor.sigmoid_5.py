import torch
import numpy as np
import random

def generate_input_data():
    # Generate random input data
    input_data = np.random.rand(10, 10)
    return torch.from_numpy(input_data)

def main():
    # Generate input data
    input_data = generate_input_data()

    # Call the API torch.Tensor.sigmoid
    output = input_data.sigmoid()

    # Print the output
    print(output)

if __name__ == "__main__":
    main()