import torch
import numpy as np
import random

def generate_random_data():
    # Generate random data for demonstration
    data = np.random.rand(10, 10)
    tensor = torch.from_numpy(data)
    return tensor

def main():
    tensor = generate_random_data()
    result = tensor.sigmoid()
    print(result)

if __name__ == "__main__":
    main()