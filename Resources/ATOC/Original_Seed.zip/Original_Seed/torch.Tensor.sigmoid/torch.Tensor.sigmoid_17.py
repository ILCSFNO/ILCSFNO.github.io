import torch
import numpy as np
import random

def generate_input_data():
    # Generate random data for input and labels
    input_data = np.random.rand(10, 5)
    labels = np.random.randint(0, 2, size=(10, 5))
    return torch.from_numpy(input_data), torch.from_numpy(labels)

def main():
    input_data, labels = generate_input_data()

    # Call the API torch.Tensor.sigmoid
    sigmoid_output = input_data.sigmoid()

    # Print the results
    print("Input Data:")
    print(input_data)
    print("\nSigmoid Output:")
    print(sigmoid_output)

if __name__ == "__main__":
    main()