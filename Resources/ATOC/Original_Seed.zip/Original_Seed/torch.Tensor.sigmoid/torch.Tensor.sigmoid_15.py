import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

# Generate 5 random tensors with shape (1, 10)
input_data = torch.randn(5, 10)

# Call the API torch.Tensor.sigmoid
output_data = input_data.sigmoid()

# Print the output data
print(output_data)