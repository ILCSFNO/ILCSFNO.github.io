import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(1, 1000))
random.seed(random.randint(1, 1000))

# Generate a tensor with random values
input_tensor = torch.tensor(np.random.rand(1, 5))

# Apply sigmoid function to the tensor
output_tensor = input_tensor.sigmoid()

# Print the output
print(output_tensor)