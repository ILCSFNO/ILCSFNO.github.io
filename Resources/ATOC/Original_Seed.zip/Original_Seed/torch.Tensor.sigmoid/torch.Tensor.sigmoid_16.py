import torch
import numpy as np

# Generate input data
np.random.seed(0)
input_data = torch.tensor(np.random.rand(10, 10))

# Call the API torch.Tensor.sigmoid
output = input_data.sigmoid()

# Print the output
print(output)