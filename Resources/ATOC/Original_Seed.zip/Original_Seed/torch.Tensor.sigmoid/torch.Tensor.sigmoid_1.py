import torch
import numpy as np
import random

def generate_input_data(size):
    """
    Generate random input data for the sigmoid function.
    """
    return np.random.rand(size)

def main():
    # Generate random input data
    input_data = generate_input_data(10)

    # Convert input data to PyTorch tensor
    input_tensor = torch.tensor(input_data)

    # Apply sigmoid function to the input tensor
    output_tensor = input_tensor.sigmoid()

    # Print the output tensor
    print(output_tensor)

if __name__ == "__main__":
    main()