import torch
import numpy as np
import random

def generate_random_data():
    # Generate random input data
    input_data = torch.randn(1, 10)
    labels = torch.randn(1, 10)

    return input_data, labels

def main():
    input_data, labels = generate_random_data()

    # Apply sigmoid function to input data
    output = input_data.sigmoid()

    print("Input Data:", input_data)
    print("Output:", output)
    print("Labels:", labels)

if __name__ == "__main__":
    main()