import torch
import numpy as np
import random

# Generate random input data
random_data = np.random.rand(10, 5)

# Convert input data to torch tensor
input_tensor = torch.from_numpy(random_data)

# Call the API torch.Tensor.sigmoid
output_tensor = input_tensor.sigmoid()

# Print the output tensor
print(output_tensor)