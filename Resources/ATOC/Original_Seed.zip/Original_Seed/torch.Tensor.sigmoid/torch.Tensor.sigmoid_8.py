import torch
import numpy as np
import random

def generate_random_data():
    # Generate random data for input and labels
    input_data = torch.tensor(np.random.rand(10, 5))
    labels = torch.tensor(np.random.randint(0, 2, 10))

    return input_data, labels

def main():
    # Generate random data
    input_data, labels = generate_random_data()

    # Apply sigmoid function to input data
    output = input_data.sigmoid()

    # Print the output
    print(output)

if __name__ == "__main__":
    main()