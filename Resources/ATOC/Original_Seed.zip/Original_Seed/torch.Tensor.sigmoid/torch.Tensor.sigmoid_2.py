import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
def generate_input_data():
    return torch.randn(1, 1)

# Generate random labels
def generate_labels(input_data):
    return (input_data > 0).float()

# Generate random input data and labels
input_data = generate_input_data()
labels = generate_labels(input_data)

# Define a simple neural network model
model = nn.Sequential(
    nn.Linear(1, 1),
    nn.Sigmoid()
)

# Initialize the model, loss function and optimizer
criterion = nn.BCELoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

# Train the model
for epoch in range(1000):
    # Forward pass
    outputs = model(input_data)
    loss = criterion(outputs, labels)

    # Backward and optimize
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # Print loss at each 100 epochs
    if epoch % 100 == 0:
        print(f'Epoch {epoch+1}, Loss: {loss.item()}')

# Use the trained model to make predictions
predictions = model(input_data)

# Apply the sigmoid func