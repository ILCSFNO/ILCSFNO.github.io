import torch
import numpy as np
import random

# Generate random input data
random.seed(42)
df = random.randint(1, 10)
input_data = np.random.rand(5, 5)

# Call the API torch.is_storage
print(torch.is_storage(input_data))