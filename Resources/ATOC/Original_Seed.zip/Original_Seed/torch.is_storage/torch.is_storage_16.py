import torch
import torch.multiprocessing as mp
import random

def generate_random_data():
    return torch.randn(1000)

def test_torch_is_storage():
    input_data = generate_random_data()
    input_data_torch = torch.tensor(input_data)
    print(torch.is_storage(input_data_torch))

if __name__ == "__main__":
    test_torch_is_storage()