import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)
input_data = np.random.rand(10, 5)

# Call the API torch.is_storage
def is_storage(obj):
    return torch.is_storage(obj)

# Test the API
print([is_storage(x) for x in [input_data, torch.tensor(input_data), torch.tensor(input_data, dtype=torch.float32)]])