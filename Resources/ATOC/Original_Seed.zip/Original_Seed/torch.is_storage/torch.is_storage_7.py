import torch
import torch.randn
import torch.randn_like

# Task 1: Import torch
print("Task 1: Import torch")

# Task 2: Generate input data with torch.randn
input_data = torch.randn(10, 10)

# Task 3: Call the API torch.is_storage
print(torch.is_storage(input_data))