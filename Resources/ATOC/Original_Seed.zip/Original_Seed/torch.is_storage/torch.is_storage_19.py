import torch
import numpy as np
import random

# Generate random input data
np.random.seed(42)
random.seed(42)
torch.manual_seed(42)

input_data = torch.randn(10, 5)

# Task 3: Call the API torch.is_storage
def check_storage(obj):
    return torch.is_storage(obj)

print(check_storage(input_data))