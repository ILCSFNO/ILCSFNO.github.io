import torch
import numpy as np
import random

# Generate random input data
random.seed(42)
input_data = np.random.rand(10, 3)

# Task 1: Import torch
print("Task 1: Import torch")
import torch

# Task 2: Generate random input data
print("Task 2: Generate random input data")
random.seed(42)
input_data = np.random.rand(10, 3)

# Task 3: Call the API torch.is_storage
print("Task 3: Call the API torch.is_storage")
for data in input_data:
    print(torch.is_storage(data))