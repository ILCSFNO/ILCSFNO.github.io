import torch
import torch.random
import torch.nn as nn
import torch.optim as optim
import numpy as np

# Generate random input data
input_data = torch.randn(100, 5)

# Define a model
class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.fc1 = nn.Linear(5, 10)
        self.fc2 = nn.Linear(10, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = Model()

# Define a loss function and optimizer
criterion = nn.MSELoss()
optimizer = optim.SGD(model.parameters(), lr=0.01)

# Call the API torch.is_storage
print(torch.is_storage(model))
print(torch.is_storage(input_data))