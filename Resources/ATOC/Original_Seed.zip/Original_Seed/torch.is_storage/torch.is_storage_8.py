import torch
import torch.manual_seed
import torch.distributions.chi2 as chi2

torch.manual_seed(1234)

def generate_random_data():
    return torch.randn(1000)

data = generate_random_data()

def test_torch_is_storage():
    print(torch.is_storage(data))

test_torch_is_storage()