import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(10, 5)

# Set random seed for reproducibility
random.seed(42)
torch.manual_seed(42)

# Task 1: Import torch
# No need to import torch as it's already imported

# Task 2: Generate input data with any function
# No need to generate input data as it's already done

# Task 3: Call the API torch.is_storage
def check_storage(obj):
    return isinstance(obj, torch._storage.MapStorage)

# Test the function
print(check_storage(input_data))  # Should print: True

# Randomly select an element from the input data
random_element = input_data[random.randint(0, 9), random.randint(0, 4)]

# Check if the random element is stored in the device (GPU or CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(check_storage(random_element.to(device)))  # Should print: True