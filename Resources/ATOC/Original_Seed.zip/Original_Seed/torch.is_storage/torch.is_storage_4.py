import torch
import torch.random
import numpy as np

torch.manual_seed(42)
np.random.seed(42)

# Generate random input data
x = torch.randn(10, 3)

# Call the API torch.is_storage
print(torch.is_storage(x))