import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(10, 3)

# Generate random input tensor
input_tensor = torch.from_numpy(input_data).float()

# Task 3: Call the API torch.is_storage
print(torch.is_storage(input_tensor))