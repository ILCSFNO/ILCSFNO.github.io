import torch
import torch.distributions
import numpy as np
import random

def generate_random_data():
    return torch.randn(1000)

def main():
    torch.manual_seed(random.randint(0, 1000))
    np.random.seed(random.randint(0, 1000))
    input_data = generate_random_data()

    # Call the API torch.is_storage
    print(torch.is_storage(input_data))

if __name__ == "__main__":
    main()