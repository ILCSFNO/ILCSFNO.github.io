import torch
import numpy as np

# Generate random input data
input_data = np.random.rand(10, 10)

# Generate random input tensor
input_tensor = torch.from_numpy(input_data)

# Call the API torch.is_storage
def is_storage(obj):
    return isinstance(obj, torch._storage.Storage)

print(is_storage(input_tensor))