import torch
import random
import numpy as np

# Generate random input data
random_input = np.random.rand(10, 10)

# Task 1: Import torch
# No code needed as it's already done

# Task 2: Generate input data with any function I like
# No code needed as it's already done

# Task 3: Call the API torch.is_storage
def task_3():
    # Task 3: Call the API torch.is_storage
    torch.is_storage(random_input)

task_3()