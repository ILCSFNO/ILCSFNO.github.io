import torch
import random
import numpy as np

# Generate random input data
random_input = np.random.rand(10)

# Call the API torch.is_storage
def test_storage():
    torch.is_storage(random_input)

test_storage()