import torch
import torch.random
import numpy as np

def generate_random_input():
    return torch.randn(10)

input_data = generate_random_input()
print(input_data)

def test_torch_is_storage():
    tensor = torch.tensor([1, 2, 3], device=torch.device('cpu'))
    print(torch.is_storage(tensor))

test_torch_is_storage()