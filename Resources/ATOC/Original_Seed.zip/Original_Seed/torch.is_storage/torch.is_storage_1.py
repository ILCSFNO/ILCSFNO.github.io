import torch
import numpy as np

# Generate random input data
np.random.seed(42)
random_data = np.random.rand(10, 10)

# Call the API torch.is_storage
def is_storage(obj):
    return torch.is_storage(obj)

# Test the function
print([is_storage(x) for x in [torch.tensor(random_data), random_data, random_data.tolist()]])