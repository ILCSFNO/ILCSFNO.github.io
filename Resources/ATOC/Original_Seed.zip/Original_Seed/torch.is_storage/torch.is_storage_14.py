import torch
import torch.random

# Generate random input data
input_data = torch.randn(100, 10)

# Task 1: Import torch
print("Task 1: Import torch")
import torch

# Task 2: Generate input data
print("Task 2: Generate input data")
import torch.random

input_data = torch.randn(100, 10)

# Task 3: Call the API torch.is_storage
print("Task 3: Call the API torch.is_storage")
print(torch.is_storage(input_data))