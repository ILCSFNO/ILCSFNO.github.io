import torch
import torch.nn.functional as F
import numpy as np
import random

def generate_input_data():
    anchor = torch.randn(1, 3, 224, 224)
    positive = torch.randn(1, 3, 224, 224)
    negative = torch.randn(1, 3, 224, 224)
    return anchor, positive, negative

def generate_triplet_loss(anchor, positive, negative):
    distance_function = lambda x, y: torch.norm(x - y, dim=[2, 3])
    loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, distance_function=distance_function, margin=1.0, swap=False, reduction='mean')
    return loss.item()

# Generate input data
anchor, positive, negative = generate_input_data()

# Generate triplet loss
loss = generate_triplet_loss(anchor, positive, negative)
print(loss)