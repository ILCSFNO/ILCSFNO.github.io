import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
def generate_input_data():
    anchor = torch.randn(1, 128, 128, 3)
    positive = torch.randn(1, 128, 128, 3)
    negative = torch.randn(1, 128, 128, 3)
    return anchor, positive, negative

# Generate input data
anchor, positive, negative = generate_input_data()

# Define a custom distance function
def custom_distance_function(x, y):
    return torch.norm(x - y, dim=1, keepdim=True)

# Set the distance function
distance_function = custom_distance_function

# Set the margin
margin = 1.0

# Set the reduction
reduction ='mean'

# Calculate the triplet margin loss
loss = F.triplet_margin_with_distance_loss(anchor, positive, negative,
                                         distance_function=distance_function,
                                         margin=margin,
                                         swap=False,
                                         reduction=reduction)

print(loss)