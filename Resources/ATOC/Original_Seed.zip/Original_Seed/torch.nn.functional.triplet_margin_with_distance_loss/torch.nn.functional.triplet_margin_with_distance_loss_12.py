import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(1, 128, 128)
positive = torch.randn(1, 128, 128)
negative = torch.randn(1, 128, 128)

# Generate random distance between anchor and positive
distance = torch.randn(1).item()

# Generate random margin
margin = torch.tensor(1.0)

# Generate random swap flag
swap = torch.tensor(False)

# Generate random reduction flag
reduction = torch.tensor('mean')

# Compute triplet margin loss
loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, distance_function=torch.nn.MSELoss(), margin=margin, swap=swap, reduction=reduction)

print(loss)