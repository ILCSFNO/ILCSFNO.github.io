import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
def generate_input_data():
    anchor = torch.randn(10, 128)
    positive = torch.randn(10, 128)
    negative = torch.randn(10, 128)
    return anchor, positive, negative

# Generate input data
anchor, positive, negative = generate_input_data()

# Define a custom distance function
def custom_distance(x, y):
    return torch.norm(x - y, p=1)

# Set the margin and distance function
margin = 1.0
distance_function = custom_distance

# Set the reduction to'mean'
reduction ='mean'

# Call the API
loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, distance_function=distance_function, margin=margin, reduction=reduction)

print(loss)