import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(1, 128, 128, dtype=torch.float32)
positive = torch.randn(1, 128, 128, dtype=torch.float32)
negative = torch.randn(1, 128, 128, dtype=torch.float32)

distance_function = lambda x, y: torch.norm(x - y, dim=1, keepdim=True)

# Define the triplet margin loss function
def triplet_margin_loss(anchor, positive, negative, distance_function, margin=1.0, swap=False, reduction='mean'):
    anchor_dist = distance_function(anchor, positive)
    anchor_dist = torch.clamp(anchor_dist - margin, min=0.0)
    anchor_dist = torch.mean(anchor_dist, dim=(1, 2), keepdim=True)

    negative_dist = distance_function(anchor, negative)
    negative_dist = torch.clamp(negative_dist - margin, min=0.0)
    negative_dist = torch.mean(negative_dist, dim=(1, 2), keepdim=True)

    loss = an