import torch
import torch.nn.functional as F
import numpy as np

# Generate random input data
np.random.seed(0)
anchor = torch.randn(1, 128, requires_grad=True)
positive = torch.randn(1, 128, requires_grad=True)
negative = torch.randn(1, 128, requires_grad=True)

# Generate random labels
labels = torch.ones(1, 1)

# Define distance function
distance_function = lambda x, y: torch.norm(x - y, dim=1, keepdim=True)

# Define triplet margin loss function
def triplet_margin_loss(anchor, positive, negative, margin=1.0):
    distance = distance_function(anchor, positive)
    distance = torch.cat((distance, distance_function(anchor, negative)), dim=1)
    loss = F.margin_ranking_loss(distance, labels, margin=margin)
    return loss

# Calculate triplet margin loss
loss = triplet_margin_loss(anchor, positive, negative)

# Print the loss
print(loss)