import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
def generate_input_data():
    anchor = torch.randn(1, 3, 224, 224)
    positive = torch.randn(1, 3, 224, 224)
    negative = torch.randn(1, 3, 224, 224)
    return anchor, positive, negative

# Generate random labels
def generate_labels(anchor, positive, negative):
    return torch.tensor([0, 1, -1])

# Main function
def main():
    anchor, positive, negative = generate_input_data()
    labels = generate_labels(anchor, positive, negative)

    # Compute the triplet margin loss
    loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, distance_function=lambda x, y: (x - y).pow(2).sum(dim=(1, 2, 3)).sqrt(), margin=1.0, swap=False, reduction='mean')

    print(loss)

if __name__ == "__main__":
    main()