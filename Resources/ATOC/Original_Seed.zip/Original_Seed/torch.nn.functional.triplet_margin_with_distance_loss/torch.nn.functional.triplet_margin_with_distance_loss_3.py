import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(100, 128)  # 100 anchor embeddings, 128 dimensions
positive = torch.randn(100, 128)  # 100 positive anchor embeddings, 128 dimensions
negative = torch.randn(100, 128)  # 100 negative anchor embeddings, 128 dimensions

# Generate random labels
labels = torch.randint(0, 3, (100,))

# Define a custom distance function
def custom_distance(x, y):
    return torch.mean((x - y) ** 2)

# Create a TripletMarginWithDistanceLoss instance
loss_fn = F.triplet_margin_with_distance_loss(margin=1.0)

# Call the API
loss = loss_fn(anchor, positive, negative, distance_function=custom_distance)
print(loss)