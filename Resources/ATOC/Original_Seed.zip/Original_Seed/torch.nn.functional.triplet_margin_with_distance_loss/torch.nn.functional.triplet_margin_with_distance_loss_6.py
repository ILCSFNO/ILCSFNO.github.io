import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(10, 128, requires_grad=True)
positive = torch.randn(10, 128, requires_grad=True)
negative = torch.randn(10, 128, requires_grad=True)

# Generate random labels
labels = torch.randint(0, 3, (10,))

# Create a custom distance function
def custom_distance(x, y):
    return torch.norm(x - y, p=2, dim=1)

# Define the loss function
def triplet_margin_with_distance_loss(anchor, positive, negative, distance_function=None, margin=1.0, swap=False, reduction='mean'):
    if distance_function is None:
        distance_function = custom_distance
    
    anchor_dist = distance_function(anchor, positive)
    anchor_neg_dist = distance_function(anchor, negative)
    
    # Compute the loss for positive pairs
    loss_positive = F.relu(margin - anchor_dist + anchor_neg_dist)
    
    # Compute the loss for negative pairs
    loss_negative = F.relu(anchor_dist - (margin + anchor_neg_