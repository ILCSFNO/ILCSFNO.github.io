import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

# Generate random anchor tensor
anchor = torch.randn(32, 128, 128, dtype=torch.float32)

# Generate random positive tensor
positive = torch.randn(32, 128, 128, dtype=torch.float32)

# Generate random negative tensor
negative = torch.randn(32, 128, 128, dtype=torch.float32)

# Generate random distance tensor
distance = torch.randn(32, 128, 128, dtype=torch.float32)

# Generate random margin tensor
margin = torch.tensor(1.0, dtype=torch.float32)

# Generate random swap tensor
swap = torch.tensor(False, dtype=torch.bool)

# Compute the triplet margin loss
loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, 
                                        distance_function=torch.nn.MSELoss(), 
                                        margin=margin, swap=swap)

print(loss)