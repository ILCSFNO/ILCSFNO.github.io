import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

# Generate random anchor tensor
anchor = torch.randn(32, 128, 128, 3)

# Generate random positive tensor
positive = torch.randn(32, 128, 128, 3)

# Generate random negative tensor
negative = torch.randn(32, 128, 128, 3)

# Generate random distance function tensor
distance_function = torch.randn(32, 128, 128, 3)

# Generate random margin tensor
margin = torch.tensor(1.0)

# Generate random swap tensor
swap = torch.tensor(False)

# Generate random reduction tensor
reduction = torch.tensor('mean')

# Call the API torch.nn.functional.triplet_margin_with_distance_loss
loss = F.triplet_margin_with_distance_loss(anchor, positive, negative,
                                          distance_function=distance_function,
                                          margin=margin,
                                          swap=swap,
                                          reduction=reduction)
print(loss)