import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(1, 128, 128, 3).float()
positive = torch.randn(1, 128, 128, 3).float()
negative = torch.randn(1, 128, 128, 3).float()

# Generate random labels
label = torch.tensor([[1], [1], [0]])

# Define a custom distance function
def custom_distance(x, y):
    return torch.norm(x - y, dim=1, keepdim=True)

# Call the API
distance_function = custom_distance
margin = 1.0
loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, distance_function=distance_function, margin=margin, swap=False, reduction='mean')

print(loss)