import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(2, 3)
positive = torch.randn(2, 3)
negative = torch.randn(2, 3)

# Generate random labels
labels = torch.randint(0, 3, (2,))

# Define a custom distance function
def custom_distance(x, y):
    return torch.norm(x - y, dim=1)

distance_function = custom_distance

# Define the triplet margin loss function
def triplet_margin_loss(anchor, positive, negative, distance_function=distance_function, margin=1.0, swap=False, reduction='mean'):
    # Calculate the distances between anchor and positive/negative pairs
    anchor_pos = distance_function(anchor, positive)
    anchor_neg = distance_function(anchor, negative)

    # Calculate the losses for each anchor
    anchor_loss_pos = F.relu(margin - anchor_pos)
    anchor_loss_neg = F.relu(anchor_pos - margin)

    # Calculate the total loss
    total_loss = (anchor_loss_pos + anchor_loss_neg) / 2

    