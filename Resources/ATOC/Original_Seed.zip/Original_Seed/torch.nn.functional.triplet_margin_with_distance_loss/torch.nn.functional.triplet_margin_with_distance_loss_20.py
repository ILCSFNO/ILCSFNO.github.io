import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(1, 128, 128, dtype=torch.float32)
positive = torch.randn(1, 128, 128, dtype=torch.float32)
negative = torch.randn(1, 128, 128, dtype=torch.float32)

# Generate random distances
distance = torch.randn(1, 128, 128, dtype=torch.float32)

# Define the loss function
def triplet_margin_loss(anchor, positive, negative, distance, margin):
    loss = F.triplet_margin_with_distance_loss(anchor, positive, negative, distance=distance, margin=margin)
    return loss

# Call the API
loss = triplet_margin_loss(anchor, positive, negative, distance, margin=1.0)

# Print the loss
print(loss)