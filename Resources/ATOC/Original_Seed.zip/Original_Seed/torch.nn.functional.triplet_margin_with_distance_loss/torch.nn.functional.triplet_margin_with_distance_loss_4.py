import torch
import torch.nn.functional as F
import numpy as np

# Generate input data
np.random.seed(0)
anchor = torch.randn(1, 128, requires_grad=True)
positive = torch.randn(1, 128, requires_grad=True)
negative = torch.randn(1, 128, requires_grad=True)

# Generate random distances
distance = torch.randn(1, 128, 128, requires_grad=True)

# Define the loss function
def triplet_margin_loss(anchor, positive, negative, distance, margin=1.0):
    anchor_distance = F.pairwise_distance(anchor, distance)
    positive_distance = F.pairwise_distance(anchor, positive)
    negative_distance = F.pairwise_distance(anchor, negative)
    
    loss = F.margin_triplet_loss(anchor, positive, negative, margin=margin, distance=anchor_distance)
    return loss

# Call the API
loss = triplet_margin_loss(anchor, positive, negative, distance)
print(loss)