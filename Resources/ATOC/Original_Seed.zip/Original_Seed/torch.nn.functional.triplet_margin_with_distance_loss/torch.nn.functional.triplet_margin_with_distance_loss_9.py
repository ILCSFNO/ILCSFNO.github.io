import torch
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

anchor = torch.randn(4, 128)  # 4 anchors, 128 features each
positive = torch.randn(4, 128)  # 4 positive pairs, 128 features each
negative = torch.randn(4, 128)  # 4 negative pairs, 128 features each

distance_function = lambda x, y: torch.norm(x - y, dim=1)

def generate_triplet_data():
    anchor = torch.randn(4, 128)
    positive = torch.randn(4, 128)
    negative = torch.randn(4, 128)
    return anchor, positive, negative

def generate_random_triplet_data():
    anchor, positive, negative = generate_triplet_data()
    for i in range(4):
        positive[i] += np.random.normal(0, 0.1, 128)
        negative[i] += np.random.normal(0, 0.1, 128)
    return anchor, positive, negative

anchor, positive, negative = generate_random_