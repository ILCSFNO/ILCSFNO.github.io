import torch

def generate_input_data():
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import random

    # Generate random data
    random_data = np.random.rand(100, 5)

    # Convert to pandas DataFrame
    df = pd.DataFrame(random_data, columns=[f'Feature {i}' for i in range(5)])

    # Create a plot
    plt.figure(figsize=(10, 5))
    for i in range(5):
        plt.plot(df[f'Feature {i}'], label=f'Feature {i}')
    plt.legend()
    plt.show()

    return torch.tensor(df.values)

# Call the API
input_data = generate_input_data()

# Call the API torch.eye
eye_tensor = torch.eye(5)

# Print the output
print(input_data)
print(eye_tensor)