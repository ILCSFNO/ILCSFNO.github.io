import torch

# Generate random input data
import random
import numpy as np
input_data = np.random.rand(3, 3)

# Call the API torch.eye
output = torch.eye(3, dtype=torch.float32, device=torch.device("cpu"))
print(output)