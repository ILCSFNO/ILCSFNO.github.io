import torch
import random

def generate_random_data():
    n = random.randint(1, 10)
    m = random.randint(1, n)
    return n, m

def main():
    n, m = generate_random_data()
    print(f"Input Data: n={n}, m={m}")
    eye_tensor = torch.eye(n, m)
    print(f"torch.eye({n}, {m}): {eye_tensor}")

if __name__ == "__main__":
    main()