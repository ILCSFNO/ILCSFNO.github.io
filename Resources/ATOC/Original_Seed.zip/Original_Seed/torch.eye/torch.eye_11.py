import torch

# Generate random input data
import random
import numpy as np
input_data = np.random.randint(0, 2, (10, 10))

# Generate input data with any function
def generate_input_data():
    return np.random.randint(0, 2, (10, 10))

# Call the API torch.eye
torch_eye = torch.eye(5, 5)
print(input_data)
print(torch_eye)