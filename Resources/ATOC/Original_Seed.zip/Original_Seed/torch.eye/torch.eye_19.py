import torch

# Generate random input data
import numpy as np
input_data = np.random.rand(3, 3)

# Generate a 2-D tensor with ones on the diagonal and zeros elsewhere
eye_tensor = torch.eye(3, device='cuda', requires_grad=False)
print(eye_tensor)