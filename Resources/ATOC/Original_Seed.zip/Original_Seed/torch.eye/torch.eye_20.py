import torch

def generate_input_data():
    # Generate a random 3x4 tensor
    return torch.randn(3, 4)

def main():
    # Generate input data
    input_data = generate_input_data()

    # Create a 3x3 identity matrix
    identity_matrix = torch.eye(3)

    # Print the input data and identity matrix
    print("Input Data:")
    print(input_data)
    print("\nIdentity Matrix:")
    print(identity_matrix)

if __name__ == "__main__":
    main()