import torch
import numpy as np
import random

def generate_random_data():
    n = random.randint(1, 10)
    m = random.randint(1, 10)
    data = np.random.rand(n, m)
    return torch.tensor(data, dtype=torch.float32)

def main():
    data = generate_random_data()
    eye = torch.eye(n=data.shape[0], m=data.shape[1])
    print(f"Input Data: {data}")
    print(f"Eye Tensor: {eye}")

if __name__ == "__main__":
    main()