import torch
import numpy as np

# Generate random input data
np.random.seed(0)
n = np.random.randint(1, 10)
m = np.random.randint(1, 10)
input_data = np.random.rand(1, n, m)

# Call the API torch.eye
eye_tensor = torch.eye(n, m=m, requires_grad=False, device='cpu')
print(input_data)
print(eye_tensor)