import torch

# Generate random input data
import random
import numpy as np

n = random.randint(1, 10)
m = random.randint(1, 10)

# Generate input data
input_data = {
    "n": n,
    "m": m
}

# Call the API torch.eye
torch_eye = torch.eye(n, m=m)

# Print the input data
print("Input Data:")
for key, value in input_data.items():
    print(f"{key}: {value}")

# Print the output of torch.eye
print("\nOutput of torch.eye:")
print(torch_eye)