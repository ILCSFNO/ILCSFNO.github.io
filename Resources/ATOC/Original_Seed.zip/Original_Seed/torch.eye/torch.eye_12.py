import torch
import numpy as np

# Generate random input data
np.random.seed(0)
torch.manual_seed(0)
n = np.random.randint(1, 11)
m = np.random.randint(1, 11)

# Generate input data with any function
x = np.random.rand(n, m)

# Call the API torch.eye
eye_tensor = torch.eye(n, m, dtype=torch.float32, device='cpu')

# Print the input data
print("Input Data:")
print(x)

# Print the output of torch.eye
print("\nOutput of torch.eye:")
print(eye_tensor)