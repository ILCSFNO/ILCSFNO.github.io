import torch

# Generate random input data
import numpy as np
import random
n = random.randint(1, 10)
m = random.randint(1, 10)
input_data = np.random.rand(n, m)

# Call the API torch.eye
output = torch.eye(n, m=m, device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu"), requires_grad=False)