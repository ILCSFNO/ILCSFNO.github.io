import torch

# Generate random input data
import numpy as np
import random

def generate_random_data():
    n = random.randint(1, 10)
    m = random.randint(1, 10)
    data = np.random.rand(n, m)
    return data

def main():
    data = generate_random_data()
    print("Input Data:")
    print(data)

    # Call the API torch.eye
    tensor = torch.eye(n=data.shape[0], m=data.shape[1], device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu"))
    print("\nOutput of torch.eye API:")
    print(tensor)

if __name__ == "__main__":
    main()