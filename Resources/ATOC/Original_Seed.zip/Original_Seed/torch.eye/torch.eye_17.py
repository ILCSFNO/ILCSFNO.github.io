import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
n = random.randint(1, 10)
m = random.randint(1, 10)
input_data = np.random.rand(n, m)

# Call the API torch.eye
output = torch.eye(n, m, device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu"))

# Print the output
print(output)
print(input_data)