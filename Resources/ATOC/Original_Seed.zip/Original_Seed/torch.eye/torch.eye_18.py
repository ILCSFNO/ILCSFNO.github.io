import torch
import numpy as np

# Generate input data
np.random.seed(0)
input_data = np.random.rand(3, 4)

# Call the API torch.eye
torch_eye = torch.eye(3)
print(input_data)
print(torch_eye)