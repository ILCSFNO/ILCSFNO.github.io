import torch

# Generate input data
import numpy as np
import random

def generate_input_data():
    n = random.randint(1, 10)
    m = random.randint(1, 10)
    input_data = np.random.rand(n, m)
    return input_data

# Call the API torch.eye
input_data = generate_input_data()
output = torch.eye(input_data.shape[0], input_data.shape[1])

# Print the output
print(output)