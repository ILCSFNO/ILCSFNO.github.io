import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = np.random.rand(3, 3)

# Call the API torch.eye
torch_eye = torch.eye(3)

# Print the result
print("Random Data:")
print(random_data)
print("\ntorch.eye(3):")
print(torch_eye)