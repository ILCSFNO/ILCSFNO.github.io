import torch
import random

# Generate random input data
input_data = random.randint(1, 100)

# Set the number of threads to 4
torch.set_num_threads(4)

# Test the set_num_threads function
try:
    # Run some torch code to test the set_num_threads function
    torch.randn(1000, 1000)
except RuntimeError as e:
    print(e)