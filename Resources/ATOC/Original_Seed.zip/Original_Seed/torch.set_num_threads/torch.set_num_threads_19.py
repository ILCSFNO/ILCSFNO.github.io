import torch
import random

def generate_input_data():
    # Generate random input data
    input_data = torch.randn(100, 5)
    return input_data

def main():
    # Generate input data
    input_data = generate_input_data()

    # Set the number of threads for intraop parallelism on CPU
    torch.set_num_threads(random.randint(1, 10))

    # Print the number of threads
    print(f"Number of threads set: {torch.get_num_threads()}")

if __name__ == "__main__":
    main()