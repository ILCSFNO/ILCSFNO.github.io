import torch
import random
import time

def generate_random_data():
    data = []
    for i in range(1000):
        x = random.random()
        y = random.random()
        data.append((x, y))
    return data

def main():
    # Generate random input data
    data = generate_random_data()
    
    # Set the number of threads
    torch.set_num_threads(random.randint(1, 10))
    
    # Measure the time taken
    start_time = time.time()
    for x, y in data:
        # Perform some computation
        pass
    end_time = time.time()
    print(f"Time taken: {end_time - start_time} seconds")

if __name__ == "__main__":
    main()