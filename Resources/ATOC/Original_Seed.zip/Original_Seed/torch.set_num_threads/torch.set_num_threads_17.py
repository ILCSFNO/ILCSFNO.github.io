import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))

# Generate random input data
input_data = np.random.rand(1000, 10)

# Set the number of threads
torch.set_num_threads(4)