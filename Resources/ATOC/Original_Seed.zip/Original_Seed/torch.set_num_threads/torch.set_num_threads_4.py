import torch
import numpy as np
import random
import time

# Generate random input data
def generate_random_input():
    data = np.random.rand(100, 100)
    tensor = torch.from_numpy(data)
    return tensor

# Generate input data
input_data = generate_random_input()

# Set the number of threads
torch.set_num_threads(random.randint(1, 10))

# Time the input data
start_time = time.time()
# Call the API torch.set_num_threads
torch.set_num_threads(random.randint(1, 10))
end_time = time.time()

# Print the results
print("Input Data Shape:", input_data.shape)
print("Time taken:", end_time - start_time, "seconds")