import torch
import random
import time

def generate_random_data():
    # Generate random input data
    x = torch.randn(1000, 1000)
    y = torch.randn(1000, 1000)
    return x, y

def main():
    # Generate random input data
    x, y = generate_random_data()

    # Call torch.set_num_threads
    num_threads = random.randint(1, 10)
    torch.set_num_threads(num_threads)

    # Measure the time taken to perform operations
    start_time = time.time()
    # Perform some operations here
    z = x + y
    w = z * 2
    end_time = time.time()

    print(f"Number of threads set: {num_threads}")
    print(f"Time taken: {end_time - start_time} seconds")

if __name__ == "__main__":
    main()