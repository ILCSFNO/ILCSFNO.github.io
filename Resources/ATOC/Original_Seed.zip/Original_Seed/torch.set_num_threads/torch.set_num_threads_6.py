import torch
import random

# Generate random input data
input_data = [random.randint(0, 100) for _ in range(100)]

# Set the number of threads
torch.set_num_threads(random.randint(1, 10))