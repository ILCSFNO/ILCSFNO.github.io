import torch
import random
import numpy as np

# Generate random input data
def generate_random_input_data():
    data = np.random.rand(100, 10, 10).astype(np.float32)
    return data

# Set the number of threads
torch.set_num_threads(random.randint(1, 8))

# Generate input data
input_data = generate_random_input_data()

# Test the torch.set_num_threads API
print("Number of threads set:", torch.num_threads())