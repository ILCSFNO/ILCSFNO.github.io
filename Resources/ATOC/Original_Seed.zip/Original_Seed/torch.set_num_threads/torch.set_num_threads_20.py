import torch
import numpy as np

def generate_random_data():
    np.random.seed(0)
    return np.random.rand(100, 10)

def main():
    # Generate random input data
    data = generate_random_data()
    
    # Call the API to set the number of threads
    torch.set_num_threads(4)
    
    # Ensure the correct number of threads is used
    assert torch.cuda.device_count() == 4
    
    # Test the API
    print("Number of threads set successfully")

if __name__ == "__main__":
    main()