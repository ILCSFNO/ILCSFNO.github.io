import torch
import random
import numpy as np

def generate_input_data():
    # Generate random input data
    input_data = np.random.rand(100, 10)
    return input_data

def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Set the number of threads to 4
    torch.set_num_threads(4)
    
    # Perform some operation with the input data
    print("Input Data Shape: ", input_data.shape)
    print("Input Data Type: ", input_data.dtype)

if __name__ == "__main__":
    main()