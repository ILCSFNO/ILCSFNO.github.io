import torch
import random
import time

# Generate random input data
input_data = [random.randint(0, 100) for _ in range(100)]

# Set the number of threads to 4
torch.set_num_threads(4)

# Measure the time taken to run the code
start_time = time.time()

# Run the input data through a dummy operation
for data in input_data:
    torch.tensor(data)

# Print the time taken
print(f"Time taken: {time.time() - start_time} seconds")