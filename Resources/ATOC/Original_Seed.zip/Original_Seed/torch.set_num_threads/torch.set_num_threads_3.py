import torch
import random

def generate_random_data():
    # Generate random data
    data = [random.randint(0, 100) for _ in range(100)]
    labels = [random.randint(0, 2) for _ in range(100)]
    return data, labels

def main():
    # Generate random data
    data, labels = generate_random_data()

    # Set the number of threads
    torch.set_num_threads(random.randint(1, 10))

    # Print the data and labels
    print("Data:", data)
    print("Labels:", labels)

if __name__ == "__main__":
    main()