import torch
import random
import time

def generate_random_input_data():
    data = []
    for _ in range(1000):
        x = random.random()
        y = random.random()
        data.append((x, y))
    return data

def main():
    torch.set_num_threads(random.randint(1, 4))  # Randomly set the number of threads
    start_time = time.time()
    data = generate_random_input_data()
    torch.set_num_threads(1)  # Reset the number of threads
    end_time = time.time()
    print(f"Time taken: {end_time - start_time} seconds")

if __name__ == "__main__":
    main()