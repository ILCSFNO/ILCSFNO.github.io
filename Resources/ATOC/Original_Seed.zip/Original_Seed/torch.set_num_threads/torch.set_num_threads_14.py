import torch
import random
import time

def generate_random_input_data():
    # Generate random input data
    data = [random.randint(0, 100) for _ in range(1000)]
    labels = [random.randint(0, 2) for _ in range(1000)]
    return data, labels

def main():
    # Generate random input data
    data, labels = generate_random_input_data()
    
    # Set the number of threads
    torch.set_num_threads(random.randint(1, 8))
    
    # Measure the time taken by torch.set_num_threads
    start_time = time.time()
    torch.set_num_threads(random.randint(1, 8))
    end_time = time.time()
    print(f"Time taken: {end_time - start_time} seconds")

if __name__ == "__main__":
    main()