import torch
import random

def generate_random_data():
    data = {
        "input": [random.random() for _ in range(1000)],
        "target": [random.random() for _ in range(1000)]
    }
    return data

def main():
    # Generate random data
    data = generate_random_data()
    
    # Set the number of threads
    torch.set_num_threads(4)
    
    # Use the data in some way (in this case, just print it)
    print("Input Data:", data["input"])
    print("Target Data:", data["target"])

if __name__ == "__main__":
    main()