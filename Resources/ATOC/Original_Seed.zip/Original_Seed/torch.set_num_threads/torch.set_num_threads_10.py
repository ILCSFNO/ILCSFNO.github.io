import torch
import random
import time
import numpy as np

# Generate random input data
np.random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))
input_data = np.random.rand(100, 10)
input_tensor = torch.from_numpy(input_data)

# Call the API torch.set_num_threads
torch.set_num_threads(random.randint(1, 10))

# Measure the time taken
start_time = time.time()
# Perform some computation (e.g., matrix multiplication)
result = torch.matmul(input_tensor, input_tensor)
end_time = time.time()

print(f"Time taken: {end_time - start_time} seconds")