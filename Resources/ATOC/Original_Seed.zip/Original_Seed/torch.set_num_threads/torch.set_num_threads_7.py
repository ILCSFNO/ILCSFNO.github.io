import torch
import random

def generate_random_input_data():
    # Generate random input data
    x = torch.randn(1000, 1000)
    y = torch.randn(1000, 1000)
    return x, y

def main():
    # Generate random input data
    x, y = generate_random_input_data()

    # Set the number of threads to 4
    torch.set_num_threads(4)

    # Test the number of threads
    print(f"Number of threads: {torch.get_num_threads()}")

    # Run some eager code
    print("Running eager code...")
    torch.randn(1000, 1000)

    # Run some JIT code
    print("Running JIT code...")
    torch.jit.script(torch.randn(1000, 1000)).eval()

    # Run some autograd code
    print("Running autograd code...")
    torch.autograd.grad(torch.randn(1000, 1000), torch.randn(1000, 1000), retain_graph=True)

if __name__ == "__main__":
    main()