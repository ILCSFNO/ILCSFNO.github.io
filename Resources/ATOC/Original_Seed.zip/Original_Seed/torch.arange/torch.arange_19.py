import torch

# Generate input data
import random
input_start = random.randint(1, 10)
input_end = random.randint(input_start, input_start + 10)
input_step = random.randint(1, 5)

# Call the API torch.arange
output = torch.arange(input_start, input_end, input_step)

print(output)