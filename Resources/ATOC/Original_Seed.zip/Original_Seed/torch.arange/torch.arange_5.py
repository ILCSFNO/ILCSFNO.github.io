import torch

def generate_random_data():
    return torch.randn(100)

def main():
    data = generate_random_data()
    print(torch.arange(0, 10))

if __name__ == "__main__":
    main()