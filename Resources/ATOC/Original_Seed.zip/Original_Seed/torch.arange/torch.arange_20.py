import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

start = np.random.randint(0, 10)
end = np.random.randint(0, 20)
step = np.random.randint(0, 5)

# Generate the input data
input_data = {
    "start": start,
    "end": end,
    "step": step
}

# Call the API torch.arange
torch_output = torch.arange(start, end, step)

# Print the output
print("Input Data:")
for key, value in input_data.items():
    print(f"{key}: {value}")

print("\nTensor Output:")
print(torch_output)