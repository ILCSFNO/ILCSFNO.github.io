import torch
import numpy as np

# Generate random input data
np.random.seed(0)
start = np.random.randint(0, 10)
end = np.random.randint(0, 10) + 1
step = np.random.randint(1, 5)

# Generate input data with any function
data = np.arange(start, end, step)

# Call the API torch.arange
output = torch.tensor(data, dtype=torch.int64, device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu"))

print(output)