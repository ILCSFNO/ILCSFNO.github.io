import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
start = random.randint(0, 100)
end = random.randint(0, 100)
step = random.choice([1, 0.5])

# Generate input data with any function
input_data = {
    "start": start,
    "end": end,
    "step": step,
    "out": torch.arange(start, end, step)
}

# Print the input data
print("Input Data:")
print(input_data)

# Call the API torch.arange
print("\nCalling torch.arange with the following parameters:")
print(f"start: {input_data['start']}")
print(f"end: {input_data['end']}")
print(f"step: {input_data['step']}")

# Print the output of the API torch.arange
print("\nOutput of torch.arange:")
print(input_data["out"])