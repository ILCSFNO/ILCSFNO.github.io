import torch

# Generate input data with random function
import random
import numpy as np

np.random.seed(0)
random.seed(0)

# Generate random start and end values
start = random.randint(0, 10)
end = random.randint(0, 10)

# Generate random step value
step = random.randint(1, 10)

# Generate input data
input_data = {
    "start": start,
    "end": end,
    "step": step
}

# Call the API torch.arange
output = torch.arange(start, end, step, dtype=torch.int64, device="cpu")

print("Input Data:")
for key, value in input_data.items():
    print(f"{key}: {value}")

print("\nOutput:")
print(output)