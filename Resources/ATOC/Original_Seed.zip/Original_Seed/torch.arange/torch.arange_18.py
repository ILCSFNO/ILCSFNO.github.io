import torch

# Generate random input data
import random
input_data = [random.randint(0, 10) for _ in range(10)]

# Call the API torch.arange
torch.arange(input_data[0], input_data[1], input_data[2])