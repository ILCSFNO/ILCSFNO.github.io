import torch

def generate_input_data():
    return torch.tensor([1, 2, 3, 4, 5])

def main():
    input_data = generate_input_data()
    print("Input Data:", input_data)
    print("Output of torch.arange(0, 10, 2):", torch.arange(0, 10, 2))
    print("Output of torch.arange(1, 4, 0.5):", torch.arange(1, 4, 0.5))

if __name__ == "__main__":
    main()