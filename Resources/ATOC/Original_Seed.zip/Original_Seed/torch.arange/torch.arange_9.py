import torch

# Generate input data
import numpy as np
np.random.seed(0)
input_data = np.random.randint(0, 10, 5)

# Call the API torch.arange
torch_output = torch.arange(0, 10, 2)

print(input_data)
print(torch_output)