import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
start = np.random.randint(0, 10)
end = np.random.randint(start, 20)
step = np.random.randint(1, 6)

# Generate input data
data = {
    "start": start,
    "end": end,
    "step": step
}

# Generate output tensor
out = torch.arange(start, end, step)

# Print output
print(data)
print(out)