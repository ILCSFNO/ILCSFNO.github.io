import torch

# Generate input data
import numpy as np
np.random.seed(0)
input_data = np.random.randint(0, 10, 5)

# Call the API torch.arange
output = torch.arange(input_data[0], input_data[0] + input_data[1], input_data[2])

# Print the output
print(output)