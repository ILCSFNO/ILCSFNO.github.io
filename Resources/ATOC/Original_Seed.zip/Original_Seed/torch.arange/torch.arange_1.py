import torch

# Generate random input data
import random
start = random.randint(0, 10)
end = random.randint(0, 20)
step = random.randint(1, 10)

# Call the API torch.arange
print(torch.arange(start, end, step))