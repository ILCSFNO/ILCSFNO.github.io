import torch

# Generate input data with a list comprehension
input_data = [i for i in range(10)]

# Call the API torch.arange
torch_output = torch.arange(0, 10, 2)

# Print the output
print("Input Data:", input_data)
print("torch.arange Output:", torch_output)