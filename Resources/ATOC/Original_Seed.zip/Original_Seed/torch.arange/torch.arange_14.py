import torch
import random

# Generate input data
start = random.randint(0, 10)
end = random.randint(start, 10)
step = random.randint(1, 5)

# Call the API torch.arange
torch.arange(start, end, step)