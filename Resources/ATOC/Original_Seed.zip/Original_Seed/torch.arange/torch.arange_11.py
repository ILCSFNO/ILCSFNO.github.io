import torch
import numpy as np

# Generate random input data
np.random.seed(0)
start = np.random.randint(0, 10)
end = np.random.randint(0, 10) + 1
step = np.random.randint(1, 5)

# Generate input data with any function
input_data = {
    "start": start,
    "end": end,
    "step": step
}

# Call the API torch.arange
output = torch.arange(start, end, step)

# Print the output
print("Input Data:", input_data)
print("Output:", output)