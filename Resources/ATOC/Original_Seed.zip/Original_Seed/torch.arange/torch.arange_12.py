import torch
import numpy as np

# Generate input data
np.random.seed(0)
start = np.random.randint(0, 10)
end = np.random.randint(start, 20)
step = np.random.randint(1, 5)

# Call the API torch.arange
torch_output = torch.arange(start, end, step, requires_grad=False)
np_output = torch.tensor(np.arange(start, end, step))

print("PyTorch Output:")
print(torch_output)

print("\nNumPy Output:")
print(np_output)