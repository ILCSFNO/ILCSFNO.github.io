import torch

# Generate input data with any function
import random
import numpy as np

# Create a random array
random_array = np.random.randint(0, 100, 10)

# Convert numpy array to torch tensor
random_tensor = torch.tensor(random_array)

# Call the API torch.arange
print(torch.arange(10))
print(torch.arange(1, 4))
print(torch.arange(1, 2.5, 0.5))