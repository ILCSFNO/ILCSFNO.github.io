import torch
import numpy as np

# Generate input data
np.random.seed(0)
start = np.random.randint(0, 10)
end = np.random.randint(0, 10)
step = np.random.randint(1, 10)

# Generate input data
input_data = {
    "start": start,
    "end": end,
    "step": step
}

# Call the API torch.arange
output = torch.arange(start, end, step)

# Print the output
print("Input Data:", input_data)
print("Output:", output)

# Print the device and dtype of the output
print("Device:", output.device)
print("Data Type:", output.dtype)