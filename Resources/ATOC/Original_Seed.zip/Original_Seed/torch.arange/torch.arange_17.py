import torch
import numpy as np

# Generate random input data
np.random.seed(0)
start = np.random.randint(0, 10)
end = np.random.randint(1, 11)
step = np.random.randint(1, 6)

# Generate input data
input_data = {
    "start": start,
    "end": end,
    "step": step
}

# Generate output tensor
output_tensor = torch.arange(start, end, step)

# Print the input data and output tensor
print("Input Data:")
for key, value in input_data.items():
    print(f"{key}: {value}")

print("\nOutput Tensor:")
print(output_tensor)