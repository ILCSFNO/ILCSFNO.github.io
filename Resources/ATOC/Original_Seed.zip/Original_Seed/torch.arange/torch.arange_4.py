import torch

# Generate input data with any function
import numpy as np
np.random.seed(0)
input_data = np.random.randint(0, 10, 10)

# Call the API torch.arange
torch_output = torch.arange(0, 10, 2)
print("Input Data: ", input_data)
print("Tensor Output: ", torch_output)