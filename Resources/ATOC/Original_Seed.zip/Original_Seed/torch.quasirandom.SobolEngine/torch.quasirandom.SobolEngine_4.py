import torch
import torch.quasirandom

# Generate input data
input_data = torch.randn(10, 5)

# Create a SobolEngine
soboleng = torch.quasirandom.SobolEngine(dimension=5)

# Draw a sequence of 10 points from the Sobol sequence
output = soboleng.draw(10)

# Print the output
print(output)