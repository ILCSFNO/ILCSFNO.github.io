import torch
import torch.quasirandom as qri

# Generate input data with any function I like
def generate_input_data():
    return torch.randn(10, 5)

# Call the API torch.quasirandom.SobolEngine
def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Create a SobolEngine
    soboleng = qri.SobolEngine(dimension=5, scramble=True)
    
    # Draw a sequence of 10 points from the Sobol sequence
    sequence = soboleng.draw(10)
    
    # Print the input data and the sequence
    print("Input Data:")
    print(input_data)
    print("\nSequence:")
    print(sequence)

if __name__ == "__main__":
    main()