import torch
import numpy as np

# Generate input data
np.random.seed(0)
input_data = np.random.rand(5, 5)

# Create SobolEngine
soboleng = torch.quasirandom.SobolEngine(dimension=5)

# Draw 3 points from the Sobol sequence
points = soboleng.draw(3)

# Print the points
print(points)

# Fast-forward the state of the SobolEngine by 3 steps
soboleng.fast_forward(3)

# Reset the SobolEngine to base state
soboleng.reset()

# Draw 3 points from the Sobol sequence again
points = soboleng.draw(3)

# Print the points
print(points)