import torch
import numpy as np

# Generate input data with any function we like
np.random.seed(0)
input_data = np.random.rand(3, 5)

# Call the API torch.quasirandom.SobolEngine
soboleng = torch.quasirandom.SobolEngine(dimension=5)
sobol_sequence = soboleng.draw(3)

# Print the generated sequence
print(sobol_sequence)

# Fast-forward the state of the SobolEngine by 3 steps
soboleng.fast_forward(3)

# Reset the SobolEngine to base state
soboleng.reset()

# Draw a sequence of 3 points from the Sobol sequence
sobol_sequence = soboleng.draw(3)

# Print the generated sequence
print(sobol_sequence)