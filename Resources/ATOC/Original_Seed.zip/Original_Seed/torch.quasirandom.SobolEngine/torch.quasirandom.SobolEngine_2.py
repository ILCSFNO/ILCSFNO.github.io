import torch
import torch.quasirandom
import numpy as np

# Generate input data with any function we like
def generate_input_data():
    return np.random.rand(100, 5)

# Call the API torch.quasirandom.SobolEngine
def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Create SobolEngine
    soboleng = torch.quasirandom.SobolEngine(dimension=5, scramble=False, seed=42)
    
    # Draw 3 points from the Sobol sequence
    points = soboleng.draw(3)
    
    # Print the points
    print(points)
    
    # Fast-forward the state of the SobolEngine by 10 steps
    soboleng.fast_forward(10)
    
    # Reset the SobolEngine to base state
    soboleng.reset()
    
    # Draw 3 points from the Sobol sequence
    points = soboleng.draw(3)
    
    # Print the points
    print(points)

if __name__ == "__main__":
    main()