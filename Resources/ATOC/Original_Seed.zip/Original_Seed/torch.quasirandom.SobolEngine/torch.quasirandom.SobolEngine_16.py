import torch
import torch.quasirandom

# Generate input data with any function we like
def generate_input_data():
    return torch.randn(3, 5)

# Call the API torch.quasirandom.SobolEngine
def main():
    dimension = 5
    soboleng = torch.quasirandom.SobolEngine(dimension=dimension)
    print(generate_input_data())
    print(soboleng.draw(3))
    print(soboleng.draw_base2(3))
    print(soboleng.fast_forward(10))
    print(soboleng.reset())

if __name__ == "__main__":
    main()