import torch
import torch.quasirandom as qr

# Generate input data
input_data = torch.randn(5, 5)

# Create SobolEngine
soboleng = qr.SobolEngine(dimension=5)

# Draw 3 Sobol sequences
print(soboleng.draw(3))

# Fast-forward the state of the SobolEngine by 10 steps
soboleng.fast_forward(10)

# Reset the SobolEngine to base state
soboleng.reset()

# Draw 3 Sobol sequences
print(soboleng.draw(3))