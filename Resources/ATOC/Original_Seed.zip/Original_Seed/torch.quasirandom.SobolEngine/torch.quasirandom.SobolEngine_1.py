import torch
import torch.quasirandom

# Generate input data
import numpy as np
np.random.seed(0)
dimension = 5
sobol_engine = torch.quasirandom.SobolEngine(dimension=dimension)
sobol_sequence = sobol_engine.draw(100)

# Convert numpy array to torch tensor
sobol_tensor = torch.tensor(sobol_sequence, dtype=torch.float32)

# Print the first 10 elements of the tensor
print(sobol_tensor[:10])