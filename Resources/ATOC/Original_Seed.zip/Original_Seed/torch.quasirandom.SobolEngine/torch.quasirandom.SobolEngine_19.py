import torch
import numpy as np

# Generate input data with any function we like
np.random.seed(0)  # Set the seed for reproducibility
input_data = np.random.rand(10, 5)

# Call the API torch.quasirandom.SobolEngine
sobol_engine = torch.quasirandom.SobolEngine(dimension=5)
sobol_sequence = sobol_engine.draw(10)

# Print the input data and the Sobol sequence
print("Input Data:")
print(input_data)
print("\nSobol Sequence:")
print(sobol_sequence)