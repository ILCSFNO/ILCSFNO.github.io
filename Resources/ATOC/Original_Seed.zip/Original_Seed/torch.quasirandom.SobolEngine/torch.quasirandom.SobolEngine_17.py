import torch
import torch.quasirandom as qr

# Generate input data with random function
import numpy as np
np.random.seed(0)
random_data = np.random.rand(3, 5)

# Call the API torch.quasirandom.SobolEngine
sobol_engine = qr.SobolEngine(dimension=5, scramble=True, seed=0)

# Draw a sequence of 3 points from a Sobol sequence
sobol_sequence = sobol_engine.draw(3)

# Print the generated sequence
print("Generated Sobol Sequence:")
print(sobol_sequence)

# Fast-forward the state of the SobolEngine by 10 steps
sobol_engine.fast_forward(10)

# Reset the SobolEngine to base state
sobol_engine.reset()

# Draw a sequence of 3 points from a Sobol sequence
sobol_sequence = sobol_engine.draw(3)

# Print the generated sequence
print("\nGenerated Sobol Sequence after resetting:")
print(sobol_sequence)