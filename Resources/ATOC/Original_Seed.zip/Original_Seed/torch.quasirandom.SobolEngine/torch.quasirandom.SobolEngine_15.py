import torch
import torch.quasirandom

# Generate input data
import numpy as np
np.random.seed(0)

# Generate 5 random 3D points
points = np.random.rand(3, 5, 5)

# Call the API torch.quasirandom.SobolEngine
soboleng = torch.quasirandom.SobolEngine(dimension=5, scramble=False, seed=None)
sobol_sequence = soboleng.draw_base2(m=10)
print(sobol_sequence)

# Call the API torch.quasirandom.SobolEngine
sobol_sequence = soboleng.draw(n=3)
print(sobol_sequence)

# Call the API torch.quasirandom.SobolEngine
sobol_sequence = soboleng.draw_base2(m=10)
print(sobol_sequence)

# Call the API torch.quasirandom.SobolEngine
sobol_sequence = soboleng.draw(n=3)
print(sobol_sequence)

# Call the API torch.quasirandom.SobolEngine
sobol_sequence = soboleng.draw_base2(m=10)
print(sobol_sequence)

# Call the API torch.quasirandom.SobolEn