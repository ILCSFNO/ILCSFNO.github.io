import torch
import torch.quasirandom as quasirandom

# Generate input data with random function
import random
random_data = [[random.random() for _ in range(5)] for _ in range(3)]

# Call the API torch.quasirandom.SobolEngine
soboleng = quasirandom.SobolEngine(dimension=5)
sobol_sequence = soboleng.draw_base2(m=3)

# Print the generated sequence
print("Generated Sequence:")
for sequence in sobol_sequence:
    print(sequence)

# Print the input data
print("\nInput Data:")
for data in random_data:
    print(data)

# Fast-forward the state of the SobolEngine by 10 steps
soboleng.fast_forward(n=10)

# Reset the SobolEngine to base state
soboleng.reset()