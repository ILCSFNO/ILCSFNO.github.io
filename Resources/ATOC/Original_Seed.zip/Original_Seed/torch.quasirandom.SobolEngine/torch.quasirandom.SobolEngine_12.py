import torch
import numpy as np

# Generate input data
np.random.seed(0)
dimension = 5
scramble = True
seed = 0

# Call the API torch.quasirandom.SobolEngine
soboleng = torch.quasirandom.SobolEngine(dimension=dimension, scramble=scramble, seed=seed)

# Draw 3 random points from the Sobol sequence
points = soboleng.draw(3)

# Print the points
print(points)

# Fast-forward the state of the SobolEngine by 1 step
soboleng.fast_forward(1)

# Draw 3 random points from the Sobol sequence
points = soboleng.draw(3)

# Print the points
print(points)