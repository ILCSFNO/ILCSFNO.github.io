import torch
import torch.quasirandom as quasirandom
import numpy as np
import random

def generate_sobol_engine(dimension, scramble=False, seed=None):
    if seed is not None:
        torch.manual_seed(seed)
        random.seed(seed)
    sobol_engine = quasirandom.SobolEngine(dimension, scramble=scramble)
    return sobol_engine

def generate_input_data(dimension):
    sobol_engine = generate_sobol_engine(dimension)
    points = sobol_engine.draw(10)
    return points

def main():
    dimension = 5
    points = generate_input_data(dimension)
    print(points)

if __name__ == "__main__":
    main()