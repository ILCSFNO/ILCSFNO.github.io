import torch
import torch.quasirandom
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(3, 5)

# Generate Sobol sequence
sobol_engine = torch.quasirandom.SobolEngine(dimension=5, scramble=True, seed=0)
sobol_sequence = sobol_engine.draw_base2(m=5)

# Convert Sobol sequence to tensor
sobol_tensor = torch.tensor(sobol_sequence, dtype=torch.float32)

# Print input data and Sobol sequence
print("Input Data:")
print(input_data)
print("\nSobol Sequence:")
print(sobol_tensor)