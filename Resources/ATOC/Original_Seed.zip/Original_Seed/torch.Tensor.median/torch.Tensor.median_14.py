import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
input_data = np.random.randint(0, 100, (10, 5))

# Convert input data to torch.Tensor
input_tensor = torch.from_numpy(input_data)

# Call the API torch.Tensor.median
median_result = input_tensor.median(dim=1, keepdim=True)

print("Input Data:")
print(input_tensor)
print("\nMedian Result:")
print(median_result)