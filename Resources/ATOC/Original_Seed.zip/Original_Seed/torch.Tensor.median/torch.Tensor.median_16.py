import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    data = np.random.rand(100, 10)
    tensor = torch.tensor(data, dtype=torch.float32)
    return tensor

# Generate input data
tensor = generate_random_data()

# Call the API torch.Tensor.median
print(tensor.median(dim=0))