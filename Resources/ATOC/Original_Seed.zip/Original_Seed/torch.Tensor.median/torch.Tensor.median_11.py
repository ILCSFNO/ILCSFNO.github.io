import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
torch.manual_seed(0)
random.seed(0)

data = np.random.randint(1, 100, 10)
tensor_data = torch.tensor(data)

# Call the API torch.Tensor.median
median_value = tensor_data.median()

print("Median Value: ", median_value)