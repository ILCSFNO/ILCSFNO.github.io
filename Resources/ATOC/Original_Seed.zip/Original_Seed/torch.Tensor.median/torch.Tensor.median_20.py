import torch
import numpy as np
import random

# Generate random input data
def generate_random_data(size):
    return torch.tensor(np.random.rand(size, 10))

# Generate random input data with specific shape
data = generate_random_data(100)

# Call the median API
print(data.median(dim=0))