import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    return torch.randn(10, 5)

# Call the API torch.Tensor.median
def main():
    input_data = generate_input_data()
    print("Input Data:")
    print(input_data)
    print("\nMedian of Input Data:")
    print(input_data.median())

if __name__ == "__main__":
    main()