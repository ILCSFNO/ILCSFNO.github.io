import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    return torch.tensor(np.random.rand(10, 10))

# Generate input data
input_data = generate_random_data()

# Call the API torch.Tensor.median
median_value = input_data.median()

print("Median Value: ", median_value)