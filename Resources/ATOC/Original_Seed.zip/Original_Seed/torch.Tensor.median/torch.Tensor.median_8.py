import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
data = np.random.rand(1000)

# Convert numpy array to torch tensor
tensor = torch.tensor(data)

# Call the median function
median_value = tensor.median()

print("Median value: ", median_value)