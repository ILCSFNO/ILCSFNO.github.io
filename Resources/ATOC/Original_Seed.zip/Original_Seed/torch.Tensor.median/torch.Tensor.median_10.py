import torch
import numpy as np
import random

def generate_random_data():
    return torch.randn(10, 5)

def main():
    # Generate random data
    data = generate_random_data()

    # Calculate median along the first dimension
    median = data.median(dim=0)

    # Calculate median along the last dimension
    median_last_dim = data.median(dim=1)

    # Calculate median without keeping the dimension
    median_no_keepdim = data.median(dim=0, keepdim=False)

    # Calculate median along the first dimension with keeping the dimension
    median_keepdim = data.median(dim=0, keepdim=True)

    print("Median along the first dimension:")
    print(median)
    print("Median along the last dimension:")
    print(median_last_dim)
    print("Median without keeping the dimension:")
    print(median_no_keepdim)
    print("Median along the first dimension with keeping the dimension:")
    print(median_keepdim)

if __name__ == "__main__":
    main()