import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    data = np.random.rand(100, 10)
    tensor = torch.from_numpy(data)
    return tensor

# Generate input data
input_tensor = generate_input_data()

# Call the API torch.Tensor.median
print(input_tensor.median())