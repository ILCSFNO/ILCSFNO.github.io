import torch
import numpy as np
import random

def generate_random_data():
    return torch.tensor(np.random.randint(0, 100, (10, 10)))

def main():
    data = generate_random_data()
    median_value = data.median(dim=0)
    print("Median values along each row:")
    print(median_value)
    print("Median value of the entire tensor:")
    print(data.median())

if __name__ == "__main__":
    main()