import torch
import numpy as np
import random

def generate_random_data(size):
    return torch.tensor(np.random.rand(size))

def main():
    # Generate random data
    data = generate_random_data(1000)
    
    # Call torch.Tensor.median
    median = data.median()
    
    print(f"Median: {median}")

if __name__ == "__main__":
    main()