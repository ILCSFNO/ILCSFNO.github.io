import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
data = torch.tensor(np.random.randint(0, 100, size=(10, 10)))

# Call the API torch.Tensor.median
print(data.median())