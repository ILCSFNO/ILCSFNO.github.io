import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    return torch.randn(10, 10)

# Generate input data
input_data = generate_random_data()

# Call the API torch.Tensor.median
print(input_data.median())