import torch
import numpy as np
import random

def generate_random_data():
    # Generate random data
    data = np.random.rand(100, 5)
    tensor_data = torch.tensor(data, dtype=torch.float32)
    return tensor_data

def main():
    # Generate random data
    tensor_data = generate_random_data()

    # Call the API torch.Tensor.median
    median_value = tensor_data.median(dim=0)

    print("Median Value: ", median_value)

if __name__ == "__main__":
    main()