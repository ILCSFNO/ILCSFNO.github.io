import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
data = np.random.rand(100, 5)
tensor = torch.tensor(data, dtype=torch.float32)

# Call the API torch.Tensor.median
print("Median of tensor:")
print(tensor.median(dim=0))
print("Median of tensor along a specific dimension (dim=1):")
print(tensor.median(dim=1, keepdim=True))
print("Median of tensor along all dimensions:")
print(tensor.median())