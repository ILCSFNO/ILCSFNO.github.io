import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
input_data = np.random.rand(10, 10)

# Convert numpy array to torch tensor
tensor = torch.from_numpy(input_data)

# Call the API torch.Tensor.median
median_value = tensor.median()

# Print the result
print("Median value: ", median_value)