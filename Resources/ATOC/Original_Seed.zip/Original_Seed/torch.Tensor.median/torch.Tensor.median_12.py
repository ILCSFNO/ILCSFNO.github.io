import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    data = np.random.rand(100, 10)
    tensor_data = torch.from_numpy(data)
    return tensor_data

# Generate random input data
tensor_data = generate_input_data()

# Call the API torch.Tensor.median
median_result = tensor_data.median(dim=1)

# Print the result
print("Median result:")
print(median_result)

# Check if the result is a tensor
print("Is the result a tensor?", isinstance(median_result, torch.Tensor))

# Check if the result is a scalar
print("Is the result a scalar?", median_result.is_scalar())

# Check if the result is NaN
print("Is the result NaN?", median_result.isnan().any())