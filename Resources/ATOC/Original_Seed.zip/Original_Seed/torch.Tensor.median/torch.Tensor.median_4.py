import torch
import numpy as np
import random

# Generate random input data
def generate_random_data(size):
    return torch.tensor(np.random.randint(0, 100, size=(size, 10)))

# Generate input data
input_data = generate_random_data(100)

# Call the API torch.Tensor.median
print(input_data.median(dim=0))