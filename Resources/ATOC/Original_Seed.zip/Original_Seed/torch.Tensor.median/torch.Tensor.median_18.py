import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)

# Generate 10 random numbers
numbers = np.random.randint(1, 100, 10)

# Convert numpy array to torch tensor
tensor = torch.tensor(numbers)

# Call the API torch.Tensor.median
median = tensor.median()

# Print the result
print("Median:", median)