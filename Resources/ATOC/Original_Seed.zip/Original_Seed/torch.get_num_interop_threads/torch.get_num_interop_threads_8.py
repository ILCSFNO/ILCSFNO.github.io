import torch
import random
import time

def generate_random_input():
    return [random.randint(0, 100) for _ in range(10)]

def main():
    input_data = generate_random_input()
    num_interop_threads = torch.get_num_interop_threads()
    print(f"Input Data: {input_data}")
    print(f"Number of Inter-op Threads: {num_interop_threads}")
    print(f"Time taken: {time.time() - start_time} seconds")

if __name__ == "__main__":
    start_time = time.time()
    main()