import torch

def generate_random_data():
    import random
    import numpy as np

    data = np.random.rand(100, 10)
    labels = np.random.randint(0, 2, 100)
    return data, labels

def main():
    data, labels = generate_random_data()

    # Ensure that the data is on a device (CPU or GPU)
    device = torch.device("cpu")
    data = data.to(device)
    labels = labels.to(device)

    # Get the number of inter-op threads
    num_interop_threads = torch.get_num_interop_threads()
    print(f"Number of inter-op threads: {num_interop_threads}")

if __name__ == "__main__":
    main()