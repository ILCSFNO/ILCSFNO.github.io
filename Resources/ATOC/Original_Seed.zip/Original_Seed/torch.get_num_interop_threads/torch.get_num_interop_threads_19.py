import torch

def generate_input_data():
    import numpy as np
    import random

    data = np.random.rand(1000)
    labels = np.random.randint(0, 2, 1000)
    return data, labels

def main():
    data, labels = generate_input_data()
    print(f"Data: {data}, Labels: {labels}")

    num_interop_threads = torch.get_num_interop_threads()
    print(f"Number of Inter-op Threads: {num_interop_threads}")

if __name__ == "__main__":
    main()