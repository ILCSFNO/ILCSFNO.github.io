import torch

def generate_random_input_data():
    import numpy as np
    return np.random.rand(10, 10)

def main():
    input_data = generate_random_input_data()
    print("Input Data Shape:", input_data.shape)
    
    num_interop_threads = torch.get_num_interop_threads()
    print("Number of Inter-op Threads:", num_interop_threads)

if __name__ == "__main__":
    main()