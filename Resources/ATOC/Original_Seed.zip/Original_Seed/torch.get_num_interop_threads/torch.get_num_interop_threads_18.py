import torch

def generate_random_input_data():
    import numpy as np
    import random
    input_data = np.random.rand(10, 10)
    return input_data

def main():
    input_data = generate_random_input_data()
    num_interop_threads = torch.get_num_interop_threads()
    print(f"Input Data: {input_data}")
    print(f"Number of Inter-op Threads: {num_interop_threads}")

if __name__ == "__main__":
    main()