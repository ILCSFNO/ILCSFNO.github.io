import torch
import random

def generate_random_data():
    return [random.randint(0, 100) for _ in range(10)]

def main():
    # Generate random input data
    data = generate_random_data()
    
    # Call the API torch.get_num_interop_threads
    num_threads = torch.get_num_interop_threads()
    
    # Print the results
    print("Input Data:", data)
    print("Number of Inter-op Threads:", num_threads)

if __name__ == "__main__":
    main()