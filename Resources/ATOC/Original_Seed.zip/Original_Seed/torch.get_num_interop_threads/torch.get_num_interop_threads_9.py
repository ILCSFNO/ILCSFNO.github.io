import torch

def generate_input_data():
    import numpy as np
    import random
    data = np.random.rand(10, 10)
    labels = np.random.randint(0, 2, size=10)
    return data, labels

def main():
    data, labels = generate_input_data()
    num_threads = torch.get_num_interop_threads()
    print(f"Number of inter-op threads: {num_threads}")
    print(f"Input data shape: {data.shape}")
    print(f"Input labels shape: {labels.shape}")

if __name__ == "__main__":
    main()