import torch
import random

def generate_random_data():
    # Generate random data
    data = [random.randint(0, 100) for _ in range(1000)]
    return data

def main():
    # Generate random input data
    data = generate_random_data()

    # Call the API to get the number of inter-op threads
    num_threads = torch.get_num_interop_threads()

    # Print the result
    print("Number of inter-op threads:", num_threads)

if __name__ == "__main__":
    main()