import torch

def generate_input_data():
    import numpy as np
    import random

    # Generate random data for demonstration
    data = np.random.rand(100, 10, 10)
    labels = np.random.randint(0, 2, 100)

    return data, labels

def main():
    data, labels = generate_input_data()

    # Call the API torch.get_num_interop_threads
    num_interop_threads = torch.get_num_interop_threads()

    print(f"Number of inter-op threads: {num_interop_threads}")

    # Use the generated data for testing
    print("Generated Data Shape:")
    print(data.shape)
    print("Generated Labels Shape:")
    print(labels.shape)

if __name__ == "__main__":
    main()