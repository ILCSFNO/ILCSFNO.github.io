import torch

def generate_random_data():
    import random
    import numpy as np
    import pandas as pd
    
    random.seed(42)
    np.random.seed(42)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    
    data = {
        'Name': ['John', 'Anna', 'Peter', 'Linda', 'Tom'],
        'Age': np.random.randint(20, 60, 5),
        'Country': np.random.choice(['USA', 'UK', 'Australia', 'Germany'], 5)
    }
    
    df = pd.DataFrame(data)
    return df

def main():
    df = generate_random_data()
    print(df)
    
    num_threads = torch.get_num_interop_threads()
    print(f"Number of inter-op threads: {num_threads}")

if __name__ == "__main__":
    main()