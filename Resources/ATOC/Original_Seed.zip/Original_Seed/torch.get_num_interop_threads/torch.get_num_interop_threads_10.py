import torch
import random

def generate_input_data():
    return [random.randint(0, 100) for _ in range(100)]

def main():
    input_data = generate_input_data()
    num_interop_threads = torch.get_num_interop_threads()
    print(f"Input Data: {input_data}")
    print(f"Number of Inter-op Threads: {num_interop_threads}")

if __name__ == "__main__":
    main()