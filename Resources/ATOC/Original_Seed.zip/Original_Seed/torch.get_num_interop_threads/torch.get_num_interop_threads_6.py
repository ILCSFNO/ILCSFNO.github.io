import torch
import random

# Generate random input data
def generate_input_data():
    return [random.randint(1, 100) for _ in range(10)]

# Main function
def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Get the number of inter-op threads
    num_interop_threads = torch.get_num_interop_threads()
    
    # Print the result
    print(f"Input Data: {input_data}")
    print(f"Number of Inter-Op Threads: {num_interop_threads}")

if __name__ == "__main__":
    main()