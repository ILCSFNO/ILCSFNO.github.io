import torch

def generate_input_data():
    return torch.randn(1000, 1000)

def main():
    input_data = generate_input_data()
    num_interop_threads = torch.get_num_interop_threads()
    print(f"Number of input data points: {input_data.shape[0]}")
    print(f"Number of inter-op threads: {num_interop_threads}")

if __name__ == "__main__":
    main()