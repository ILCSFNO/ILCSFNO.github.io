import torch
import random

def generate_random_data():
    return [random.randint(0, 100) for _ in range(100)]

def main():
    # Generate random input data
    data = generate_random_data()

    # Get the number of inter-op threads
    num_interop_threads = torch.get_num_interop_threads()

    print(f"Generated Data: {data}")
    print(f"Number of Inter-op Threads: {num_interop_threads}")

if __name__ == "__main__":
    main()