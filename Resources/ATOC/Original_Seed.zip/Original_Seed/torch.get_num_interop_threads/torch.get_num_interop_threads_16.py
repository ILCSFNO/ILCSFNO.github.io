import torch

def generate_input_data():
    # Generate random input data
    import random
    import numpy as np
    input_data = np.random.rand(10, 10)
    return input_data

def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Get the number of inter-op threads
    num_interop_threads = torch.get_num_interop_threads()
    
    # Print the results
    print("Input Data Shape:", input_data.shape)
    print("Number of Inter-op Threads:", num_interop_threads)

if __name__ == "__main__":
    main()