import torch

# Generate input data (not used in this case)
import random
import numpy as np

# Generate random numbers for testing
random.seed(0)
np.random.seed(0)

def test_get_num_interop_threads():
    # Call the API torch.get_num_interop_threads
    num_threads = torch.get_num_interop_threads()
    print(f"Number of inter-op threads: {num_threads}")

test_get_num_interop_threads()