import torch

def generate_random_input_data():
    import random
    import numpy as np
    import torch.nn.functional as F

    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)

    x = np.random.rand(100, 10)
    y = np.random.rand(100, 10)
    input_data = torch.tensor(x, dtype=torch.float32)
    label_data = torch.tensor(y, dtype=torch.float32)

    return input_data, label_data

def main():
    input_data, label_data = generate_random_input_data()
    num_interop_threads = torch.get_num_interop_threads()
    print(f"Number of threads used for inter-op parallelism on CPU: {num_interop_threads}")

if __name__ == "__main__":
    main()