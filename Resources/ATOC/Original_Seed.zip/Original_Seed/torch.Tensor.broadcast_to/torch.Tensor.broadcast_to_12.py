import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    tensor = torch.randn(shape)
    return tensor

# Generate input data
tensor = generate_input_data()

# Call the API torch.Tensor.broadcast_to
def main():
    # Get the shape of the input tensor
    input_shape = tensor.shape
    
    # Generate the desired shape
    desired_shape = (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))
    
    # Call the API
    broadcasted_tensor = tensor.broadcast_to(desired_shape)
    
    # Print the input tensor
    print("Input Tensor:")
    print(tensor)
    
    # Print the broadcasted tensor
    print("Broadcasted Tensor:")
    print(broadcasted_tensor)

if __name__ == "__main__":
    main()