import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    shape = (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))
    return torch.randn(shape)

# Generate input data
input_data = generate_random_data()

# Call the API torch.Tensor.broadcast_to
def call_broadcast_to(input_data):
    shape = input_data.shape
    broadcast_shape = list(shape)
    broadcast_shape[0] = 1
    return input_data.broadcast_to(broadcast_shape)

output = call_broadcast_to(input_data)

print(output)