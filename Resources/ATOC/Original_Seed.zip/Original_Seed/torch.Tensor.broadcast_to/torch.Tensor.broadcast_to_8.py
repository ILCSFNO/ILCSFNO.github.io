import torch
import numpy as np
import random

def generate_random_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    data = torch.randn(shape)
    return data

def main():
    data = generate_random_data()
    print("Original Data Shape: ", data.shape)
    
    shape = (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))
    target_shape = (10, 10, 10)
    
    broadcasted_data = data.broadcast_to(target_shape)
    print("Broadcasted Data Shape: ", broadcasted_data.shape)

if __name__ == "__main__":
    main()