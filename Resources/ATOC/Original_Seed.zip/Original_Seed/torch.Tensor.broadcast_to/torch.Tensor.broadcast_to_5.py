import torch
import numpy as np
import random

# Generate random input data
random_shape = (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))
random_tensor = torch.randn(random_shape)

# Generate output shape
output_shape = (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))

# Call the API torch.Tensor.broadcast_to
output_tensor = random_tensor.broadcast_to(output_shape)

# Print the results
print("Input Tensor Shape:", random_tensor.shape)
print("Input Tensor:")
print(random_tensor)
print("Output Tensor Shape:", output_tensor.shape)
print("Output Tensor:")
print(output_tensor)