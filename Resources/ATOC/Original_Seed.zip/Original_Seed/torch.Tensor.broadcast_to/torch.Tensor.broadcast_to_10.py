import torch
import random
import numpy as np

def generate_random_tensor(shape, value):
    return torch.tensor(np.random.choice(value, shape))

def generate_input_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    return generate_random_tensor(shape, [0, 1])

def main():
    input_tensor = generate_input_data()
    print("Original Tensor Shape: ", input_tensor.shape)
    broadcasted_tensor = input_tensor.broadcast_to((20, 30))
    print("Broadcasted Tensor Shape: ", broadcasted_tensor.shape)

if __name__ == "__main__":
    main()