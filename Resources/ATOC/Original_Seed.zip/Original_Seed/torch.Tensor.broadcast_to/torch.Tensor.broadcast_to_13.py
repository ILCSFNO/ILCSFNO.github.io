import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    shape = (2, 3, 4)
    input_data = np.random.rand(2, 3, 4)
    return torch.from_numpy(input_data)

# Generate random output shape
def generate_output_shape():
    shape = (3, 4)
    return shape

# Main function
def main():
    input_data = generate_input_data()
    output_shape = generate_output_shape()
    
    # Create a new tensor with the output shape
    output_tensor = torch.zeros(output_shape)
    
    # Call the broadcast_to function
    input_tensor = input_data.expand(output_shape[0], output_shape[1], output_shape[2])
    input_tensor = input_tensor broadcast_to(output_shape)
    
    # Print the input and output tensors
    print("Input Tensor:")
    print(input_tensor)
    print("\nOutput Tensor:")
    print(output_tensor)

if __name__ == "__main__":
    main()