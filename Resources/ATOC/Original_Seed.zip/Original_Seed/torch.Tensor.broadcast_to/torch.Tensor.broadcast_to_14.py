import torch
import random
import numpy as np

# Generate random input data
def generate_input_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    input_data = torch.randn(shape)
    return input_data

# Generate random output shape
def generate_output_shape():
    return (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))

# Generate random input data and output shape
input_data = generate_input_data()
output_shape = generate_output_shape()

# Call the API torch.Tensor.broadcast_to
input_data_broadcast = input_data.broadcast_to(output_shape)

# Print the output
print("Input Data:")
print(input_data)
print("\nOutput Shape:")
print(output_shape)
print("\nBroadcasted Input Data:")
print(input_data_broadcast)