import torch
import numpy as np
import random

def generate_random_tensor(size):
    return torch.randn(size)

def generate_input_data():
    size = random.randint(1, 10)
    tensor = generate_random_tensor(size)
    broadcasted_tensor = tensor.expand((size, size))
    return tensor, broadcasted_tensor

tensor, broadcasted_tensor = generate_input_data()

print("Original Tensor:")
print(tensor)

print("\nBroadcasted Tensor:")
print(broadcasted_tensor)

print("\nBroadcasted Tensor Shape:", broadcasted_tensor.shape)

print("\nBroadcasted Tensor Dimensions:")
print(broadcasted_tensor.dim())

print("\nBroadcasted Tensor Size:")
print(broadcasted_tensor.numel())