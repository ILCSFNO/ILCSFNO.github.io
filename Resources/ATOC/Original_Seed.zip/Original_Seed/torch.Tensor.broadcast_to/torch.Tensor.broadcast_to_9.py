import torch
import numpy as np
import random

# Generate random input data
input_tensor = torch.randn(2, 3, 4)

# Generate random shape
shape = (5, 6)

# Call the API torch.Tensor.broadcast_to
output_tensor = input_tensor.broadcast_to(shape)

# Print the output
print(output_tensor)