import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    tensor = torch.randn(shape)
    return tensor

# Generate input data
tensor = generate_input_data()

# Call the API torch.Tensor.broadcast_to
tensor_broadcasted = tensor.broadcast_to((tensor.shape[0], tensor.shape[1], random.randint(1, 10)))

# Print the input data and the output
print("Input Data:")
print(tensor)
print("\nOutput:")
print(tensor_broadcasted)

# Verify the output
print("\nVerification:")
print(tensor.shape, tensor_broadcasted.shape)