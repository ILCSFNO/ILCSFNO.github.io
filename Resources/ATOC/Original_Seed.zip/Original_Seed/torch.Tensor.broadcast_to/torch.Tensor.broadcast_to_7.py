import torch
import random
import numpy as np

# Generate random input data
input_data = torch.randn(2, 3, 4)

# Generate random shape
shape = (5, 6, 7)

# Call the API torch.Tensor.broadcast_to
output = input_data.broadcast_to(shape)

print(output)