import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    data = torch.randn(shape)
    return data

# Generate input data
data = generate_input_data()

# Call the API torch.Tensor.broadcast_to
print(data.broadcast_to((10, 10, 10)))