import torch
import numpy as np
import random

# Generate random input data
def generate_random_input_data():
    random.seed(0)
    input_data = torch.randn(2, 3, 4)
    return input_data

# Generate random shape
def generate_random_shape():
    random.seed(0)
    shape = (random.randint(1, 10), random.randint(1, 10))
    return shape

# Call the API torch.Tensor.broadcast_to
def main():
    input_data = generate_random_input_data()
    shape = generate_random_shape()
    input_data_broadcast = input_data.broadcast_to(shape)
    print(input_data_broadcast)

if __name__ == "__main__":
    main()