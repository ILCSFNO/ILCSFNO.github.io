import torch
import numpy as np
import random

# Generate random input data
random_input_data = np.random.rand(2, 3, 4, 5)

# Create a tensor from the input data
input_tensor = torch.from_numpy(random_input_data)

# Generate a broadcast shape
broadcast_shape = (1, 2, 3, 4, 5)

# Call the API torch.Tensor.broadcast_to
broadcast_tensor = input_tensor.broadcast_to(broadcast_shape)

print(broadcast_tensor)