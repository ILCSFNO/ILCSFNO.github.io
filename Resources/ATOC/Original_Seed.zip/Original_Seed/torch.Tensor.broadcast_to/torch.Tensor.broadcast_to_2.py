import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    return torch.randn(3, 4, 5, 6)

# Generate random input data
data = generate_random_data()

# Call the API torch.Tensor.broadcast_to
def call_broadcast_to(data):
    shape = (10, 8, 6, 4)
    return data.broadcast_to(shape)

# Call the API torch.Tensor.broadcast_to
result = call_broadcast_to(data)

# Print the result
print(result)