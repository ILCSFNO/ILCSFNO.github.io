import torch
import numpy as np
import random

def generate_input_data():
    # Generate random data
    data = np.random.rand(2, 3, 4, 5)
    tensor = torch.from_numpy(data)
    return tensor

def main():
    tensor = generate_input_data()
    # Randomly choose a shape
    shape = (random.randint(1, 10), random.randint(1, 10), random.randint(1, 10), random.randint(1, 10))
    # Broadcast the tensor to the chosen shape
    broadcasted_tensor = tensor.broadcast_to(shape)
    print(broadcasted_tensor)

if __name__ == "__main__":
    main()