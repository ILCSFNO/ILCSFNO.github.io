import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)

# Random tensor
tensor = torch.randn(2, 3, 4)

# Random shape
shape = (5, 6, 7)

# Generate input data
input_data = torch.randn(1, 2, 3)

# Call the API torch.Tensor.broadcast_to
output = tensor.broadcast_to(shape)

# Print the output
print(output)
print(input_data)