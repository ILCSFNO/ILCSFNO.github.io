import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    random_shape = (random.randint(1, 5), random.randint(1, 5), random.randint(1, 5))
    random_tensor = torch.randn(random_shape)
    return random_tensor

# Generate input data
input_tensor = generate_input_data()

# Call the API torch.Tensor.broadcast_to
print("Original Tensor:")
print(input_tensor.shape)
print(input_tensor)

print("\nBroadcasted Tensor:")
input_tensor_broadcasted = input_tensor.broadcast_to((10, 10, 10))
print(input_tensor_broadcasted.shape)
print(input_tensor_broadcasted)