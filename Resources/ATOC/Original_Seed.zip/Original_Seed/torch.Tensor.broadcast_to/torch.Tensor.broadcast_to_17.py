import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    shape = (random.randint(1, 10), random.randint(1, 10))
    input_data = np.random.rand(*shape)
    input_tensor = torch.from_numpy(input_data).float()
    return input_tensor

# Generate input data and call the API
input_tensor = generate_input_data()
print("Input Tensor Shape:", input_tensor.shape)

# Call the API torch.Tensor.broadcast_to
input_tensor_broadcast = input_tensor.broadcast_to((10, 10))
print("Broadcasted Tensor Shape:", input_tensor_broadcast.shape)