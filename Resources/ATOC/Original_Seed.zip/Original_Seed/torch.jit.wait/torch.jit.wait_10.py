import torch
import random

def generate_random_input_data():
    return [random.randint(0, 100) for _ in range(10)]

def main():
    # Generate input data
    input_data = generate_random_input_data()
    print("Input Data:", input_data)

    # Create a future
    future = torch.jit.fork(generate_random_input_data)

    # Wait for the future to complete
    result = torch.jit.wait(future)

    print("Result:", result)

if __name__ == "__main__":
    main()