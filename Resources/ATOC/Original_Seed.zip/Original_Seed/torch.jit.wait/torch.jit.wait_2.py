import torch
import random
import time

def generate_input_data():
    data = []
    for _ in range(1000):
        x = torch.randn(1, 3, 224, 224)
        y = torch.randn(1)
        data.append((x, y))
    return data

def main():
    data = generate_input_data()
    input_x, input_y = data[0]
    
    # Create a torch.jit.Future
    future = torch.jit.fork(input_x, input_y)
    
    # Wait for the future to complete
    result = torch.jit.wait(future)
    
    print("Input X Shape:", input_x.shape)
    print("Input Y Shape:", input_y.shape)
    print("Result Shape:", result.shape)

if __name__ == "__main__":
    main()