import torch
import random

def generate_input_data():
    # Generate random input data
    inputs = [(random.randint(0, 100), random.randint(0, 100), random.randint(0, 100)) for _ in range(10)]
    return inputs

def main():
    # Generate input data
    inputs = generate_input_data()

    # Create a torch.jit.Future for each input
    futures = [torch.jit.fork() for _ in range(len(inputs))]

    # Wait for each future to complete
    results = []
    for future in futures:
        result = torch.jit.wait(future)
        results.append(result)

    # Print the results
    for i, result in enumerate(results):
        print(f"Input {i+1}: {inputs[i]}, Result: {result}")

if __name__ == "__main__":
    main()