import torch
import random

# Generate random input data
def generate_random_data():
    return torch.randn(100, 100)

# Generate input data
input_data = generate_random_data()

# Create a torch.jit.Future instance
future = torch.jit.fork(generate_random_data)

# Wait for the future to complete
result = torch.jit.wait(future)

# Print the result
print(result)