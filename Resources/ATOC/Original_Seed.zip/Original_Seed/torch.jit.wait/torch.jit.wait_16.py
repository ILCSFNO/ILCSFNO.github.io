import torch
import random

def generate_random_data():
    return [random.randint(0, 100) for _ in range(10)]

def main():
    data = generate_random_data()
    future = torch.jit.fork(generate_random_data)
    result = torch.jit.wait(future)
    print("Random Data:", data)
    print("Result of the task:", result)

if __name__ == "__main__":
    main()