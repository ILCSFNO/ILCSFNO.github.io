import torch
import random
import time

def generate_random_data():
    data = [random.randint(0, 100) for _ in range(10)]
    labels = [random.randint(0, 1) for _ in range(10)]
    return data, labels

def main():
    data, labels = generate_random_data()
    future = torch.jit.fork(lambda: (torch.tensor(data), torch.tensor(labels)))
    start_time = time.time()
    result = torch.jit.wait(future)
    end_time = time.time()
    print("Time taken:", end_time - start_time)

if __name__ == "__main__":
    main()