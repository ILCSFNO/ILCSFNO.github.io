import torch
import random
import time

def generate_random_data():
    return [random.randint(0, 100) for _ in range(10)]

def main():
    # Generate random data
    data = generate_random_data()

    # Create a future
    future = torch.jit.fork(generate_random_data)

    # Wait for the future to complete
    result = torch.jit.wait(future)

    # Print the result
    print(result)

if __name__ == "__main__":
    main()