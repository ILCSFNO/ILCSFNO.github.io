import torch
import random

def generate_random_data():
    return torch.randn(10, 10)

def generate_random_future():
    return torch.jit.fork(generate_random_data)

def main():
    future = generate_random_future()
    result = torch.jit.wait(future)
    print(result)

if __name__ == "__main__":
    main()