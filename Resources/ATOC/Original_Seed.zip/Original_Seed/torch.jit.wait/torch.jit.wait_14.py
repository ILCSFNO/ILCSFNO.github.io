import torch
import torch.jit
import random
import time

def generate_random_input():
    return [random.random() for _ in range(100)]

def main():
    input_data = generate_random_input()
    print("Input Data: ", input_data)

    future = torch.jit.fork(generate_random_input)
    print("Created Fork: ", future)

    result = torch.jit.wait(future)
    print("Result: ", result)

    torch.jit.wait(future)  # Wait for the fork to complete
    print("Fork Completed")

if __name__ == "__main__":
    start_time = time.time()
    main()
    print("Time Taken: ", time.time() - start_time)