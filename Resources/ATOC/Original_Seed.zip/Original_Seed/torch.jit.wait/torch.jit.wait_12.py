import torch
import random

# Generate random input data
def generate_random_data():
    return torch.randn(1, 3, 224, 224)

# Generate input data
input_data = generate_random_data()

# Call the API torch.jit.wait
future = torch.jit.fork(input_data)
result = torch.jit.wait(future)

# Print the result
print(result)