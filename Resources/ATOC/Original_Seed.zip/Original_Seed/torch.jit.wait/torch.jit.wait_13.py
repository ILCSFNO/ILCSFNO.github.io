import torch
import random
import time

def generate_random_input_data():
    return [random.random() for _ in range(100)]

def main():
    input_data = generate_random_input_data()
    print("Input Data:", input_data)

    # Create a torch.jit.Future object
    future = torch.jit.fork(generate_random_input_data)

    # Wait for the future to complete
    result = torch.jit.wait(future)

    print("Result:", result)

if __name__ == "__main__":
    start_time = time.time()
    main()
    print("Execution Time:", time.time() - start_time)