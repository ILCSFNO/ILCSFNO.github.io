import torch
import torch.jit
import random
import time

# Generate random input data
class RandomData:
    def __init__(self):
        self.x = random.randint(1, 100)
        self.y = random.randint(1, 100)

    def __call__(self):
        return self.x, self.y

# Generate input data
data = RandomData()

# Create a future using torch.jit.fork
future = torch.jit.fork(data)

# Call the API torch.jit.wait
result = torch.jit.wait(future)

# Print the result
print(result)