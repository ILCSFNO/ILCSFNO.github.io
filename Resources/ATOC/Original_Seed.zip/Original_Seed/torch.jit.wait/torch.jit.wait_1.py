import torch
import random
import time

def generate_random_data():
    return [random.randint(0, 100) for _ in range(10)]

def main():
    # Generate input data
    data = generate_random_data()

    # Create a torch.jit.Future and call torch.jit.wait
    future = torch.jit.fork(generate_random_data)
    result = torch.jit.wait(future)
    print(result)

if __name__ == "__main__":
    main()