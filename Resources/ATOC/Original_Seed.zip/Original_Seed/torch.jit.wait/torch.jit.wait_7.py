import torch
import random
import time

def generate_random_input_data():
    input_data = []
    for _ in range(10):
        input_data.append(random.randint(0, 100))
    return input_data

def generate_future():
    return torch.jit.Future(int)

def main():
    input_data = generate_random_input_data()
    future = generate_future()
    print("Input Data: ", input_data)
    print("Future: ", future)
    result = torch.jit.wait(future)
    print("Result: ", result)

if __name__ == "__main__":
    start_time = time.time()
    main()
    print("Time Taken: ", time.time() - start_time)