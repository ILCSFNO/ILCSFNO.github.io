import torch
import random
import time

def generate_random_data():
    return [random.random() for _ in range(100)]

def main():
    torch.set_default_tensor_type('torch.DoubleTensor')

    data = generate_random_data()
    print("Generated Data: ", data)

    future = torch.jit.fork(generate_random_data)
    torch.jit.wait(future)
    result = future.result()
    print("Result: ", result)

if __name__ == "__main__":
    main()