import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    random_data = np.random.rand(10, 10)
    tensor = torch.tensor(random_data, dtype=torch.float32)
    return tensor

# Generate input data
tensor = generate_random_data()

# Call the API torch.Tensor.remainder_
tensor.remainder_(torch.tensor(10))

print(tensor)