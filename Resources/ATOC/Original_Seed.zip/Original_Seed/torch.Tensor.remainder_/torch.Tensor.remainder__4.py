import torch
import numpy as np
import random

def generate_random_input():
    return torch.randn(10, 5), torch.randint(1, 10, (10, 5))

def main():
    input_data, divisor = generate_random_input()
    
    # Call the API
    input_data.remainder_(divisor)
    
    # Print the result
    print(input_data)

if __name__ == "__main__":
    main()