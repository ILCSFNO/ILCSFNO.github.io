import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

dividend = torch.randn(3, 3, dtype=torch.float32)
divisor = torch.randn(3, 3, dtype=torch.float32)

# Generate random remainder values
remainder_values = torch.randn(3, 3, dtype=torch.float32)

# Create tensors
dividend_tensor = torch.tensor(dividend)
divisor_tensor = torch.tensor(divisor)
remainder_tensor = torch.tensor(remainder_values)

# Call the API torch.Tensor.remainder_
dividend_tensor.remainder_(divisor_tensor)
print("Dividend Tensor: ", dividend_tensor)
print("Divisor Tensor: ", divisor_tensor)
print("Remainder Tensor: ", remainder_tensor)