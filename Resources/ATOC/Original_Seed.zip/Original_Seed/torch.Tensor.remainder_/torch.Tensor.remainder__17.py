import torch
import numpy as np
import random

# Generate random input data
def generate_random_data():
    a = np.random.rand(10, 10)
    b = np.random.rand(10, 10)
    return torch.from_numpy(a), torch.from_numpy(b)

# Generate input data
a, b = generate_random_data()

# Call the API torch.Tensor.remainder_
a.remainder_(b)