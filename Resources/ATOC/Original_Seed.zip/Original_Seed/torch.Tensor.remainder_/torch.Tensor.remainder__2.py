import torch
import random

def generate_input_data():
    return torch.randn(10, 10)

def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Generate random divisor
    divisor = random.randint(1, 10)
    
    # Call the remainder_ API
    input_data.remainder_(divisor)
    
    # Print the result
    print(input_data)

if __name__ == "__main__":
    main()