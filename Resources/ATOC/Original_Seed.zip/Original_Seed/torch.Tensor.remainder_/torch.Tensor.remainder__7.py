import torch
import random

# Generate random input data
def generate_random_data():
    a = random.randint(1, 100)
    b = random.randint(1, 100)
    divisor = random.randint(1, 100)
    return torch.tensor([a, b, divisor])

# Generate input data
data = generate_random_data()

# Call the API torch.Tensor.remainder_
data.remainder_(divisor=torch.tensor(10))
print(data)