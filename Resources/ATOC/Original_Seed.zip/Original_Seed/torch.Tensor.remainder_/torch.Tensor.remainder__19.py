import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(10, 10).astype(np.float32)
tensor = torch.from_numpy(input_data)

# Generate random divisor
divisor = torch.randn(1, 10).float() * 100 + 1

# Call the API torch.Tensor.remainder_
tensor.remainder_(divisor)

# Print the result
print(tensor)