import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    divisor = random.randint(1, 100)
    dividend = random.randint(1, 1000)
    tensor = torch.tensor(dividend)
    return tensor, divisor

# Generate input data
tensor, divisor = generate_input_data()

# Call the API torch.Tensor.remainder_
tensor.remainder_(divisor)

print("Input Tensor: ", tensor)
print("Input Divisor: ", divisor)