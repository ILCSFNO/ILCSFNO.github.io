import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    num_elements = random.randint(1, 10)
    input_tensor = torch.randn(num_elements)
    return input_tensor

# Generate random divisor
def generate_divisor():
    divisor = random.randint(1, 100)
    return divisor

# Call the API
def call_api():
    input_tensor = generate_input_data()
    divisor = generate_divisor()
    print("Input Tensor:", input_tensor)
    print("Divisor:", divisor)
    input_tensor.remainder_(divisor)

call_api()