import torch
import numpy as np
import random

def generate_random_data():
    # Generate random numbers
    a = random.randint(0, 100)
    b = random.randint(0, 100)
    c = random.randint(0, 100)

    # Generate input data
    x = torch.tensor([a, b, c])

    # Generate divisor
    divisor = torch.tensor([10, 20, 30])

    return x, divisor

def main():
    x, divisor = generate_random_data()

    # Call the API torch.Tensor.remainder_
    x.remainder_(divisor)

    # Print the result
    print(x)

if __name__ == "__main__":
    main()