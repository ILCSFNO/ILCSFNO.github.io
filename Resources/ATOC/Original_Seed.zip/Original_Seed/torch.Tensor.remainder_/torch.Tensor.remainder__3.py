import torch
import torch.nn.functional as F
import numpy as np
import random

def generate_input_data():
    return torch.randn(10, 10)

def main():
    tensor = generate_input_data()
    divisor = torch.randint(1, 11, (tensor.shape[0],), dtype=torch.int64)
    result = tensor.remainder_(divisor)
    print(result)

if __name__ == "__main__":
    main()