import torch
import random
import numpy as np

# Generate random input data
random_tensor = torch.randn(10, 10)

# Generate random divisor
random_divisor = torch.randint(2, 11, (1,))

# Call the API torch.Tensor.remainder_
random_tensor.remainder_(random_divisor)

# Print the result
print(random_tensor)