import torch
import numpy as np
import random

# Generate random input data
random.seed(0)
divisor = torch.tensor(random.randint(1, 100), dtype=torch.long)
input_data = torch.tensor(np.random.randint(0, 100, size=(1, 1)), dtype=torch.long)

# Generate random output data
output_data = torch.tensor(np.random.randint(0, 100, size=(1, 1)), dtype=torch.long)

# Call the API torch.Tensor.remainder_
input_data.remainder_(divisor)

print("Input Data: ", input_data)
print("Output Data: ", output_data)