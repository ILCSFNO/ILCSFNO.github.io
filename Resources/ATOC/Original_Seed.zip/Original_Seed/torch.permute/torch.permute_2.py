import torch
import numpy as np
import random

# Generate input data with random shape
input_shape = (random.randint(1, 5), random.randint(1, 5), random.randint(1, 5))
input_tensor = torch.randn(input_shape)

# Generate random permutation of dimensions
dims = tuple(sorted(random.sample(range(input_tensor.dim()), input_tensor.dim())))

# Call the API torch.permute
output_tensor = torch.permute(input_tensor, dims)

# Print the shape of the input and output tensors
print("Input Tensor Shape:", input_tensor.size())
print("Output Tensor Shape:", output_tensor.size())