import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    return torch.randn(2, 3, 5)

input_data = generate_input_data()

# Generate random dimensions
dims = tuple(random.randint(0, input_data.dim() - 1) for _ in range(input_data.dim()))

# Call the API torch.permute
result = torch.permute(input_data, dims)

# Print the size of the result
print(result.size())