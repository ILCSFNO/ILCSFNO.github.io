import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
torch.manual_seed(0)
random.seed(0)

input_data = torch.randn(2, 3, 5)

# Generate random dims
dims = tuple(random.randint(0, input_data.dim() - 1) for _ in range(input_data.dim()))

# Call the API torch.permute
output = torch.permute(input_data, dims)

# Print the output
print("Input Data:")
print(input_data.size())
print("Output Data:")
print(output.size())
print("Input Data Shape:")
print(input_data.shape)
print("Output Data Shape:")
print(output.shape)