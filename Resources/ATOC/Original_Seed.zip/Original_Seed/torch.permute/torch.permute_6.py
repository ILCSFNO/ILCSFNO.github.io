import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

# Create a 3D tensor
input_tensor = torch.randn(2, 3, 5)

# Generate random dimensions
dims = tuple(random.randint(0, input_tensor.dim() - 1) for _ in range(input_tensor.dim()))

# Call the API torch.permute
permuted_tensor = torch.permute(input_tensor, dims)

# Print the original tensor size
print("Original tensor size:", input_tensor.size())

# Print the permuted tensor size
print("Permuted tensor size:", permuted_tensor.size())