import torch
import numpy as np

# Generate input data
input_data = torch.randn(2, 3, 5)

# Call the API torch.permute
permuted_data = torch.permute(input_data, (2, 0, 1))

# Print the original and permuted data
print("Original Data:")
print(input_data.size())
print(input_data)

print("\nPermutated Data:")
print(permuted_data.size())
print(permuted_data)