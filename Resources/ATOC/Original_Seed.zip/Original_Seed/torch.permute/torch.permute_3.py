import torch
import numpy as np
import random

# Generate random input data
def generate_random_input():
    return torch.randn(2, 3, 5)

# Generate random dimensions
def generate_random_dims():
    return (random.randint(0, 5),) + (random.randint(0, 3),) + (random.randint(0, 2),)

# Main function
def main():
    # Generate random input data
    input_data = generate_random_input()
    
    # Generate random dimensions
    dims = generate_random_dims()
    
    # Call the API torch.permute
    permuted_input = torch.permute(input_data, dims)
    
    print("Original Input Shape:", input_data.size())
    print("Permuted Input Shape:", permuted_input.size())

if __name__ == "__main__":
    main()