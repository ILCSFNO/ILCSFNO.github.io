import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(2, 3, 5)

# Generate random dimensions
dims = tuple(random.randint(0, 3) for _ in range(len(input_data.shape)))

# Call the API torch.permute
output = torch.permute(input_data, dims)

# Print the output shape
print(output.size())