import torch
import numpy as np
import random

# Generate random input data
def generate_random_input():
    shape = (5, 3, 2)
    input_tensor = torch.randn(*shape)
    return input_tensor

# Generate random dimensions
def generate_random_dims():
    return tuple(random.randint(0, len(shape) - 1) for _ in range(len(shape)))

# Generate code
input_tensor = generate_random_input()
dims = generate_random_dims()

code = f"""
import torch

# Generate random input data
def generate_random_input():
    shape = (5, 3, 2)
    input_tensor = torch.randn(*shape)
    return input_tensor

# Generate random dimensions
def generate_random_dims():
    return tuple(random.randint(0, len(shape) - 1) for _ in range(len(shape)))

# Call the API torch.permute
input_tensor = generate_random_input()
dims = generate_random_dims()

permuted_tensor = torch.permute(input_tensor, dims)
print(permuted_tensor.size())
"""
print(code)