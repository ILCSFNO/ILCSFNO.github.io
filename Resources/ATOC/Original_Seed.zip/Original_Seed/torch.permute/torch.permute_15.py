import torch
import numpy as np

# Generate input data with a random 3D tensor
input_data = torch.randn(2, 3, 5)

# Define the dimensions to be permuted
dims = (2, 0, 1)

# Call the torch.permute API
permuted_data = torch.permute(input_data, dims)

# Print the size of the original and permuted tensors
print("Original Tensor Size:", input_data.size())
print("Permuted Tensor Size:", permuted_data.size())