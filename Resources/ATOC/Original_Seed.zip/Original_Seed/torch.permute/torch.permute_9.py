import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)
random_number = np.random.rand(2, 3, 5)
input_data = torch.tensor(random_number, dtype=torch.float32)

# Generate random dims tuple
dims = tuple(random.randint(0, len(input_data.shape)) for _ in range(len(input_data.shape)))

# Call the API torch.permute
permuted_input = torch.permute(input_data, dims)

# Print the original and permuted input data
print("Original Input Data:")
print(input_data)
print("\nPermuted Input Data:")
print(permuted_input)