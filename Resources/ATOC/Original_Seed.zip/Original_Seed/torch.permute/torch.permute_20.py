import torch
import numpy as np

# Generate input data
input_data = torch.randn(2, 3, 5)

# Call the API torch.permute
permuted_input = torch.permute(input_data, (2, 0, 1))

# Print the original size of the input data
print("Original Size of Input Data:", input_data.size())

# Print the size of the permuted input data
print("Size of Permuted Input Data:", permuted_input.size())

# Print the permuted input data
print("Permuted Input Data:\n", permuted_input)