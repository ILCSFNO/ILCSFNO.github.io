import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    return torch.randn(3, 2, 5)

# Generate random dimensions
def generate_random_dims():
    return tuple(random.randint(0, 5) for _ in range(len(torch.randn(3, 2, 5).shape)))

# Call the API torch.permute
def main():
    input_data = generate_input_data()
    dims = generate_random_dims()
    permuted_input = torch.permute(input_data, dims)
    print(permuted_input)

if __name__ == "__main__":
    main()