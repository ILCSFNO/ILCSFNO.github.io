import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

x = torch.randn(2, 3, 5)

# Permute the dimensions
dims = random.sample(range(x.dim()), x.dim())
permuted_x = torch.permute(x, dims)

# Print the original tensor size
print("Original Tensor Size:", x.size())

# Print the permuted tensor size
print("Permuted Tensor Size:", permuted_x.size())