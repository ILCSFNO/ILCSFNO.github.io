import torch
import numpy as np
import random

# Generate input data
def generate_input_data():
    shape = (2, 3, 5)
    data = np.random.rand(*shape)
    return torch.tensor(data)

# Call the API torch.permute
def main():
    input_data = generate_input_data()
    dims = (2, 0, 1)
    permuted_input = torch.permute(input_data, dims)
    print("Original Tensor Shape:", input_data.size())
    print("Permuted Tensor Shape:", permuted_input.size())

if __name__ == "__main__":
    main()