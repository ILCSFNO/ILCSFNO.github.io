import torch
import numpy as np

# Generate input data
torch.manual_seed(0)
np.random.seed(0)

x = torch.randn(2, 3, 5)

# Call the API torch.permute
permuted_x = torch.permute(x, (2, 0, 1)).detach().numpy()

print("Original tensor size:", x.size())
print("Original tensor data:", x.detach().numpy())
print("Permuted tensor size:", permuted_x.shape)
print("Permuted tensor data:\n", permuted_x)