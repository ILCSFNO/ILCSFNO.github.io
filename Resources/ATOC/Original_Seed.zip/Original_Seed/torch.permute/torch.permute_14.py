import torch
import numpy as np

# Generate random input data
np.random.seed(0)
torch.manual_seed(0)
input_data = torch.randn(2, 3, 5)

# Call the API torch.permute
permuted_data = torch.permute(input_data, (2, 0, 1))

# Print the sizes of the original and permuted data
print("Original Data Size:", input_data.size())
print("Permuted Data Size:", permuted_data.size())