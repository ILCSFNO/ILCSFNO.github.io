import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_data = torch.randn(2, 3, 5)

# Randomly select dimensions to permute
dims = tuple(random.sample(range(input_data.dim()), random.randint(1, input_data.dim())))

# Call the API torch.permute
output = torch.permute(input_data, dims)

# Print the size of the output tensor
print(output.size())