import torch
import numpy as np
import random

# Generate input data
def generate_input_data():
    shape = (2, 3, 5)
    input_data = torch.randn(shape)
    return input_data

# Generate input data randomly
input_data = generate_input_data()

# Call the API torch.permute
def call_permute_api(input_data):
    dims = (2, 0, 1)
    permuted_input = torch.permute(input_data, dims)
    return permuted_input

permuted_input = call_permute_api(input_data)

print(permuted_input)