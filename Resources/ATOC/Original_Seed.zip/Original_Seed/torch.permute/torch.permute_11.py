import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_data = torch.randn(2, 3, 5)

# Generate random dimensions
dims = tuple(random.randint(0, len(input_data.size()) - 1) for _ in range(len(input_data.size())))

# Call the API torch.permute
output = torch.permute(input_data, dims)

print("Input shape:", input_data.size())
print("Output shape:", output.size())
print("Output tensor:\n", output)