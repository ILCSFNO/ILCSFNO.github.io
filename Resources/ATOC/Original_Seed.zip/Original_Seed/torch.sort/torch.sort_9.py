import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
input_data = torch.randn(10, 4)

# Call the API torch.sort
sorted_values, indices = torch.sort(input_data, dim=-1, descending=False, stable=False)

print("Sorted Values: ", sorted_values)
print("Indices: ", indices)