import torch

# Generate input data
input_data = torch.randn(10, 4)

# Call the API torch.sort
sorted_values, indices = torch.sort(input_data, dim=-1, descending=False, stable=False)

print("Sorted Values:")
print(sorted_values)
print("\nIndices:")
print(indices)

# Call the API torch.sort with descending=True
sorted_values, indices = torch.sort(input_data, dim=-1, descending=True, stable=False)

print("\nSorted Values (Descending):")
print(sorted_values)
print("\nIndices:")
print(indices)

# Call the API torch.sort with stable=True
sorted_values, indices = torch.sort(input_data, dim=-1, descending=False, stable=True)

print("\nSorted Values (Stable):")
print(sorted_values)
print("\nIndices:")
print(indices)