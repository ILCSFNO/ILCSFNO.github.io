import torch

# Generate input data
x = torch.randn(3, 4)

# Call the API torch.sort
sorted, indices = torch.sort(x, dim=-1, descending=False, stable=False)

print("Sorted values: ", sorted)
print("Indices: ", indices)