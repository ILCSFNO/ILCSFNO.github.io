import torch
import numpy as np
import random

# Generate input data
np.random.seed(0)
random.seed(0)
x = torch.tensor(np.random.rand(3, 4))

# Call the API torch.sort
sorted, indices = torch.sort(x, dim=-1, descending=False, stable=False)