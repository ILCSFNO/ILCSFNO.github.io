import torch
import random

# Generate random input data
x = torch.tensor(random.sample(range(100), 10))

# Call the API torch.sort
sorted, indices = torch.sort(x)

print("Sorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)