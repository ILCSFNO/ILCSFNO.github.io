import torch
import numpy as np

# Generate input data
np.random.seed(0)
x = np.random.rand(10, 4)

# Convert numpy array to torch tensor
x_tensor = torch.from_numpy(x)

# Call the API torch.sort
sorted, indices = torch.sort(x_tensor, dim=-1, descending=False, stable=False)

# Print the results
print("Sorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)