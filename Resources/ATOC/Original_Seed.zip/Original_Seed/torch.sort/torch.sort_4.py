import torch

# Generate input data with a random tensor of shape (10, 3)
input_data = torch.randn(10, 3)

# Call the API torch.sort
sorted_data, indices = torch.sort(input_data, dim=-1, descending=False, stable=False)

# Print the sorted values and indices
print("Sorted Values:")
print(sorted_data)
print("\nIndices:")
print(indices)

# Call the API torch.sort with descending=True
sorted_data_desc, indices_desc = torch.sort(input_data, dim=-1, descending=True, stable=False)

# Print the sorted values and indices
print("\nSorted Values (Descending):")
print(sorted_data_desc)
print("\nIndices (Descending):")
print(indices_desc)

# Call the API torch.sort with stable=True
sorted_data_stable, indices_stable = torch.sort(input_data, dim=-1, descending=False, stable=True)

# Print the sorted values and indices
print("\nSorted Values (Stable):")
print(sorted_data_stable)
print("\nIndices (Stable):")
print(indices_stable)