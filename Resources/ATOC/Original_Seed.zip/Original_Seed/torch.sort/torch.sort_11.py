import torch
import numpy as np
import random

# Generate input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)
x = torch.randn(3, 4)

# Call the API torch.sort
sorted, indices = torch.sort(x, dim=-1, descending=False)

print("Sorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)

# Generate random input data
y = torch.randn(5, 5)

# Call the API torch.sort
sorted, indices = torch.sort(y, dim=-1, descending=False)

print("\nSorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)

# Generate random input data
z = torch.tensor([0, 1] * 9)

# Call the API torch.sort
sorted, indices = z.sort()

print("\nSorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)

# Call the API torch.sort with stable=True
sorted, indices = z.sort(stable=True)

print("\nSorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)