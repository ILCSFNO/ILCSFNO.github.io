import torch
import numpy as np
import random

# Generate input data
x = torch.randn(3, 4)

# Call the API torch.sort
sorted, indices = torch.sort(x, descending=False)

# Print the result
print("Sorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)

# Generate new input data
y = torch.tensor([0, 1] * 9)

# Call the API torch.sort
sorted, indices = torch.sort(y, stable=True)

# Print the result
print("\nSorted tensor:")
print(sorted)
print("\nIndices tensor:")
print(indices)