import torch

# Generate input data
import numpy as np
x = torch.tensor(np.random.rand(5, 4))

# Call the API torch.sort
sorted, indices = torch.sort(x, descending=False, stable=False)
print("Sorted tensor: ", sorted)
print("Indices tensor: ", indices)