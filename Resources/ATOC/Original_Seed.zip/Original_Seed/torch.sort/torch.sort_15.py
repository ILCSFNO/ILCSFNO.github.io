import torch
import numpy as np

# Generate random input data
np.random.seed(0)
x = torch.tensor(np.random.rand(10, 4))

# Call the API torch.sort
sorted, indices = torch.sort(x, descending=False)
print("Sorted tensor: ", sorted)
print("Indices tensor: ", indices)