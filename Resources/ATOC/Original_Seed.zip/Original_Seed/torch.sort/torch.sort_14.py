import torch

# Generate input data
import numpy as np
np.random.seed(0)
input_data = np.random.rand(10, 4)

# Convert input data to PyTorch tensor
input_tensor = torch.from_numpy(input_data).float()

# Call the API torch.sort
sorted_values, indices = torch.sort(input_tensor, descending=False)

# Print the results
print("Sorted Values:")
print(sorted_values)
print("\nIndices:")
print(indices)