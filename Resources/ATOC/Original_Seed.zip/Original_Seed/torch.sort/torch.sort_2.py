import torch
import random
import numpy as np

# Generate input data
x = torch.randn(3, 4)

# Call the API torch.sort
sorted_x, indices = torch.sort(x, descending=False)

# Print the results
print("Sorted tensor:")
print(sorted_x)
print("\nIndices tensor:")
print(indices)

# Generate another set of input data
x = torch.tensor([0, 1] * 9)

# Call the API torch.sort
sorted_x, indices = torch.sort(x)

# Print the results
print("\nSorted tensor:")
print(sorted_x)
print("\nIndices tensor:")
print(indices)

# Call the API torch.sort with stable=True
sorted_x, indices = torch.sort(x, stable=True)

# Print the results
print("\nSorted tensor:")
print(sorted_x)
print("\nIndices tensor:")
print(indices)