import torch
import random

# Generate input data
x = torch.tensor([random.uniform(-10, 10) for _ in range(10)])

# Call the API torch.sort
sorted_x, indices = torch.sort(x)

# Print the results
print("Sorted tensor:")
print(sorted_x)
print("Indices tensor:")
print(indices)