import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = np.random.rand(10, 4)
input_tensor = torch.tensor(random_data, dtype=torch.float32)

# Call the API torch.sort
sorted_values, indices = torch.sort(input_tensor, dim=-1, descending=False, stable=False)
print("Sorted values:", sorted_values)
print("Indices:", indices)