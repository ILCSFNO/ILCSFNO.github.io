import torch

# Generate random input data
import random
input_data = torch.randn(10, 4)

# Call the torch.sort API
sorted_data, indices = torch.sort(input_data, descending=False)

# Print the results
print("Sorted Data:")
print(sorted_data)
print("\nIndices:")
print(indices)

# Call the torch.sort API with stable=True
sorted_data_stable, indices_stable = torch.sort(input_data, descending=False, stable=True)

# Print the results
print("\nSorted Data (Stable):")
print(sorted_data_stable)
print("\nIndices (Stable):")
print(indices_stable)