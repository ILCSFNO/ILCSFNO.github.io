import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = torch.randn(5, 3)

# Call the API torch.Tensor.arctanh
output_data = input_data.arctanh()

# Print the output
print(output_data)