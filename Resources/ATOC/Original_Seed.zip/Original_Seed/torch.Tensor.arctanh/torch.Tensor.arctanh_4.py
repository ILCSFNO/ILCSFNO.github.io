import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(10, 10)

# Convert input data to PyTorch tensor
input_tensor = torch.from_numpy(input_data)

# Call the arctanh API on the tensor
output = input_tensor.arctanh()

# Print the output
print(output)