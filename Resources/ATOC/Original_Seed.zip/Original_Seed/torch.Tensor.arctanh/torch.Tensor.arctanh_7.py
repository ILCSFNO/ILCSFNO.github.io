import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(5, 3)

# Generate random labels
labels = torch.randn(5, 3)

# Call the API torch.Tensor.arctanh
output = input_data.arctanh()

# Print the output
print(output)