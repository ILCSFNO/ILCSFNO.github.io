import torch
import torch.nn as nn
import numpy as np
import random

def generate_random_data():
    return torch.randn(1, 1)

def main():
    input_data = generate_random_data()
    output = torch.Tensor(arctanh(input_data))
    print(output)

if __name__ == "__main__":
    main()