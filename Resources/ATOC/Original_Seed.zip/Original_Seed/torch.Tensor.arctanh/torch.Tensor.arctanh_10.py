import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

input_data = torch.randn(5, 3)

# Call the API torch.Tensor.arctanh
output_data = input_data.arctanh()

print("Input Data: ", input_data)
print("Output Data: ", output_data)