import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(10, 5)

# Convert input data to PyTorch tensor
input_tensor = torch.from_numpy(input_data)

# Call the arctanh function on the input tensor
output_tensor = input_tensor.arctanh()

# Print the output tensor
print(output_tensor)