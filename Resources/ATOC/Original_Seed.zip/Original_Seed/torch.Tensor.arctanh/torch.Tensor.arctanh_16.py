import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = np.random.rand(10, 10)

# Convert numpy array to torch tensor
tensor_data = torch.from_numpy(random_data)

# Calculate arctanh of the tensor data
result = tensor_data.arctanh()

# Print the result
print(result)