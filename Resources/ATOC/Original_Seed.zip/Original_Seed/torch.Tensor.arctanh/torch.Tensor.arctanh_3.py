import torch
import numpy as np
import random

# Generate random input data
random_input = np.random.rand(5, 10)

# Convert numpy array to torch tensor
random_input_tensor = torch.from_numpy(random_input)

# Call the arctanh function
result = random_input_tensor.arctanh()

# Print the result
print(result)