import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = torch.tensor(np.random.rand(10, 5))

# Call the API torch.Tensor.arctanh
output = input_data.arctanh()
print(output)