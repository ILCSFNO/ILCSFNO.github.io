import torch
import numpy as np
import random

def generate_random_input_data(size):
    return torch.randn(size)

def generate_random_labels(size):
    return torch.randint(0, 2, (size,))

def main():
    input_size = 10
    label_size = 10

    input_data = generate_random_input_data(input_size)
    labels = generate_random_labels(label_size)

    # Applying arctanh function
    result = input_data.tensor.arctanh()

    print("Input Data:")
    print(input_data)
    print("\nLabels:")
    print(labels)
    print("\nResult after applying arctanh:")
    print(result)

if __name__ == "__main__":
    main()