import torch
import numpy as np

# Generate input data
input_data = torch.tensor(np.random.rand(10, 5))

# Call the API torch.Tensor.arctanh
output = input_data.arctanh()

# Print the output
print(output)