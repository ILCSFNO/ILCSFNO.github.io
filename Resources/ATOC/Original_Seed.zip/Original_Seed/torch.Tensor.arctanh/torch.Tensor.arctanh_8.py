import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

input_data = torch.randn(5, 5)

# Call the API torch.Tensor.arctanh
output_data = input_data.arctanh()

# Print the input and output data
print("Input Data:")
print(input_data)
print("\nOutput Data:")
print(output_data)