import torch
import numpy as np
import random

# Generate random input data
random_input_data = np.random.rand(5, 3)

# Create a PyTorch tensor from the input data
input_tensor = torch.from_numpy(random_input_data)

# Call the arctanh API
output_tensor = input_tensor.arctanh()

# Print the output tensor
print(output_tensor)