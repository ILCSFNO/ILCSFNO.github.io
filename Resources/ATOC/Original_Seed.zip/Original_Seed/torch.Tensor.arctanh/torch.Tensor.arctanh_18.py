import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(10, 5)

# Convert input data to a PyTorch tensor
tensor = torch.from_numpy(input_data)

# Call the arctanh function on the tensor
arctanh_result = tensor.arctanh()

# Print the result
print(arctanh_result)