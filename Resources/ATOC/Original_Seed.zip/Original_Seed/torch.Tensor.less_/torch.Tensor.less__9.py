import torch
import torch.randn
import torch.randn_like

def generate_input_data():
    shape = (1000,)
    data = torch.randn(shape)
    return data

def main():
    data = generate_input_data()
    other_data = torch.randn_like(data)
    result = data.less_(other_data)
    print(result)

if __name__ == "__main__":
    main()