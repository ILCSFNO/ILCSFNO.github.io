import torch
import random
import numpy as np

def generate_random_data():
    return torch.tensor([random.randint(0, 100) for _ in range(10)])

def main():
    # Generate random input data
    input_data = generate_random_data()
    print("Input Data: ", input_data)

    # Generate random other tensor
    other_tensor = torch.tensor([random.randint(0, 100) for _ in range(10)])
    print("Other Tensor: ", other_tensor)

    # Call the less_ API
    result = input_data.less_(other_tensor)
    print("Result: ", result)

if __name__ == "__main__":
    main()