import torch
import random

# Generate random input data
def generate_random_data():
    a = torch.randn(5, 3)
    b = torch.randn(5, 3)
    return a, b

a, b = generate_random_data()

# Call the API torch.Tensor.less_
print("Original tensors:")
print("a:", a)
print("b:", b)

print("\nTensor less_:")
print(a.less_(b))

print("\nOriginal tensors (not modified):")
print("a:", a)
print("b:", b)