import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)
torch.cuda.manual_seed_all(0)

input_tensor = torch.randn(10, 10)

# Generate random tensor for comparison
other_tensor = torch.randn(10, 10)

# Generate random scalar for comparison
scalar = torch.randn(1)

# Call the API torch.Tensor.less_
input_tensor.less_(other_tensor)
print(input_tensor)
print(input_tensor < scalar)