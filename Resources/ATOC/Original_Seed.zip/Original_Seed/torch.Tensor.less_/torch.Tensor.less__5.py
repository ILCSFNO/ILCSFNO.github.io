import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

# Generate random tensor
tensor = torch.randn(5, 5)

# Generate random tensor for comparison
tensor_less = torch.randn(5, 5)

# Call the API torch.Tensor.less_
tensor.less_(tensor_less)

print(tensor)