import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random

# Generate random input data
def generate_random_input():
    a = torch.randn(5, 5)
    b = torch.randn(5, 5)
    return a, b

# Generate input data
a, b = generate_random_input()

# Call the API torch.Tensor.less_
a.less_(b)

# Print the result
print(a)