import torch
import numpy as np

# Generate random input data
np.random.seed(0)
data = torch.randn(5, 3)
other_data = torch.randn(5, 3)

# Call the API torch.Tensor.less_
result = data.less_(other_data)

print(result)