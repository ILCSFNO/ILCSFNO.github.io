import torch
import numpy as np

# Generate random input data
np.random.seed(0)
tensor1 = torch.randn(10, 10)
tensor2 = torch.randn(10, 10)

# Generate random other tensor
other_tensor = torch.randn(10, 10)

# Call the API torch.Tensor.less_
tensor1.less_(other_tensor)

# Print the result
print(tensor1)