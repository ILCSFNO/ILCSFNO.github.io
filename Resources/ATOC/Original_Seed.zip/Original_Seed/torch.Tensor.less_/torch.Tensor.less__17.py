import torch
import random

def generate_random_tensor(shape):
    return torch.randn(*shape)

def generate_random_input_data():
    return generate_random_tensor((1000, 5))

# Generate input data
input_data = generate_random_input_data()

# Generate random tensor for comparison
tensor_to_compare = generate_random_tensor((1000, 5))

# Create a new tensor and in-place compare with the tensor
result = input_data.less_(tensor_to_compare)

print(result)