import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = np.random.randint(2, size=(10, 10))

# Create PyTorch tensors from the input data
input_tensor = torch.from_numpy(random_data)

# Call the bitwise_and_ function
output_tensor = input_tensor.bitwise_and_

# Print the output tensor
print(output_tensor)