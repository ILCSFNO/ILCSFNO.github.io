import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    a = torch.randn(10, 10)
    b = torch.randn(10, 10)
    return a, b

a, b = generate_input_data()

# Call the API torch.Tensor.bitwise_and_
a.bitwise_and_(b)
print(a)
print(b)