import torch
import numpy as np
import random

def generate_random_data():
    return torch.tensor([random.randint(0, 100) for _ in range(10)])

def main():
    # Generate random data
    data = generate_random_data()

    # Call the bitwise_and_ API
    data.bitwise_and_(data)

    # Print the result
    print(data)

if __name__ == "__main__":
    main()