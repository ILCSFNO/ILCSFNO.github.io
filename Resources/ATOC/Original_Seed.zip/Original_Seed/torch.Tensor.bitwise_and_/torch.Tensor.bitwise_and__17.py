import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    a = torch.randn(5, 5)
    b = torch.randn(5, 5)
    return a, b

# Generate input data
a, b = generate_input_data()

# Call the API torch.Tensor.bitwise_and_
# In-place version of bitwise_and()
a.bitwise_and_(b)

print(a)
print(b)