import torch
import numpy as np
import random

def generate_random_data():
    # Generate random binary tensor
    shape = (2, 2)
    data = np.random.randint(2, size=shape)
    tensor = torch.tensor(data, dtype=torch.uint8)
    return tensor

def main():
    # Generate random input data
    tensor = generate_random_data()

    # Call the API torch.Tensor.bitwise_and_
    tensor.bitwise_and_(tensor)

    # Print the result
    print(tensor)

if __name__ == "__main__":
    main()