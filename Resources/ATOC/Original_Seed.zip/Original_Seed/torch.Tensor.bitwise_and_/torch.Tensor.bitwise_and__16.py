import torch
import random

def generate_random_tensor(size):
    return torch.randn(size)

def generate_random_input():
    tensor = generate_random_tensor((10,))
    tensor_1 = generate_random_tensor((10,))
    tensor_2 = generate_random_tensor((10,))

    input_data = {
        'tensor': tensor,
        'tensor_1': tensor_1,
        'tensor_2': tensor_2
    }

    return input_data

def main():
    input_data = generate_random_input()
    tensor = input_data['tensor']
    tensor_1 = input_data['tensor_1']
    tensor_2 = input_data['tensor_2']

    result = tensor.bitwise_and_(tensor_1)
    print(f"Input Data: {tensor}, {tensor_1}, {tensor_2}")
    print(f"Result: {result}")

if __name__ == "__main__":
    main()