import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_data = torch.randn(2, 2, dtype=torch.uint8)

# Call the API torch.Tensor.bitwise_and_
output_data = input_data.bitwise_and_(other=torch.tensor([[1, 2], [3, 4]], dtype=torch.uint8))

print("Input Data: ", input_data)
print("Output Data: ", output_data)