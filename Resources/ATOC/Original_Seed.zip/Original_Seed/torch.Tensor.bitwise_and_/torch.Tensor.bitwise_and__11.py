import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    # Randomly generate two tensors of size 10
    tensor1 = torch.randn(10)
    tensor2 = torch.randn(10)
    return tensor1, tensor2

# Generate input data
tensor1, tensor2 = generate_input_data()

# Call the API torch.Tensor.bitwise_and_
tensor1.bitwise_and_(tensor2)

print(tensor1)
print(tensor2)