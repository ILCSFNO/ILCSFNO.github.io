import torch
import random

# Generate random input data
def generate_random_input():
    a = torch.randint(0, 10, (3,))
    b = torch.randint(0, 10, (3,))
    return a, b

# Generate input data
a, b = generate_random_input()

# Call the API
a.bitwise_and_(b)

# Print the output
print(a)
print(b)