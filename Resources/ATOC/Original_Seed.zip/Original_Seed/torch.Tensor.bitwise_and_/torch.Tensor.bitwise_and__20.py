import torch
import torch.randn as randn

def generate_random_tensor(size):
    return torch.randn(size)

def generate_random_tensor_list(size, num_tensors):
    return [generate_random_tensor(size) for _ in range(num_tensors)]

# Generate input data
tensor_size = 3
tensor_list = generate_random_tensor_list(tensor_size, 2)

print("Input Tensor:")
print(tensor_list[0])
print("Input Tensor List:")
print(tensor_list)

# Call the API torch.Tensor.bitwise_and_
tensor_list[0] = tensor_list[0].bitwise_and_(tensor_list[1])

print("\nAfter bitwise_and_ operation:")
print(tensor_list[0])