import torch
import numpy as np

# Generate random input data
np.random.seed(0)
torch.random.seed(0)

tensor_size = 5
num_elements = 10
tensor = torch.randn(tensor_size, num_elements)
mask = torch.randint(0, 2, (tensor_size, num_elements), dtype=torch.bool)
source = torch.randint(0, 10, (tensor_size, num_elements))

# Call the API torch.Tensor.masked_scatter_
tensor.masked_scatter_(mask, source)

# Print the result
print(tensor)