import torch
import numpy as np

# Generate input data
np.random.seed(0)
torch.random.seed(0)
shape = (2, 5)
data = torch.randint(0, 10, shape=shape)
mask = torch.randint(0, 2, shape=shape)
source = torch.randint(0, 10, shape=shape)

# Call the API torch.Tensor.masked_scatter_
def main():
    tensor = data.clone()
    tensor.masked_scatter_(mask, source)
    print(tensor)

if __name__ == "__main__":
    main()