import torch

# Generate input data
def generate_input_data():
    self = torch.tensor([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]])
    mask = torch.tensor([[0, 0, 0, 1, 1], [1, 1, 0, 1, 1]], dtype=torch.bool)
    source = torch.tensor([[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]])
    return self, mask, source

# Call the API torch.Tensor.masked_scatter_
self, mask, source = generate_input_data()
self.masked_scatter_(mask, source)
print(self)