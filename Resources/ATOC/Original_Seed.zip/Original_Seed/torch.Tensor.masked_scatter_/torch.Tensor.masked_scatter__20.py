import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

# Generate a random boolean mask
mask = torch.tensor(np.random.choice([True, False], size=(5, 5)), dtype=torch.bool)

# Generate a random source tensor
source = torch.tensor(np.random.randint(0, 10, size=(5, 5)), dtype=torch.long)

# Call the API torch.Tensor.masked_scatter_
def test_masked_scatter():
    tensor = torch.zeros((5, 5), dtype=torch.long)
    tensor.masked_scatter_(mask, source)
    print(tensor)

test_masked_scatter()