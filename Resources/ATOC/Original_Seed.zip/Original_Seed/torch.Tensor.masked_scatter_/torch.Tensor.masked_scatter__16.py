import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = torch.tensor(np.random.randint(0, 10, (2, 5)), dtype=torch.int32)

# Generate random mask
mask = torch.tensor(np.random.choice([0, 1], (2, 5), p=[0.7, 0.3]), dtype=torch.bool)

# Generate random source tensor
source = torch.tensor(np.random.randint(0, 10, (2, 5)), dtype=torch.int32)

# Call the API torch.Tensor.masked_scatter_
output = input_data.masked_scatter_(mask, source)

print(output)