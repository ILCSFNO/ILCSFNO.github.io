import torch
import numpy as np
import random

# Generate input data
def generate_input_data():
    mask = torch.tensor([[0, 0, 0, 1, 1], [1, 1, 0, 1, 1]], dtype=torch.bool)
    source = torch.tensor([[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]])
    self = torch.tensor([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]])
    return mask, source, self

# Generate random input data
mask, source, self = generate_input_data()

# Call the API torch.Tensor.masked_scatter_
self.masked_scatter_(mask, source)
print(self)