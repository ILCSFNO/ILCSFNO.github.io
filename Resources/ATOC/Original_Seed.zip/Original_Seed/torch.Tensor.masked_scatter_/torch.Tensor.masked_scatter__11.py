import torch
import numpy as np

# Generate random input data
np.random.seed(0)
mask = torch.tensor(np.random.choice([True, False], size=(2, 5)), dtype=torch.bool)
source = torch.tensor(np.random.randint(0, 10, size=(2, 5)))

# Call the API torch.Tensor.masked_scatter_
self = torch.tensor(np.random.randint(0, 10, size=(2, 5)), dtype=torch.float32)
self.masked_scatter_(mask, source)

# Print the result
print(self)