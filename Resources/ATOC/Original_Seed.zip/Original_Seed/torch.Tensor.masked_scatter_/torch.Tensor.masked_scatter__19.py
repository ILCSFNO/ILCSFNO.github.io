import torch

# Generate random input data
random_tensor = torch.randn(2, 5)
mask = torch.randint(0, 2, (2, 5), dtype=torch.bool)
source = torch.randint(0, 10, (2, 5))

print("Original Tensor:")
print(random_tensor)

print("\nMask:")
print(mask)

print("\nSource Tensor:")
print(source)

# Call the API torch.Tensor.masked_scatter_
random_tensor.masked_scatter_(mask, source)

print("\nTensor after masked scatter:")
print(random_tensor)