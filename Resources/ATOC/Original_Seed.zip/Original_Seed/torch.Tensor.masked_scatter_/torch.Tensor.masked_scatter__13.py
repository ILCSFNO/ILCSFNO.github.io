import torch
import numpy as np

# Generate random input data
np.random.seed(0)
mask = torch.tensor(np.random.choice([True, False], size=(2, 5), p=[0.5, 0.5]), dtype=torch.bool)
source = torch.tensor(np.random.randint(0, 10, size=(2, 5)), dtype=torch.long)

# Create a tensor with some values
tensor = torch.tensor([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]], dtype=torch.long)

# Call the API torch.Tensor.masked_scatter_
tensor.masked_scatter_(mask, source)

print(tensor)