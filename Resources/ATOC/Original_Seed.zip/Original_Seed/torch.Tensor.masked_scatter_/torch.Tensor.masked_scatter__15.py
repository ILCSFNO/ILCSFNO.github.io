import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

def generate_random_data():
    mask = torch.tensor(np.random.choice([True, False], size=(2, 5), p=[0.1, 0.9]), dtype=torch.bool)
    source = torch.tensor(np.random.randint(0, 10, size=(2, 5)), dtype=torch.long)
    self = torch.tensor(np.random.randint(0, 10, size=(2, 5)), dtype=torch.long)
    return mask, source, self

mask, source, self = generate_random_data()

# Call the API torch.Tensor.masked_scatter_
self.masked_scatter_(mask, source)

print(self)