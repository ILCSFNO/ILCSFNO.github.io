import torch

# Generate random input data
torch.random.manual_seed(0)
input_data = torch.tensor([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]], dtype=torch.float32)

# Generate random mask
torch.random.manual_seed(0)
mask = torch.tensor([[0, 0, 0, 1, 1], [1, 1, 0, 1, 1]], dtype=torch.bool)

# Generate random source tensor
torch.random.manual_seed(0)
source = torch.tensor([[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]], dtype=torch.float32)

# Call the API torch.Tensor.masked_scatter_
input_data.masked_scatter_(mask, source)

print(input_data)