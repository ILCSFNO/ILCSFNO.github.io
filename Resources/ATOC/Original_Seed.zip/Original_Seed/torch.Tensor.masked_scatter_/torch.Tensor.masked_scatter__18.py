import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

def generate_random_tensor(rows, cols):
    return torch.tensor(np.random.rand(rows, cols))

def generate_random_mask(rows, cols):
    return torch.tensor(np.random.choice([0, 1], size=(rows, cols), p=[0.5, 0.5]))

def generate_random_source(rows, cols):
    return torch.tensor(np.random.rand(rows, cols))

rows = 5
cols = 5
tensor = generate_random_tensor(rows, cols)
mask = generate_random_mask(rows, cols)
source = generate_random_source(rows, cols)

print("Original Tensor:")
print(tensor)

print("\nMask:")
print(mask)

print("\nSource:")
print(source)

tensor.masked_scatter_(mask, source)

print("\nTensor after masked scatter:")
print(tensor)