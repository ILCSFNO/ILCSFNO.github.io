import torch

# Generate input data
input_tensor = torch.tensor([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]])
mask = torch.tensor([[0, 0, 0, 1, 1], [1, 1, 0, 1, 1]], dtype=torch.bool)
source = torch.tensor([[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]])

# Call the API torch.Tensor.masked_scatter_
input_tensor.masked_scatter_(mask, source)
print(input_tensor)