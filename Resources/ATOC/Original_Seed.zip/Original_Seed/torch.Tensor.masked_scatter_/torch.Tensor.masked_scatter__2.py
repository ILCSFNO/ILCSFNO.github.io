import torch
import numpy as np

# Generate random input data
np.random.seed(0)
torch.random.seed(0)
torch.manual_seed(0)

size = 2
num_elements = 5
input_data = torch.randint(0, 10, (size, num_elements))
print("Input Data:")
print(input_data)

mask = torch.randint(0, 2, (size, num_elements))
print("\nMask:")
print(mask)

source_data = torch.randint(0, 10, (size, num_elements))
print("\nSource Data:")
print(source_data)

# Call the API torch.Tensor.masked_scatter_
output = input_data.masked_scatter_(mask, source_data)
print("\nOutput:")
print(output)