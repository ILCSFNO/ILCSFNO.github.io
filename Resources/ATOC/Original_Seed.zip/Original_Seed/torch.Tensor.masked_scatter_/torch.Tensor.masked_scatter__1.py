import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

n = 5
m = 5
arr = torch.randn(n, m)

mask = torch.randint(0, 2, (n, m), dtype=torch.bool)
source = torch.randint(0, 100, (n, m))

# Call the API torch.Tensor.masked_scatter_
arr.masked_scatter_(mask, source)

print(arr)