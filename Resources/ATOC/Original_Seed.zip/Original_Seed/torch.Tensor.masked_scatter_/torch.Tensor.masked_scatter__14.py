import torch

# Generate input data
torch.random.seed(0)
input_tensor = torch.randint(0, 10, (2, 5))
print("Input Tensor:")
print(input_tensor)

torch.random.seed(0)
mask = torch.randint(0, 2, (2, 5))
print("\nMask:")
print(mask)

torch.random.seed(0)
source_tensor = torch.randint(0, 10, (2, 5))
print("\nSource Tensor:")
print(source_tensor)

# Call the API torch.Tensor.masked_scatter_
input_tensor.masked_scatter_(mask, source_tensor)
print("\nTensor after masked scatter:")
print(input_tensor)