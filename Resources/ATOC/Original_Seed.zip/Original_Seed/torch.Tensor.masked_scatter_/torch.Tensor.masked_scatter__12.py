import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_tensor = torch.tensor(np.random.randint(0, 10, (2, 5)))

# Generate random mask
mask = torch.tensor(np.random.choice([0, 1], size=(2, 5), p=[0.5, 0.5]), dtype=torch.bool)

# Generate random source tensor
source = torch.tensor(np.random.randint(0, 10, (2, 5)))

# Call the API torch.Tensor.masked_scatter_
random_tensor.masked_scatter_(mask, source)

# Print the result
print(random_tensor)