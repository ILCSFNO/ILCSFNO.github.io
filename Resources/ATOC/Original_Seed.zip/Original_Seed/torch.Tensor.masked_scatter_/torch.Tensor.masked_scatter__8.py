import torch
import numpy as np

# Generate input data
np.random.seed(0)
mask = torch.tensor(np.random.choice([0, 1], size=(2, 5), p=[0.8, 0.2]), dtype=torch.bool)
source = torch.tensor(np.random.randint(0, 10, size=(2, 5)), dtype=torch.long)

# Call the API torch.Tensor.masked_scatter_
self = torch.tensor([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]])
self.masked_scatter_(mask, source)

# Print the result
print(self)