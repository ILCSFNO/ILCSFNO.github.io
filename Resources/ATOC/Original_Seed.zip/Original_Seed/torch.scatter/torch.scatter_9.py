import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(10, 3)

# Generate random indices
indices = torch.randint(0, 10, (10,))

# Generate random values to scatter
values = torch.randn(10)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=0, index=indices, src=values)

print(output)