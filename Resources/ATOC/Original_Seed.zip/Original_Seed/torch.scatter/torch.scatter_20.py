import torch
import numpy as np
import random

# Set seed for reproducibility
random.seed(42)
np.random.seed(42)

# Generate random input data
input_data = torch.randn(5, 3)

# Generate random index
index = torch.randint(0, 5, (3,))

# Generate random values
src = torch.randn(3)

# Call the API torch.scatter
result = torch.scatter(input_data, dim=1, index=index, src=src)

print(result)