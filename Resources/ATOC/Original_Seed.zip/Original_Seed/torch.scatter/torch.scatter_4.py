import torch
import numpy as np

# Generate random input data
input_data = torch.randn(10, 3)

# Generate random indices
indices = torch.randint(0, 10, (10, 3), dtype=torch.long)

# Generate random values
values = torch.randn(10, 3)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=1, index=indices, src=values)

print(output)