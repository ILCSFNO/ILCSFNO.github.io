import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(10, 10)

# Generate random index
index = torch.randint(0, 10, (10,))
src = torch.randn(10)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=0, index=index, src=src)

# Print the output
print(output)

# Generate random input data
input_data = torch.randn(10, 10)

# Generate random index
index = torch.randint(0, 10, (10,))
src = torch.randn(10)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=0, index=index, src=src)

# Print the output
print(output)

# Generate random input data
input_data = torch.randn(10, 10)

# Generate random index
index = torch.randint(0, 10, (10,))
src = torch.randn(10)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=0, index=index, src=src)

# Print the output
print(output)