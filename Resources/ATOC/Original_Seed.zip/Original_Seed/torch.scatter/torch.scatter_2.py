import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

# Create a tensor
input_tensor = torch.randn(10, 10)

# Create a tensor with random values
src_tensor = torch.randn(10, 10)

# Create indices
indices = torch.randint(0, 10, (10,))

# Call the API torch.scatter
output_tensor = torch.scatter(input_tensor, dim=0, index=indices, src=src_tensor)

# Print the output tensor
print(output_tensor)