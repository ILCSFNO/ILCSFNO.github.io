import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))

input_data = torch.randn(3, 3)
index = torch.tensor([[0, 1], [1, 2]])

# Generate random values for scatter operation
src = torch.randn(3, 3)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=0, index=index, src=src)

# Print the output
print(output)