import torch
import numpy as np

# Generate random input data
input_data = torch.randn(5, 5)

# Generate random indices
indices = torch.randint(0, input_data.shape[0], (5,))

# Generate random source values
src_values = torch.randn(5)

# Call the torch.scatter API
result = torch.scatter(input_data, dim=0, index=indices, src=src_values)

print(result)