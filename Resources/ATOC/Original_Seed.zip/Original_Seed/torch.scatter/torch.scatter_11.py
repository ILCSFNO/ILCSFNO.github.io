import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(100, 5).astype(np.float32)

# Generate random index and source tensor
index = torch.randint(0, 100, (100,))
src = torch.randn(100, 5).float()

# Call the API torch.scatter
output = torch.scatter(input_data, dim=1, index=index, src=src)

print(output)