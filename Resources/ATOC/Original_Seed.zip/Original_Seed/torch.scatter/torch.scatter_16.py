import torch
import torch.nn.functional as F
import numpy as np
import random

def generate_random_data():
    # Generate random input tensor
    input_tensor = torch.randn(10, 3)
    
    # Generate random index tensor
    index_tensor = torch.randint(0, 10, (10,))
    
    # Generate random values tensor
    values_tensor = torch.randn(10)
    
    return input_tensor, index_tensor, values_tensor

def main():
    # Generate random input data
    input_tensor, index_tensor, values_tensor = generate_random_data()
    
    # Call the API torch.scatter
    output_tensor = torch.scatter(input_tensor, dim=0, index=index_tensor, src=values_tensor)
    
    print("Input Tensor:")
    print(input_tensor)
    print("\nIndex Tensor:")
    print(index_tensor)
    print("\nValues Tensor:")
    print(values_tensor)
    print("\nOutput Tensor:")
    print(output_tensor)

if __name__ == "__main__":
    main()