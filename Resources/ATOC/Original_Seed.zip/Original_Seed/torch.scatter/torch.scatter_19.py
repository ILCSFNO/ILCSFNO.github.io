import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(10, 3)

# Generate random indices
indices = torch.randint(0, 10, (5,))

# Generate random source values
src_values = torch.randn(5, 3)

# Call the API torch.scatter
output = torch.scatter(input_data, dim=0, index=indices, src=src_values)

# Print the output
print(output)