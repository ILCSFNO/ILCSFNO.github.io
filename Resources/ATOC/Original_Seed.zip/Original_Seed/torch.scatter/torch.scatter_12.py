import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(5, 3)

# Generate random index
index = torch.randint(0, 5, (1,))

# Generate random values to scatter
src = torch.randn(1, 3)

# Call the API torch.scatter
result = torch.scatter(input_data, dim=1, index=index, src=src)

print(result)