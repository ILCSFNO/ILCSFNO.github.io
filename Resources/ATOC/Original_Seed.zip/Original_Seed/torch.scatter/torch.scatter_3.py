import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(10, 3)
index = torch.randint(0, 10, (10,))
src = torch.randn(10, 3)

# Generate random scatter indices
scatter_indices = torch.randint(0, 10, (10,))

# Call the API torch.scatter
torch_scatter_result = torch.scatter(input_data, dim=0, index=scatter_indices, src=src)

# Print the results
print("Original Input Data:")
print(input_data)
print("\nScatter Indices:")
print(scatter_indices)
print("\nSource Tensor:")
print(src)
print("\nResult of torch.scatter:")
print(torch_scatter_result)