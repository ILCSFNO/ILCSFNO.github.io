import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(10, 5)
input_tensor = torch.tensor(input_data, dtype=torch.float32)

# Generate random index and value
np.random.seed(0)
index = torch.randint(0, 10, (10,))
value = torch.tensor(np.random.rand(10), dtype=torch.float32)

# Call the torch.scatter API
output_tensor = torch.scatter(input_tensor, dim=1, index=index, src=value)

# Print the output
print(output_tensor)