import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(10, 5)
input_tensor = torch.tensor(input_data, dtype=torch.float32)

# Generate random index
index = np.random.randint(0, 10, 5)
index_tensor = torch.tensor(index, dtype=torch.int64)

# Generate random source data
src = np.random.rand(5)
src_tensor = torch.tensor(src, dtype=torch.float32)

# Call the torch.scatter API
output = torch.scatter(input_tensor, dim=0, index=index_tensor, src=src_tensor)

print(output)