import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(5, 5)

# Generate random indices
indices = torch.randint(0, 5, (10,))

# Generate random source values
src_values = torch.randn(10)

# Call the torch.scatter API
output = torch.scatter(input_data, dim=0, index=indices, src=src_values)

print(output)