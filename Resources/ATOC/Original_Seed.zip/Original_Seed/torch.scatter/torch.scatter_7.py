import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(5, 3)
print("Input Data:")
print(input_data)

# Generate random indices
indices = torch.randint(0, 5, (3,))
print("\nIndices:")
print(indices)

# Generate random source data
source_data = torch.randn(3)
print("\nSource Data:")
print(source_data)

# Call the torch.scatter API
result = torch.scatter(input_data, dim=0, index=indices, src=source_data)
print("\nResult:")
print(result)