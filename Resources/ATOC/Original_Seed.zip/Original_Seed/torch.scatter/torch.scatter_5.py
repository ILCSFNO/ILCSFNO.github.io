import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 100))
torch.random.manual_seed(random.randint(0, 100))
input_data = torch.randn(10, 5)

# Generate random index
index = torch.randint(0, 10, (10,))

# Generate random values to scatter
src = torch.randn(10, 5)

# Call the API torch.scatter
result = torch.scatter(input_data, dim=1, index=index, src=src)

print(result)