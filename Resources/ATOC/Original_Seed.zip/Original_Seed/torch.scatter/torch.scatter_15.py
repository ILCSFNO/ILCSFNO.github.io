import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

input_data = torch.randn(10, 10)
dim = random.randint(0, 10)
index = random.randint(0, 10)
src = torch.randn(10)

# Call the API torch.scatter
torch.scatter(input_data, dim, index, src)
print(input_data)