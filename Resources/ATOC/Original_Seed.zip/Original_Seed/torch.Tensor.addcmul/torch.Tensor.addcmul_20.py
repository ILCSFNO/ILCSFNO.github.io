import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.randn(2, 2)
tensor2 = torch.randn(2, 2)

# Generate random scalar value
scalar = random.uniform(0.5, 2.0)

# Create a new tensor with random values
tensor3 = torch.randn(2, 2)

# Call the API torch.Tensor.addcmul
tensor_result = tensor1.addcmul(tensor2, value=scalar, other=tensor3)

# Print the result
print(tensor_result)