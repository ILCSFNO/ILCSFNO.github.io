import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.randn(2, 2)
tensor2 = torch.randn(2, 2)
value = random.uniform(0.1, 10.0)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)