import torch
import numpy as np
import random

def generate_input_data():
    # Generate two random tensors of shape (3, 3)
    tensor1 = torch.randn(3, 3)
    tensor2 = torch.randn(3, 3)

    # Generate a random scalar value
    value = random.uniform(0.1, 10.0)

    return tensor1, tensor2, value

tensor1, tensor2, value = generate_input_data()

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

print(result)