import torch
import numpy as np
import random

# Generate random input data
random_tensor1 = torch.randn(3, 3)
random_tensor2 = torch.randn(3, 3)

# Generate random value
random_value = random.uniform(0.5, 2.0)

# Generate random scalar
random_scalar = random.uniform(0.5, 2.0)

# Call the API torch.Tensor.addcmul
result = random_tensor1.addcmul(random_tensor2, value=random_value)

# Print the result
print(result)