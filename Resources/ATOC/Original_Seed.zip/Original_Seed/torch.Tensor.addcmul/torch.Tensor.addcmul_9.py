import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.tensor(np.random.rand(2, 2))
tensor2 = torch.tensor(np.random.rand(2, 2))

# Generate random value
value = random.uniform(0, 10)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

print(result)