import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.randn(2, 3)
tensor2 = torch.randn(2, 3)

# Generate random value
value = random.uniform(0.5, 1.5)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)