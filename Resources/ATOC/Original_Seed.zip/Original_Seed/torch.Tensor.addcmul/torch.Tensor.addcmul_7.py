import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
random_number1 = np.random.rand(10, 10)
random_number2 = np.random.rand(10, 10)

# Convert numpy arrays to torch tensors
random_tensor1 = torch.tensor(random_number1, dtype=torch.float32)
random_tensor2 = torch.tensor(random_number2, dtype=torch.float32)

# Call the API torch.Tensor.addcmul
result = random_tensor1.addcmul(random_tensor2, value=2)

# Print the result
print(result)