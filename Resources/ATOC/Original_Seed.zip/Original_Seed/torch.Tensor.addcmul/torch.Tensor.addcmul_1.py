import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.randn(2, 2)
tensor2 = torch.randn(2, 2)

# Generate random scalar value
value = random.uniform(0.5, 1.5)

# Generate random input data for testing
tensor1_test = torch.randn(2, 2)
tensor2_test = torch.randn(2, 2)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Test the API torch.Tensor.addcmul
result_test = tensor1_test.addcmul(tensor2_test, value=value)

# Print results
print("Original tensors:")
print(tensor1)
print(tensor2)
print("Result after calling addcmul API:")
print(result)
print("Result after calling addcmul API with test tensors:")
print(result_test)