import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.tensor(np.random.rand(3, 3))
tensor2 = torch.tensor(np.random.rand(3, 3))

# Generate random value for the operation
value = random.randint(1, 10)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)