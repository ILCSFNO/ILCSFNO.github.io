import torch
import numpy as np
import random

# Generate random input data
tensor1 = torch.randn(2, 3)
tensor2 = torch.randn(2, 3)

# Generate random value
value = random.uniform(0.5, 2.0)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)

# Print the original tensors and the value
print("Original tensors:")
print(tensor1)
print(tensor2)
print("Value:", value)