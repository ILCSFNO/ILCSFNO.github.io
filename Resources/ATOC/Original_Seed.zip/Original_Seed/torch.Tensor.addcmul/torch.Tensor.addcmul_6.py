import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

tensor1 = torch.randn(2, 2)
tensor2 = torch.randn(2, 2)

# Generate random value
value = random.uniform(0, 10)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)