import torch
import numpy as np
import random

# Generate random input data
random_tensor1 = torch.randn(2, 2)
random_tensor2 = torch.randn(2, 2)

# Generate random value
random_value = random.randint(1, 10)

# Call the API torch.Tensor.addcmul
result = random_tensor1.addcmul(random_tensor2, value=random_value)

# Print the result
print(result)