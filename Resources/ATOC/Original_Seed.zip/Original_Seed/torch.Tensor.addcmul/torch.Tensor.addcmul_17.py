import torch
import numpy as np
import random

# Generate random input data
random.seed(0)
tensor1 = torch.tensor(np.random.rand(3, 3))
tensor2 = torch.tensor(np.random.rand(3, 3))
value = random.uniform(0.1, 10.0)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)