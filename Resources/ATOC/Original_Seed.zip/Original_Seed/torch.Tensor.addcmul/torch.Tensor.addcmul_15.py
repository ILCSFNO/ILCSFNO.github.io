import torch
import numpy as np
import random

def generate_random_tensor(shape):
    return torch.randn(*shape)

def generate_random_input_data():
    tensor1 = generate_random_tensor((2, 3))
    tensor2 = generate_random_tensor((2, 3))
    value = random.uniform(0.1, 10.0)
    return tensor1, tensor2, value

tensor1, tensor2, value = generate_random_input_data()

result = tensor1.addcmul(tensor2, value=value)
print(result)