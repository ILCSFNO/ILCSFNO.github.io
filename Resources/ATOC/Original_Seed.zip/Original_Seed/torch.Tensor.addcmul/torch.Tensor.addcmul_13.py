import torch
import numpy as np

# Generate random input data
tensor1 = torch.randn(2, 3)
tensor2 = torch.randn(2, 3)

# Generate random value
value = torch.randn(2, 3)

# Call the API torch.Tensor.addcmul
result = tensor1.addcmul(tensor2, value=value)

# Print the result
print(result)