import torch
import numpy as np
import random

# Generate input data
input_data = torch.tensor([random.uniform(-10, 10) for _ in range(100)])

# Call the API torch.special.ndtr
result = torch.special.ndtr(input_data)

# Print the result
print(result)