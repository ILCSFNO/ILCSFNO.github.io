import torch
import torch.nn.functional as F

# Generate input data with a random tensor
input_data = torch.randn(5, 3)

# Call the API torch.special.ndtr
ndtr_result = torch.special.ndtr(input_data)

# Print the result
print(ndtr_result)