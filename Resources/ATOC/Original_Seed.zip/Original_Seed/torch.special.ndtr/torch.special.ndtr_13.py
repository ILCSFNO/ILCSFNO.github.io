import torch

# Generate input data
input_data = torch.randn(100)

# Call the API torch.special.ndtr
result = torch.special.ndtr(input_data)

# Print the result
print(result)