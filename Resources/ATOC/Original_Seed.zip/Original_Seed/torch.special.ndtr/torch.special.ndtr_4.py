import torch

# Generate input data with any function we like
input_data = torch.randn(100)

# Call the API torch.special.ndtr
ndtr_result = torch.special.ndtr(input_data)

# Print the result
print(ndtr_result)