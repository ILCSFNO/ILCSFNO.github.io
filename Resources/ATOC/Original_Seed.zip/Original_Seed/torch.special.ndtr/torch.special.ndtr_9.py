import torch

# Generate input data
input_data = torch.randn(10)

# Call the API torch.special.ndtr
ndtr_value = torch.special.ndtr(input_data)

# Print the result
print("ndtr value: ", ndtr_value)