import torch

# Generate input data with any function
input_data = torch.randn(100, 3)

# Call the API torch.special.ndtr
result = torch.special.ndtr(input_data)
print(result)