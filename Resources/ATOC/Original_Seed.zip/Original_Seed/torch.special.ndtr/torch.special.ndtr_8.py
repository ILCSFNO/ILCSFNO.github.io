import torch

# Generate input data
input_data = torch.randn(1000)

# Call the API torch.special.ndtr
output = torch.special.ndtr(input_data)

# Print the output
print(output)