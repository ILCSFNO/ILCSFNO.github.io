import torch
import numpy as np
import random

# Generate input data with any function we like
def generate_input_data():
    return torch.tensor(np.random.uniform(0, 10, 100))

# Call the API torch.special.ndtr
input_data = generate_input_data()
result = torch.special.ndtr(input_data)

# Print the result
print(result)

# Generate new input data
input_data = generate_input_data()
result = torch.special.ndtr(input_data)

# Print the result
print(result)