import torch
import torch.nn.functional as F
import numpy as np

# Generate random input data
np.random.seed(0)
torch.manual_seed(0)
input_data = torch.randn(10, 3)

# Call the API torch.special.ndtr
output = torch.special.ndtr(input_data)

# Print the output
print(output)