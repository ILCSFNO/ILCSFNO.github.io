import torch
import numpy as np

# Generate random input data
np.random.seed(0)
torch.manual_seed(0)
input_data = torch.tensor(np.random.rand(10))

# Call the API torch.special.ndtr
result = torch.special.ndtr(input_data)

# Print the result
print(result)