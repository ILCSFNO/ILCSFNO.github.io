import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))

# Generate 10 random input tensors
input_tensors = [torch.randn(1) for _ in range(10)]

# Call the API torch.Tensor.expm1_
for tensor in input_tensors:
    tensor.expm1_()