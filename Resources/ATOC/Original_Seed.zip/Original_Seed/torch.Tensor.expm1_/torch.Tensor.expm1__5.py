import torch
import numpy as np
import random

# Generate random input data
random.seed(0)
input_data = np.random.rand(5, 5)

# Create a PyTorch tensor from the input data
input_tensor = torch.from_numpy(input_data)

# Call the expm1_ function on the tensor
input_tensor.expm1_()