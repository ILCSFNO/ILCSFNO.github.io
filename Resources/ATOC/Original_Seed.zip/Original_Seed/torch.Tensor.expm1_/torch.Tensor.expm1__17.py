import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

# Generate input data with any function
input_data = torch.randn(5, 5)

# Call the API torch.Tensor.expm1_
output_data = input_data.expm1_()

# Print the output
print(output_data)