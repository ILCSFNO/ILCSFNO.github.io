import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))

def generate_input_data():
    input_data = np.random.rand(10, 10)
    tensor = torch.from_numpy(input_data)
    return tensor

# Call the API torch.Tensor.expm1_
def main():
    tensor = generate_input_data()
    tensor.expm1_()

if __name__ == "__main__":
    main()