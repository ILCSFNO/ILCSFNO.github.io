import torch
import numpy as np
import random

# Generate random input data
random.seed(0)
input_data = torch.tensor(np.random.rand(5, 5))

# Call the API torch.Tensor.expm1_
output_data = input_data.expm1_()
print(output_data)