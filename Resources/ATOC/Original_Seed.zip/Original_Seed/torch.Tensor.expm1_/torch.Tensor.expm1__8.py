import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = np.random.rand(3, 3)

# Convert numpy array to torch tensor
tensor_data = torch.from_numpy(random_data)

# Call the API torch.Tensor.expm1_
tensor_data.expm1_()