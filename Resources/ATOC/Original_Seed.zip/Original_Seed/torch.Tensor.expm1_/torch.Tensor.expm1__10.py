import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = np.random.rand(5, 5)

# Convert input data to PyTorch tensor
tensor_data = torch.from_numpy(random_data)

# Call the API torch.Tensor.expm1_
tensor_data.expm1_()