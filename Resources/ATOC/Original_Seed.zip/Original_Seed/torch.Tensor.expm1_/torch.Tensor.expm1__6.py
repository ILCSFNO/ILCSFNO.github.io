import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

input_data = torch.tensor(np.random.rand(10, 10))

# Call the API torch.Tensor.expm1_
output_data = input_data.expm1_()
print(output_data)