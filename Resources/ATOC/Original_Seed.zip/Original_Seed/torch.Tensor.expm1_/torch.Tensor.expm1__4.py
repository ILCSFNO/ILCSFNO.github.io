import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(5, 5)

# Create a PyTorch tensor from the input data
tensor = torch.from_numpy(input_data)

# Call the API torch.Tensor.expm1_
tensor.expm1_()