import torch
import numpy as np

# Generate random input data
input_data = torch.randn(5, 5)

# Call the API torch.Tensor.expm1_
input_data.expm1_()

print(input_data)