import torch
import numpy as np
import random

# Generate random input data
random.seed(0)
random_data = torch.tensor(np.random.rand(3, 3))

# Call the API torch.Tensor.expm1_
random_data.expm1_()
print(random_data)