import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(10, 10)

# Call the API torch.Tensor.expm1_
torch_tensor = torch.tensor(input_data)
torch_tensor.expm1_()