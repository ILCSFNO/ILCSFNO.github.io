import torch
import numpy as np

# Generate random input data
np.random.seed(0)
random_data = torch.randn(5, 5)

# Call the API torch.Tensor.expm1_
random_data.expm1_()