import torch
import numpy as np
import random

def generate_random_data():
    # Generate random data
    random_data = np.random.rand(10, 10)
    return torch.from_numpy(random_data)

def main():
    # Generate random data
    random_data = generate_random_data()
    
    # Call the API torch.Tensor.expm1_
    random_data.expm1_()
    
    # Print the modified tensor
    print(random_data)

if __name__ == "__main__":
    main()