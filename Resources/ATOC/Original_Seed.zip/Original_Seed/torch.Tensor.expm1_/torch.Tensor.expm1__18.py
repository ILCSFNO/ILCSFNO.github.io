import torch
import numpy as np

# Generate random input data
input_data = np.random.rand(10, 5)

# Create a tensor from the input data
tensor = torch.tensor(input_data, dtype=torch.float32)

# Call the expm1_ API
tensor.expm1_()