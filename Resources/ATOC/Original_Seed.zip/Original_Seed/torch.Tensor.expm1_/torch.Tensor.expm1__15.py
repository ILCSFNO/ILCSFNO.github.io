import torch
import numpy as np
import random

def generate_random_input():
    return torch.tensor(np.random.rand(5, 5))

def main():
    # Generate random input data
    input_data = generate_random_input()
    
    # Call the API torch.Tensor.expm1_
    result = input_data.expm1_()
    
    print(result)

if __name__ == "__main__":
    main()