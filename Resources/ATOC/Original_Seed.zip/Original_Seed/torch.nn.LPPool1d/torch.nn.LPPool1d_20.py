import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_size = 50
num_planes = 16
sequence_length = 20
batch_size = 1

input_data = torch.randn(batch_size, num_planes, sequence_length)

# Define the LPPool1d model
class CustomModel(nn.Module):
    def __init__(self):
        super(CustomModel, self).__init__()
        self.lppool = nn.LPPool1d(p=2, kernel_size=3, stride=2, ceil_mode=False)

    def forward(self, x):
        return self.lppool(x)

# Initialize the model and apply the LPPool1d
model = CustomModel()
output = model(input_data)

# Print the output shape
print(output.shape)