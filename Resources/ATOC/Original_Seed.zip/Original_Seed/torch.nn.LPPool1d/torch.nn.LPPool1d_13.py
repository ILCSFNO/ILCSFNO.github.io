import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 100))
random.seed(random.randint(0, 100))
torch.manual_seed(random.randint(0, 100))

input_size = 50
num_planes = 16
sequence_length = 20
window_size = 3
stride = 2
p = 2

input_data = torch.randn(num_planes, sequence_length, input_size)
output_data = torch.randn(num_planes, sequence_length, input_size)

# Create LPPool1d model
model = nn.LPPool1d(p, window_size, stride=stride, ceil_mode=False)

# Apply LPPool1d to input data
output = model(input_data)

print("Input Shape:", input_data.shape)
print("Output Shape:", output.shape)