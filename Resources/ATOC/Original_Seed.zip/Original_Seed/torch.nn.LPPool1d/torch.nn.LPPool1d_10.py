import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
def generate_input_data():
    input_data = torch.randn(1, 16, 50)
    return input_data

# Generate random kernel size
kernel_size = random.randint(1, 10)

# Generate random stride
stride = random.randint(1, kernel_size)

# Generate random p value
p = random.randint(1, 10)

# Create a LPPool1d model
model = nn.LPPool1d(p, kernel_size, stride=stride)

# Generate input data
input_data = generate_input_data()

# Call the LPPool1d model
output = model(input_data)

print("Input Shape:", input_data.shape)
print("Output Shape:", output.shape)