import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
input_size = (20, 16, 50)
input_data = torch.randn(input_size)

# Generate random kernel size
kernel_size = random.randint(1, 10)

# Generate random stride
stride = random.randint(1, kernel_size)

# Generate random power
power = random.randint(1, 10)

# Create LPPool1d model
model = nn.LPPool1d(power, kernel_size, stride=stride, ceil_mode=False)

# Apply the model to the input data
output = model(input_data)

# Print the output
print(output.shape)