import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_data = torch.randn(1, 16, 50).float()

# Define LPPool1d model
class CustomLPPool1d(nn.Module):
    def __init__(self, norm_type, kernel_size, stride=None, ceil_mode=False):
        super(CustomLPPool1d, self).__init__()
        self.norm_type = norm_type
        self.kernel_size = kernel_size
        self.stride = stride
        self.ceil_mode = ceil_mode

    def forward(self, x):
        output = F.lppool(x, self.kernel_size, self.stride, self.ceil_mode, self.norm_type)
        return output

# Create model instance
model = CustomLPPool1d(norm_type=2, kernel_size=3, stride=2)

# Call the model
output = model(input_data)

print(output)