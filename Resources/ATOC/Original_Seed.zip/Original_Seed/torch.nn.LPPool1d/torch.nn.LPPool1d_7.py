import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
def generate_input_data():
    input_shape = (20, 16, 50)
    input_data = torch.randn(input_shape)
    return input_data

# Generate random output shape
def generate_output_shape(kernel_size, stride):
    output_shape = (input_shape[0], input_shape[1], (input_shape[2] - kernel_size) // stride + 1)
    return output_shape

# Generate random norm_type, kernel_size, and stride
norm_type = random.randint(1, 10)
kernel_size = random.randint(1, 10)
stride = random.randint(1, kernel_size)

# Generate random input data
input_data = generate_input_data()

# Apply LPPool1d
m = nn.LPPool1d(norm_type, kernel_size, stride=stride)
output = m(input_data)

print("Input Data:")
print(input_data.shape)

print("\nOutput Shape:")
print(output.shape)

print("\nOutput:")
print(output.shape)