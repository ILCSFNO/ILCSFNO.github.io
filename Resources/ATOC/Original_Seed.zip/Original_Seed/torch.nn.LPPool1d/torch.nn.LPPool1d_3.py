import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
input_data = torch.randn(20, 16, 50)

# Generate random kernel size
kernel_size = random.randint(1, 10)

# Generate random stride
stride = random.randint(1, 10)

# Generate random ceil mode
ceil_mode = random.choice([True, False])

# Create LPPool1d model
model = nn.LPPool1d(kernel_size, stride=stride, ceil_mode=ceil_mode)

# Apply LPPool1d to input data
output = model(input_data)

# Print output shape
print(output.shape)