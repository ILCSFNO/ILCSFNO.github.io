import torch
import torch.nn as nn
import torch.nn.functional as F

# Generate input data
input_data = torch.randn(1, 16, 50)

# Create an instance of LPPool1d
lppool1d = nn.LPPool1d(p=2, kernel_size=3, stride=2, ceil_mode=False)

# Call the LPPool1d API
output = lppool1d(input_data)

# Print the output
print(output)