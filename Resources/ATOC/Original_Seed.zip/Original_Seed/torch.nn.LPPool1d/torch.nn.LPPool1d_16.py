import torch
import torch.nn as nn
import numpy as np

# Generate input data
np.random.seed(0)
input_data = torch.randn(1, 16, 50).to(torch.float32)

# Create LPPool1d instance
p = 2  # power value
kernel_size = 3
stride = 2
lppool = nn.LPPool1d(p, kernel_size, stride, ceil_mode=True)

# Apply LPPool1d to input data
output = lppool(input_data)

print(output.shape)