import torch
import torch.nn as nn
import numpy as np

# Generate input data
input_data = torch.randn(1, 16, 50)

# Define LPPool1d
class CustomLPPool1d(nn.Module):
    def __init__(self, norm_type, kernel_size, stride=None, ceil_mode=False):
        super(CustomLPPool1d, self).__init__()
        self.norm_type = norm_type
        self.kernel_size = kernel_size
        self.stride = stride
        self.ceil_mode = ceil_mode

    def forward(self, x):
        output = []
        for i in range(x.shape[2]):
            window = x[:, :, i:i + self.kernel_size]
            if self.stride is None:
                self.stride = self.kernel_size
            window = window.view(window.shape[0], -1)
            window = torch.pow(window, self.norm_type).sum(1)
            window = torch.pow(window, 1.0 / self.norm_type)
            output.append(window)
        output = torch.stack(output, dim=2)
        return output

# Apply LPPool1d
m = CustomLPPool1d(norm_type=2, kernel_si