import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
input_size = 20
input_channels = 16
input_length = 50
input_data = torch.randn(input_size, input_channels, input_length)

# Define LPPool1d
norm_type = 2
kernel_size = random.randint(1, 10)
stride = random.randint(1, kernel_size)
ceil_mode = random.choice([True, False])

# Create LPPool1d model
model = nn.LPPool1d(norm_type, kernel_size, stride, ceil_mode)

# Apply LPPool1d to the input data
output = model(input_data)

# Print the output shape
print(output.shape)