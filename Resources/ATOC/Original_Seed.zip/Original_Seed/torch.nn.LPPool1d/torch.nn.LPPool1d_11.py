import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
input_size = 50
output_size = 20
num_planes = 16
input_data = torch.randn(input_size, num_planes)

# Define LPPool1d
class CustomLPPool1d(nn.Module):
    def __init__(self, norm_type, kernel_size, stride=None, ceil_mode=False):
        super(CustomLPPool1d, self).__init__()
        self.norm_type = norm_type
        self.kernel_size = kernel_size
        self.stride = stride
        self.ceil_mode = ceil_mode

    def forward(self, x):
        if self.norm_type =='max':
            return F.max_pool1d(x, self.kernel_size, self.stride, self.ceil_mode)
        elif self.norm_type =='sum':
            return F.avg_pool1d(x, self.kernel_size, self.stride, self.ceil_mode)
        else:
            raise ValueError("norm_type should be'max' or'sum'")

# Generate random LPPool1d
norm_type ='max' if random.random() < 0.5 else's