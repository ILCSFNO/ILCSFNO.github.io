import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
input_data = torch.randn(1, 16, 50)

# Define the LPPool1d layer
kernel_size = random.randint(2, 10)
stride = random.randint(1, kernel_size)
norm_type = 2  # random norm type
lppool1d = nn.LPPool1d(norm_type, kernel_size, stride=stride, ceil_mode=True)

# Apply the LPPool1d layer to the input data
output = lppool1d(input_data)

print(output.shape)