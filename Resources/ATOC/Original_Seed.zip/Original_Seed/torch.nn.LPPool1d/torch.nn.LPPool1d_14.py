import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random

# Generate random input data
input_data = torch.randn(20, 16, 50)

# Define the LPPool1d layer
class CustomLPPool1d(nn.Module):
    def __init__(self, norm_type, kernel_size, stride=None, ceil_mode=False):
        super(CustomLPPool1d, self).__init__()
        self.norm_type = norm_type
        self.kernel_size = kernel_size
        self.stride = stride
        self.ceil_mode = ceil_mode

    def forward(self, x):
        if self.norm_type == 'inf':
            p = np.inf
        elif self.norm_type == '1':
            p = 1
        elif self.norm_type == '2':
            p = 2
        else:
            raise ValueError('Invalid norm type')

        output = F.lppool(x, self.kernel_size, self.stride, self.ceil_mode, p)

        return output

# Create an instance of the CustomLPPool1d layer
custom_lppool1d = CustomLPPool1d(norm_type='inf', kernel_si