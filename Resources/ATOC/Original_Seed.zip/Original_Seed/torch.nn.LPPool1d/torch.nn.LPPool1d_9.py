import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
def generate_input_data():
    input_shape = (20, 16, 50)
    input_data = torch.randn(input_shape)
    return input_data

# Generate random LPPool1d parameters
def generate_lppool1d_params():
    kernel_size = random.randint(1, 10)
    stride = random.randint(1, kernel_size)
    ceil_mode = random.choice([True, False])
    return kernel_size, stride, ceil_mode

# Generate code
def generate_code():
    input_data = generate_input_data()
    kernel_size, stride, ceil_mode = generate_lppool1d_params()
    m = nn.LPPool1d(kernel_size, stride, ceil_mode=ceil_mode)
    output = m(input_data)
    return input_data, m, output

input_data, m, output = generate_code()
print("Input Data:")
print(input_data.shape)
print("\nModel:")
print(m)
print("\nOutput:")
print(output.shape)