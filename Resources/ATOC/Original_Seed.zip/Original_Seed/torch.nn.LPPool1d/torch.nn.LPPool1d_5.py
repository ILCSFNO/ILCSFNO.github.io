import torch
import torch.nn as nn
import torch.nn.functional as F

# Generate random input data
input_data = torch.randn(1, 16, 50)

# Define LPPool1d
class CustomLPPool1d(nn.Module):
    def __init__(self, norm_type, kernel_size, stride=None, ceil_mode=False):
        super(CustomLPPool1d, self).__init__()
        self.norm_type = norm_type
        self.kernel_size = kernel_size
        self.stride = stride
        self.ceil_mode = ceil_mode

    def forward(self, x):
        if self.norm_type == 'inf':
            x = x ** self.kernel_size
            x = F.max_pool1d(x, self.kernel_size, self.stride, self.ceil_mode)
        elif self.norm_type == 1:
            x = x ** self.kernel_size
            x = F.avg_pool1d(x, self.kernel_size, self.stride, self.ceil_mode)
        elif self.norm_type == 2:
            x = x ** self.kernel_size
            x = F.mean_pool1d(x, self.kernel_size, self.stride, self.ceil_mode)
        else:
            raise ValueError("Invalid norm typ