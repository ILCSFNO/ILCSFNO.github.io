import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(1, 1000))
torch.manual_seed(random.randint(1, 1000))

def generate_random_input():
    input_size = 20
    channels = 16
    length = 50
    return torch.randn(input_size, channels, length)

input_data = generate_random_input()

# Define LPPool1d
class CustomLPPool1d(nn.Module):
    def __init__(self, norm_type, kernel_size, stride=None, ceil_mode=False):
        super(CustomLPPool1d, self).__init__()
        self.norm_type = norm_type
        self.kernel_size = kernel_size
        self.stride = stride
        self.ceil_mode = ceil_mode

    def forward(self, x):
        output = []
        for i in range(x.shape[2] - self.kernel_size + 1):
            window = x[:, :, i:i + self.kernel_size]
            window_power = (window ** self.norm_type).sum(dim=2, keepdim=True)
            window_power = torch.pow(window_power, 1 / self.norm_type)
            output.append(wi