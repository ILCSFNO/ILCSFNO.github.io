import torch
import numpy as np

# Generate input data
np.random.seed(0)
input_data = torch.tensor(np.random.randint(2, size=(100, 100)))

# Generate output data
output_data = torch.tensor(np.random.randint(2, size=(100, 100)))

# Call the API torch.Tensor.logical_or_
output = input_data.logical_or_(output_data)

# Print the output
print(output)