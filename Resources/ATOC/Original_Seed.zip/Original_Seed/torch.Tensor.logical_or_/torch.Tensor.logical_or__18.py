import torch
import torch.randn
import torch.randn_like

# Generate random input data
input_data = torch.randn_like(10, 5)
print("Input Data:")
print(input_data)

# Generate random input data with same shape
input_data2 = torch.randn_like(10, 5)
print("\nInput Data 2:")
print(input_data2)

# Call the API torch.Tensor.logical_or_
result = input_data.logical_or_(input_data2)
print("\nResult after logical_or_ operation:")
print(result)