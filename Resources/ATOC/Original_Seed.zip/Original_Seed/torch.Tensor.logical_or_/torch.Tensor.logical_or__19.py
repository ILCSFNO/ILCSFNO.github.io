import torch
import numpy as np
import random

# Generate random input data
def generate_random_input_data():
    # Generate random boolean tensors
    bool_tensor1 = torch.tensor(np.random.choice([True, False], size=(10, 10)), dtype=torch.bool)
    bool_tensor2 = torch.tensor(np.random.choice([True, False], size=(10, 10)), dtype=torch.bool)

    # Stack the tensors
    input_data = torch.stack((bool_tensor1, bool_tensor2), dim=0)

    return input_data

# Generate random input data
input_data = generate_random_input_data()

# Call the API torch.Tensor.logical_or_
result = input_data[0].logical_or_(input_data[1])

# Print the result
print(result)