import torch
import torch.nn as nn
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
input_data = torch.randn(5, 3, dtype=torch.bool)

# Call the API torch.Tensor.logical_or_
output_data = input_data.logical_or_(input_data)

# Print the output
print(output_data)