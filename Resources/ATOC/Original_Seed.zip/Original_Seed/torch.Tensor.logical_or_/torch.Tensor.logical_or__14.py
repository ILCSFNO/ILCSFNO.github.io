import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    a = torch.randn(5, 5)
    b = torch.randn(5, 5)
    return a, b

# Generate input data
a, b = generate_input_data()

# Call the API torch.Tensor.logical_or_
torch_result = torch.logical_or(a, b)
print("Result of torch.Tensor.logical_or_():", torch_result)

# Convert result to numpy array
np_result = torch_result.numpy()
print("Result of torch.Tensor.logical_or_():", np_result)

# Check result with numpy's logical_or function
np_result = np.logical_or(a.numpy(), b.numpy())
print("Result of numpy's logical_or():", np_result)