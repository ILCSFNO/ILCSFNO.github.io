import torch
import numpy as np
import random

# Generate random input data
random.seed(42)
np.random.seed(42)
torch.manual_seed(42)

# Generate random tensor with 5 elements
tensor1 = torch.tensor(np.random.randint(0, 2, size=5))
tensor2 = torch.tensor(np.random.randint(0, 2, size=5))

# Print the original tensors
print("Original Tensor 1:")
print(tensor1)
print("Original Tensor 2:")
print(tensor2)

# Call the API torch.Tensor.logical_or_
tensor_result = tensor1.logical_or_(tensor2)

# Print the result
print("\nResult of logical_or_ operation:")
print(tensor_result)