import torch
import numpy as np
import random

# Generate random input data
input_data = torch.randn(10, 10)

# Generate random mask data
mask_data = torch.randint(2, (10, 10), dtype=torch.bool)

# Generate random weights data
weights_data = torch.randint(2, (10, 10), dtype=torch.bool)

# Call the API torch.Tensor.logical_or_
result = input_data.logical_or_(mask_data)

# Print the result
print(result)