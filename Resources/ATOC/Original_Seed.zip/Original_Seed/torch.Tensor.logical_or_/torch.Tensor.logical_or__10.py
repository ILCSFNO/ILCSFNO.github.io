import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_data = torch.tensor(np.random.choice([0, 1], size=(10, 10)))

# Generate random labels
labels = torch.tensor(np.random.choice([0, 1], size=(10, 10)))

# Call the API torch.Tensor.logical_or_
output = input_data.logical_or_(labels)

print("Input Data:")
print(input_data)
print("\nLabels:")
print(labels)
print("\nOutput:")
print(output)