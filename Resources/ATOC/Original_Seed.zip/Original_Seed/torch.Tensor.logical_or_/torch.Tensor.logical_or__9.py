import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.randint(2, size=(10, 10))

# Create PyTorch tensors
tensor1 = torch.from_numpy(input_data)
tensor2 = torch.from_numpy(input_data)

# Call the API torch.Tensor.logical_or_
tensor_result = tensor1.logical_or_(tensor2)

# Print the result
print(tensor_result)