import torch
import numpy as np
import random

# Generate random input data
np.random.seed(0)
random.seed(0)
torch.manual_seed(0)

input_data = np.random.randint(2, size=(10, 10))
input_data_torch = torch.from_numpy(input_data)

# Call the API torch.Tensor.logical_or_
output = input_data_torch.logical_or_(input_data_torch)
print(output)