import torch
import numpy as np
import random

# Generate random input data
def generate_input_data():
    # Randomly generate two tensors
    tensor1 = torch.randn(10, 10)
    tensor2 = torch.randn(10, 10)
    
    # Randomly choose a boolean mask
    bool_mask = torch.randint(0, 2, (tensor1.shape[0],), dtype=torch.bool)
    
    return tensor1, tensor2, bool_mask

# Generate input data
tensor1, tensor2, bool_mask = generate_input_data()

# Call the API torch.Tensor.logical_or_
tensor1.logical_or_(tensor2, other=torch.tensor(bool_mask))

# Print the result
print(tensor1)