import torch
import numpy as np

# Generate input data
np.random.seed(0)
tensor1 = torch.tensor(np.random.choice([0, 1], size=(5, 5)))
tensor2 = torch.tensor(np.random.choice([0, 1], size=(5, 5)))

# Call the API torch.Tensor.logical_or_
tensor_result = tensor1.logical_or_(tensor2)

# Print the result
print(tensor_result)