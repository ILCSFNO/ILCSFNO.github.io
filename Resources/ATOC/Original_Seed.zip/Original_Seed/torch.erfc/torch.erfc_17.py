import torch
import torch.distributions.special as special
import numpy as np
import random

def generate_random_input():
    return torch.tensor(np.random.normal(0, 1, size=100))

def main():
    input_data = generate_random_input()
    output = special.erfc(input_data)
    print(output)

if __name__ == "__main__":
    main()