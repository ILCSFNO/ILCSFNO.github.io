import torch
import numpy as np
import random

# Generate random input data
input_data = torch.tensor(np.random.rand(10))

# Generate random output data
output_data = torch.randn(10)

# Call the API torch.erfc
erfc_output = torch.erfc(input_data)

# Print the results
print("Input Data:")
print(input_data)
print("\nOutput of torch.erfc:")
print(erfc_output)
print("\nOutput of numpy.erfc:")
print(np.erfc(input_data.numpy()))