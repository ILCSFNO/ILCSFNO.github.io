import torch
import numpy as np
import random

# Generate random input data
input_data = np.random.rand(100)

# Ensure the input data is a torch tensor
input_tensor = torch.tensor(input_data, dtype=torch.float32)

# Call the API torch.erfc
output = torch.erfc(input_tensor)

# Print the output
print(output)