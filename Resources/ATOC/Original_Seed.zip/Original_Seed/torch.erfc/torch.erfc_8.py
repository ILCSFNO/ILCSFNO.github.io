import torch
import torch.nn.functional as F
import torch.randn as randn

# Generate random input data
input_data = randn(100)

# Call the API torch.erfc
output = torch.erfc(input_data)

# Print the output
print(output)