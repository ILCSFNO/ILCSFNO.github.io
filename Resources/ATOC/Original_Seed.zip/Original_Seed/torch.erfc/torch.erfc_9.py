import torch
import torch.distributions
import torch.nn.functional as F
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = torch.randn(100, 1)

# Call the API torch.erfc
output = torch.erfc(input_data)

# Print the output
print(output)