import torch
import numpy as np

# Generate random input data
input_data = np.random.rand(10, 1)

# Call the API torch.erfc
output = torch.erfc(input_data)

# Print the output
print(output)