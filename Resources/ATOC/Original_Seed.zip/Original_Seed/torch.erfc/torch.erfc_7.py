import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(100, 1)

# Generate input data with torch
torch_input_data = torch.from_numpy(input_data)

# Call the API torch.erfc
torch.erfc_result = torch.erfc(torch_input_data)

# Print the result
print(torch_erfc_result)