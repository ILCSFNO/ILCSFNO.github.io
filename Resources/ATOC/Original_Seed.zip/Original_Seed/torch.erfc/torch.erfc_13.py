import torch
import torch.distributions as dist
import numpy as np
import random

def generate_input_data():
    # Generate random input data
    input_data = np.random.normal(0, 1, (1000, 1))
    return input_data

def main():
    # Generate input data
    input_data = generate_input_data()
    
    # Convert input data to tensor
    input_tensor = torch.from_numpy(input_data)
    
    # Call the API torch.erfc
    output = torch.erfc(input_tensor)
    
    # Print the output
    print(output)

if __name__ == "__main__":
    main()