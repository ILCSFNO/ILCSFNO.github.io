import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
input_data = np.random.rand(10, 10)

# Call the API torch.erfc
torch.random.manual_seed(random.randint(0, 1000))
output = torch.erfc(input_data)

# Print the shape of the output
print("Output shape:", output.shape)

# Print the first element of the output
print("First element of output:", output[0, 0])