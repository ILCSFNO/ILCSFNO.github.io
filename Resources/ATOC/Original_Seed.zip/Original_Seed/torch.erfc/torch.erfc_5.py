import torch
import numpy as np
import random

# Generate random input data
np.random.seed(random.randint(0, 1000))
random.seed(random.randint(0, 1000))
torch.manual_seed(random.randint(0, 1000))

input_data = torch.tensor(np.random.randn(10, 10), dtype=torch.float32)

# Call the API torch.erfc
output = torch.erfc(input_data)

print("Input Data:")
print(input_data)
print("\nOutput of torch.erfc API:")
print(output)