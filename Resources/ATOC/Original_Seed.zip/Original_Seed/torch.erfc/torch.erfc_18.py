import torch
import torch.nn.functional as F
import numpy as np
import random

def generate_input_data(size):
    return torch.randn(size)

def main():
    size = random.randint(1, 100)
    input_data = generate_input_data(size)
    output = torch.erfc(input_data)
    print(output)

if __name__ == "__main__":
    main()