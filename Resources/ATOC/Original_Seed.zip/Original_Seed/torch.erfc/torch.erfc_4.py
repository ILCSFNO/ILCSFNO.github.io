import torch
import torch.nn.functional as F
import numpy as np

# Generate random input data
input_data = np.random.randn(100, 1).astype(np.float32)

# Call the API torch.erfc
output = torch.tensor(torch.erfc(input_data), dtype=torch.float32)
print(output)