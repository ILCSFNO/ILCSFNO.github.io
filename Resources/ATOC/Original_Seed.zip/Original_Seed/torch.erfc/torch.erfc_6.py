import torch
import torch.distributions as dist
import numpy as np
import random

# Generate random input data
random.seed(0)
input_data = np.random.randn(100, 1)

# Generate output data
output_data = torch.erfc(input_data)

# Print the output data
print(output_data)