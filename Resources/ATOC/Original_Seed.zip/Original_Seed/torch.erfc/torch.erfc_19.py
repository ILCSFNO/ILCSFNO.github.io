import torch
import numpy as np

# Generate random input data
np.random.seed(0)
input_data = np.random.rand(100)

# Call the API torch.erfc
output = torch.tensor(torch.erfc(input_data), dtype=torch.float32)

# Print the output
print(output)