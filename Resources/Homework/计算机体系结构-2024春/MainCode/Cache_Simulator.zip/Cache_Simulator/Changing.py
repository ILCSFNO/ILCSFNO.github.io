import re
name = input('Name: ')
fin = open(name, encoding='UTF-8')
fout = open(name[:-3] + 'change.din', "w", encoding='UTF-8')
for line in fin:
    if(line.strip() == ''):
        continue
    lists = [x for x in re.split(',| ', line.strip()) if x]
    if lists[0] in ['0', '1']:
        fout.write(lists[0] + ' ' + lists[1] + '\n')