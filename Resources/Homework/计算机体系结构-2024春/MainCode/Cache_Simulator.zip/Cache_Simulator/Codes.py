from tkinter import filedialog, BooleanVar
from tkinter.messagebox import showerror, showinfo
from tkinter.simpledialog import askinteger, askstring
from typing import Union
import re

class Codes():
    def __init__(self, root):
        self.root = root
        
        self.time = -1
        self.Coding = []
        self.Cache = []
        
        self.filepath = None
        self.fileread = []
        self.endflag = False
        self.Breakpoints = []
        
        self.HitNum = {
            '0': 0,
            '1': 0
        }
        self.NotHitNum = {
            '0': 0,
            '1': 0
        }
        self.ReplaceNum = {
            '0': 0,
            '1': 0
        }
        
        self.CacheNum = int(64*1024/32/1)
        self.CacheSize = 64
        self.GetCacheSize = {
            '8': BooleanVar(value=False),
            '16': BooleanVar(value=False),
            '32': BooleanVar(value=False),
            '64': BooleanVar(value=True)
        }
        self.BlockSize = 32
        self.GetBlockSize = {
            '16': BooleanVar(value=False),
            '32': BooleanVar(value=True),
            '64': BooleanVar(value=False),
            '128': BooleanVar(value=False)
        }
        self.Associativity = 1
        self.GetAssociativity = {
            '1': BooleanVar(value=True),
            '2': BooleanVar(value=False),
            '4': BooleanVar(value=False),
            '8': BooleanVar(value=False)
        }
        
        for i in range(self.CacheNum):
            self.Cache.append([])

        self.DebugText = None
        self.StatisticsText = None
        self.CacheText = None
        self.ClockText = None
        self.BreakpointText = None
    
    def reset(self, filepath=None, Coding=[], fileread=[], Breakpoints=[], DebugText=None, StatisticsText=None, CacheText=None, ClockText=None, BreakpointText=None):
        self.time = -1
        self.Coding = Coding
        self.Cache = []
        
        self.filepath = filepath
        self.fileread = fileread
        self.endflag = False
        self.Breakpoints = Breakpoints
        
        self.HitNum = {
            '0': 0,
            '1': 0
        }
        self.NotHitNum = {
            '0': 0,
            '1': 0
        }
        self.ReplaceNum = {
            '0': 0,
            '1': 0
        }
        
        for i in range(self.CacheNum):
            self.Cache.append([])
        
        if self.DebugText != None:
            self.DebugText.delete('1.0', 'end')
        if self.StatisticsText != None:
            self.StatisticsText.delete('1.0', 'end')
        if self.CacheText != None:
            self.CacheText.delete('1.0', 'end')
        if self.ClockText != None:
            self.ClockText.delete('1.0', 'end')
        if self.BreakpointText != None:
            self.BreakpointText.delete('1.0', 'end')
        self.DebugText = DebugText
        self.StatisticsText = StatisticsText
        self.CacheText = CacheText
        self.ClockText = ClockText
        self.BreakpointText = BreakpointText
    
    def reset_DLX(self) -> bool:
        self.reset(self.filepath, self.Coding, self.fileread, self.Breakpoints, self.DebugText, self.StatisticsText, self.CacheText, self.ClockText, self.BreakpointText)
        try:
            self.DebugText.insert('end', 'Loading For ' + self.filepath + ' ... ' + '\n\n')
            # f = self.fileread
            # for line in f:
            #     self.DebugText.insert('end', line.strip() + '\n')
            #     if(line.strip() == ''):
            #         continue
            #     self.CheckCoding(line.strip())
            # self.DebugText.insert('end', '\nLoading Finished!' + '\n')
            self.ShowState(self.time)
            return True
        except:
            return False

    def CheckCoding(self, code: str):
        lists = [x for x in re.split(',| ', code) if x]
        if lists[0] in ['0', '1']:
            self.Coding.append(lists)
        return

    def ReadCodeByFile(self, DebugText, StatisticsText, CacheText, ClockText, BreakpointText) -> bool:
        self.reset(Coding=[], Breakpoints=[])
        self.DebugText = DebugText
        self.StatisticsText = StatisticsText
        self.CacheText = CacheText
        self.ClockText = ClockText
        self.BreakpointText = BreakpointText
        filepath = filedialog.askopenfilename(title='Choose Your File')
        self.filepath = filepath
        try:
            DebugText.insert('end', 'Loading For ' + filepath + ' ... ' + '\n\n')
            f = open(filepath, encoding='UTF-8')
            self.fileread = []
            for line in f:
                self.fileread.append(line)
                DebugText.insert('end', line.strip() + '\n')
                if(line.strip() == ''):
                    continue
                self.CheckCoding(line.strip())
            DebugText.insert('end', '\nLoading Finished!' + '\n')
            self.ShowState(self.time)
            return True
        except:
            return False

    def EndRunning(self):
        self.endflag = True
        showinfo("Info", "The Program is Finished.")
        return

    def Set_CacheSize(self, num: int):
        self.GetCacheSize[str(self.CacheSize)].set(False)
        self.CacheSize = num
        # self.GetCacheSize[str(self.CacheSize)] = BooleanVar(value=True)
        self.CacheNum = int(self.CacheSize*1024/self.BlockSize/self.Associativity)
        self.reset_DLX()

    def Set_BlockSize(self, num: int):
        self.GetBlockSize[str(self.BlockSize)].set(False)
        self.BlockSize = num
        # self.GetBlockSize[str(self.BlockSize)] = BooleanVar(value=True)
        self.CacheNum = int(self.CacheSize*1024/self.BlockSize/self.Associativity)
        self.reset_DLX()

    def Set_Associativity(self, num: int):
        self.GetAssociativity[str(self.Associativity)].set(False)
        self.Associativity = num
        # self.GetAssociativity[str(self.Associativity)] = BooleanVar(value=True)
        self.CacheNum = int(self.CacheSize*1024/self.BlockSize/self.Associativity)
        self.reset_DLX()

    def ShowState(self, timing: int):
        # ClockText
        self.ClockText.delete('1.0', 'end')
        self.ClockText.insert("end", 'ClockText\n', "center")
        self.ClockText.insert('end', 'Cycles' + '\t' + 'Instru' + '\n')
        for i in range(0, timing+1, 1):
            try:
                self.ClockText.insert('end', str(i+1) + '\t' + ' '.join(self.Coding[i]) + '\n')
            except:
                pass
        self.ClockText.insert('end', '\n')
        # CacheText
        self.CacheText.delete('1.0', 'end')
        self.CacheText.insert("end", 'CacheText\n', "center")
        self.CacheText.insert('end', 'CachePos' + '\t\t' + 'Tag' + '\n')
        for i in range(self.CacheNum):
            for j in range(self.Associativity):
                if j >= len(self.Cache[i]):
                    self.CacheText.insert('end', str(i) + '-' + str(j) + '\t\t' + '/' + '\n')
                else:
                    self.CacheText.insert('end', str(i) + '-' + str(j) + '\t\t' + str(self.Cache[i][j]) + '\n')
        # BreakpointText
        self.BreakpointText.delete('1.0', 'end')
        self.BreakpointText.insert("end", 'BreakpointText\n', "center")
        self.BreakpointText.insert('end', '$TEXT\t\tCode\t\tBreakpoint' + '\n')
        for i, item in enumerate(self.Coding):
            if(str(i+1) in self.Breakpoints):
                self.BreakpointText.insert('end', '0x' + ('%x' % (i*4)).rjust(8, '0') + '\t\t')
                self.BreakpointText.insert('end', ' '.join(item) + '\t\t')
                self.BreakpointText.insert('end', 'BP' + '\n')
        # StatisticsText
        self.StatisticsText.delete('1.0', 'end')
        self.StatisticsText.insert("end", 'StatisticsText\n', "center")
        ## Total
        temp_num00 = self.HitNum['0']
        temp_num01 = self.NotHitNum['0']
        temp_num10 = self.HitNum['1']
        temp_num11 = self.NotHitNum['1']
        temp_num20 = self.ReplaceNum['0']
        temp_num21 = self.ReplaceNum['1']
        self.StatisticsText.insert('end', 'Total:' + '\n')
        self.StatisticsText.insert('end', '\t' + str(temp_num00+temp_num01+temp_num10+temp_num11)+' Cycle(s) executed.' + '\n\n')
        ## Load/Store Instructions
        self.StatisticsText.insert('end', 'Load/Store Instructions:' + '\n')
        self.StatisticsText.insert('end', '\t' + 'Total:\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num00+temp_num01+temp_num10+temp_num11) + ' Load/Store Instructions' + '\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num00+temp_num10) + ' times to hit' + ' (' + str('%.2f' % (float((temp_num00+temp_num10)*100.0/(temp_num00+temp_num01+temp_num10+temp_num11)) if temp_num00+temp_num01+temp_num10+temp_num11 != 0 else 0.0)) + '%' + ' of all Load/Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num01+temp_num11) + ' times to not hit' + ' (' + str('%.2f' % (float((temp_num01+temp_num11)*100.0/(temp_num00+temp_num01+temp_num10+temp_num11)) if temp_num00+temp_num01+temp_num10+temp_num11 != 0 else 0.0)) + '%' + ' of all Load/Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t\t' + str(temp_num01+temp_num11-temp_num20-temp_num21) + ' times to insert' + ' (' + str('%.2f' % (float((temp_num01+temp_num11-temp_num20-temp_num21)*100.0/(temp_num01+temp_num11)) if temp_num01+temp_num11 != 0 else 0.0)) + '%' + ' of all NotHit Load/Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t\t' + str(temp_num20+temp_num21) + ' times to replace' + ' (' + str('%.2f' % (float((temp_num20+temp_num21)*100.0/(temp_num01+temp_num11)) if temp_num01+temp_num11 != 0 else 0.0)) + '%' + ' of all NotHit Load/Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t' + 'Loads:\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num00+temp_num01) + ' Load Instructions' + '\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num00) + ' times to hit' + ' (' + str('%.2f' % (float(temp_num00*100.0/(temp_num00+temp_num01)) if temp_num00+temp_num01 != 0 else 0.0)) + '%' + ' of all Load Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num01) + ' times to not hit' + ' (' + str('%.2f' % (float(temp_num01*100.0/(temp_num00+temp_num01)) if temp_num00+temp_num01 != 0 else 0.0)) + '%' + ' of all Load Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t\t' + str(temp_num01-temp_num20) + ' times to insert' + ' (' + str('%.2f' % (float((temp_num01-temp_num20)*100.0/(temp_num01)) if temp_num01 != 0 else 0.0)) + '%' + ' of all NotHit Load Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t\t' + str(temp_num20) + ' times to replace' + ' (' + str('%.2f' % (float((temp_num20)*100.0/(temp_num01)) if temp_num01 != 0 else 0.0)) + '%' + ' of all NotHit Load Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t' + 'Stores:\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num10+temp_num11) + ' Store Instructions' + '\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num10) + ' times to hit' + ' (' + str('%.2f' % (float(temp_num10*100.0/(temp_num10+temp_num11)) if temp_num10+temp_num11 != 0 else 0.0)) + '%' + ' of all Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t' + str(temp_num11) + ' times to not hit' + ' (' + str('%.2f' % (float(temp_num11*100.0/(temp_num10+temp_num11)) if temp_num10+temp_num11 != 0 else 0.0)) + '%' + ' of all Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t\t' + str(temp_num11-temp_num21) + ' times to insert' + ' (' + str('%.2f' % (float((temp_num11-temp_num21)*100.0/(temp_num11)) if temp_num11 != 0 else 0.0)) + '%' + ' of all NotHit Store Instructions).' + '\n')
        self.StatisticsText.insert('end', '\t\t\t' + str(temp_num21) + ' times to replace' + ' (' + str('%.2f' % (float((temp_num21)*100.0/(temp_num11)) if temp_num11 != 0 else 0.0)) + '%' + ' of all NotHit Store Instructions).' + '\n')

    def NextStep(self, showstate: bool = True) -> bool:
        if(self.endflag or self.Coding == []):
            return False
        self.time += 1
        self.DebugText.insert('end', 'Running For NextStep: ' + str(self.time) + '\n')
        if(len(self.Coding) > self.time):
            lists = self.Coding[self.time]
            CacheTag = int(lists[1], 16) // self.BlockSize
            CachePos = CacheTag % self.CacheNum
            if CacheTag in self.Cache[CachePos]:
                self.HitNum[lists[0]] += 1
                self.Cache[CachePos].remove(CacheTag)
                self.Cache[CachePos].append(CacheTag)
            else:
                self.NotHitNum[lists[0]] += 1
                if len(self.Cache[CachePos]) < self.Associativity:
                    self.Cache[CachePos].append(CacheTag)
                else:
                    self.ReplaceNum[lists[0]] += 1
                    self.Cache[CachePos].remove(self.Cache[CachePos][0])
                    self.Cache[CachePos].append(CacheTag)
        else:
            self.EndRunning()
        if showstate == True:
            self.ShowState(self.time)

        # Check Breakpoints
        for bindex in self.Breakpoints:
            if(self.time == int(bindex)-1):
                showinfo("Info", "Index: " + str(bindex) + ' have reached.')
                return False
        
        # # Print
        # self.DebugText.insert('end', 'Data: ' + '\n')
        # for item, num in self.Data.items():
        #     self.DebugText.insert('end', ' # '.join([item, str(num)]) + '\n')
        # self.DebugText.insert('end', 'Regs: ' + '\n')
        # for item, num in self.Regs.items():
        #     self.DebugText.insert('end', ' # '.join([item, str(num)]) + '\n')
        # self.DebugText.insert('end', 'TASKS: ' + '\n')
        # for itemnum, index, state in sorted(self.TASKS, key=lambda x:x[0]):
        #     self.DebugText.insert('end', ' # '.join([str(itemnum), str(index), state]) + '\n')
        return True

    def NextNStep(self):
        received = askinteger("Ask For NextNStep", "Num for Steps", initialvalue=1)
        if(isinstance(received, type(None))):
            return
        try:
            received = int(received)
        except:
            showerror("Error", "The Number is of Wrong Type!")
            return
        for i in range(received):
            if(self.NextStep(showstate=False) == False):
                self.ShowState(self.time)
                showinfo("Info", "Break NextNStep By BreakPoints or The program is Ended!")
                return
        self.ShowState(self.time)
        return

    def Back(self):
        now = self.time+1 if self.endflag==False else self.time
        self.reset_DLX()
        for i in range(now-1):
            self.NextStep(showstate=False)
        self.ShowState(self.time)

    def Run(self):
        if(self.Coding == []):
            showerror("Error", "Nothing Can be Run, Please Load Your File First!")
            return
        while(self.endflag == False):
            if(self.NextStep(showstate=False) == False):
                self.ShowState(self.time)
                showinfo("Info", "Break Run By BreakPoints or The program is Ended!")
                return
        self.ShowState(self.time)

    def RunTo(self):
        received = askstring("Ask For RunTo", "Index(1~n)", initialvalue='1')
        if(isinstance(received, type(None))):
            return
        try:
            received = received.split('-')
            if(len(received) != 1 or int(received[0]) < 1 or int(received[0]) > len(self.Coding)):
                showerror("Error", "The String is of Wrong Type!")
                return
            temp_flag = False
            while(self.endflag == False and temp_flag == False):
                if(self.NextStep(showstate=False) == False):
                    self.ShowState(self.time)
                    showinfo("Info", "Break RunTo By BreakPoints or The program is Ended!")
                    return
                if(self.time == int(received[0])-1):
                    temp_flag = True
                    break
            self.ShowState(self.time)
            if(temp_flag == True):
                showinfo("Info", "Index: " + str(received[0]) + ' have reached.')
            else:
                showerror("Error", "Something Wrong happened when Running!")
        except:
            showerror("Error", "Something Wrong happened when Running!")
        return

    def Set_Breakpoint(self):
        received = askstring("Ask For Set_Breakpoint", "Index(1~n)", initialvalue='1')
        if(isinstance(received, type(None))):
            return
        try:
            received = received.split('-')
            if(len(received) != 1 or int(received[0]) < 1 or int(received[0]) > len(self.Coding)):
                showerror("Error", "The String is of Wrong Type!")
                return
            if(received[0] not in self.Breakpoints):
                self.Breakpoints.append(received[0])
            self.ShowState(self.time)
        except:
            showerror("Error", "Something Wrong happened when Running!")
        return