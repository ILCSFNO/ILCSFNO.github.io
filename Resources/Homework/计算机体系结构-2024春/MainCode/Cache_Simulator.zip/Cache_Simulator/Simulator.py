from tkinter import *
from Codes import *

def MakeText(TextName):
    """Construct Just like:
    DebugTextFrame = Frame(root)
    DebugTextX = Scrollbar(DebugTextFrame, orient=HORIZONTAL)
    DebugTextY = Scrollbar(DebugTextFrame, orient=VERTICAL)
    DebugText = Text(DebugTextFrame, width=211, height=27, xscrollcommand=DebugTextX.set, yscrollcommand=DebugTextY.set, wrap='none')
    DebugTextX.pack(side=BOTTOM, fill=X)
    DebugTextX.config(command=DebugText.xview)
    DebugTextY.pack(side=RIGHT, fill=Y)
    DebugTextY.config(command=DebugText.yview)
    DebugText.tag_configure("center", justify='center', font=('黑体', 15))
    DebugText.insert("end", TextName + '\n', "center")
    DebugText.pack(fill=BOTH)
    DebugTextFrame.place(x=15, y=10, anchor='nw')
    """
    root, width, height, placex, placey, placeanchor = TextConfig[TextName]
    globals()[TextName+'Frame'] = Frame(root)
    globals()[TextName+'X'] = Scrollbar(globals()[TextName+'Frame'], orient=HORIZONTAL)
    globals()[TextName+'Y'] = Scrollbar(globals()[TextName+'Frame'], orient=VERTICAL)
    globals()[TextName] = Text(globals()[TextName+'Frame'], width=width, height=height, xscrollcommand=globals()[TextName+'X'].set, yscrollcommand=globals()[TextName+'Y'].set, wrap='none')
    globals()[TextName+'X'].pack(side=BOTTOM, fill=X)
    globals()[TextName+'X'].config(command=globals()[TextName].xview)
    globals()[TextName+'Y'].pack(side=RIGHT, fill=Y)
    globals()[TextName+'Y'].config(command=globals()[TextName].yview)
    globals()[TextName].tag_configure("center", justify='center', font=('黑体', 15))
    globals()[TextName].insert("end", TextName + '\n', "center")
    globals()[TextName].pack(fill=BOTH)
    globals()[TextName+'Frame'].place(x=placex, y=placey, anchor=placeanchor)

def HideText(TextName):
    globals()[TextName+'Frame'].place_forget()
    globals()[TextName].pack_forget()
    globals()[TextName+'Y'].pack_forget()
    globals()[TextName+'X'].pack_forget()
    
def ShowText(TextName):
    root, width, height, placex, placey, placeanchor = TextConfig[TextName]
    globals()[TextName+'X'].pack(side=BOTTOM, fill=X)
    globals()[TextName+'Y'].pack(side=RIGHT, fill=Y)
    globals()[TextName].pack(fill=BOTH)
    globals()[TextName+'Frame'].place(x=placex, y=placey, anchor=placeanchor)

class DEBUG():
    def __init__(self):
        self.UsingDebuging = BooleanVar(value=False)
    def ChangeDebuging(self):
        if(self.UsingDebuging.get() == True):
            HideText('StatisticsText')
            HideText('CacheText')
            ShowText('DebugText')
        else:
            ShowText('StatisticsText')
            ShowText('CacheText')
            HideText('DebugText')
    
# init
root = Tk()
codes = Codes(root)
debug = DEBUG()
# WindowSize + FullScreen
width, height = root.maxsize()
root.geometry("{}x{}+0+0".format(width, height))
root.resizable(0, 0)
root.state("zoomed")
# Title
root.title("Cache Simulator")

# Text
TextConfig = {
    # root, width, height, placex, placey, placeanchor
    'DebugText': (root, 211, 27, 15, 10, 'nw'),
    'StatisticsText': (root, 103, 27, 15, 10, 'nw'),
    'CacheText': (root, 103, 27, 770, 10, 'nw'),
    'ClockText': (root, 103, 27, 15, 400, 'nw'),
    'BreakpointText': (root, 103, 27, 770, 400, 'nw'),
}
MakeText('DebugText')
MakeText('StatisticsText')
MakeText('CacheText')
MakeText('ClockText')
MakeText('BreakpointText')

HideText('DebugText')

DebugText.insert('end', 'root.maxsize(): width=' + str(width) + ', height=' + str(height) + '\n')
# MenuBar
MenuBar = Menu(root)
# FileBar
FileBar = Menu(MenuBar, tearoff=0)
MenuBar.add_cascade(label='File', menu=FileBar)
FileBar.add_command(label='Load Code By File    Ctrl+O', command=lambda: codes.ReadCodeByFile(DebugText, StatisticsText, CacheText, ClockText, BreakpointText))
FileBar.add_command(label='Reset DLX                Ctrl+R', command=lambda: codes.reset_DLX())
FileBar.add_command(label='Reset All          Ctrl+Shift+R', command=lambda: codes.reset())
FileBar.add_command(label='Quit                Ctrl+Shift+Q', command=lambda: root.quit())
# OperateBar
OperateBar = Menu(MenuBar, tearoff=0)
MenuBar.add_cascade(label='Operate', menu=OperateBar)
OperateBar.add_command(label='Next Step               F7', command=lambda: codes.NextStep())
OperateBar.add_command(label='Next N Step           F8', command=lambda: codes.NextNStep())
OperateBar.add_command(label='Back                      F9', command=lambda: codes.Back())
OperateBar.add_command(label='Run                       F5', command=lambda: codes.Run())
OperateBar.add_command(label='Run To                  F6', command=lambda: codes.RunTo())
# CodeBar
CodeBar = Menu(MenuBar, tearoff=0)
MenuBar.add_cascade(label='Code', menu=CodeBar)
CodeBar.add_command(label='Set Breakpoint        Ctrl+B', command=lambda: codes.Set_Breakpoint())
CodeBar.add_checkbutton(label='Using Debug Mode', command=lambda: debug.ChangeDebuging(), variable=debug.UsingDebuging)
# ConfigBar
ConfigBar = Menu(MenuBar, tearoff=0)
MenuBar.add_cascade(label='Config', menu=ConfigBar)
## ConfigBar-CacheSizeBar
ConfigCacheSizeBar = Menu(ConfigBar, tearoff=0)
ConfigBar.add_cascade(label='CacheSize', menu=ConfigCacheSizeBar)
ConfigCacheSizeBar.add_checkbutton(label='8KB', command=lambda: codes.Set_CacheSize(8), variable=codes.GetCacheSize['8'])
ConfigCacheSizeBar.add_checkbutton(label='16KB', command=lambda: codes.Set_CacheSize(16), variable=codes.GetCacheSize['16'])
ConfigCacheSizeBar.add_checkbutton(label='32KB', command=lambda: codes.Set_CacheSize(32), variable=codes.GetCacheSize['32'])
ConfigCacheSizeBar.add_checkbutton(label='64KB', command=lambda: codes.Set_CacheSize(64), variable=codes.GetCacheSize['64'])
## ConfigBar-BlockSizeBar
ConfigBlockSizeBar = Menu(ConfigBar, tearoff=0)
ConfigBar.add_cascade(label='BlockSize', menu=ConfigBlockSizeBar)
ConfigBlockSizeBar.add_checkbutton(label='16B', command=lambda: codes.Set_BlockSize(16), variable=codes.GetBlockSize['16'])
ConfigBlockSizeBar.add_checkbutton(label='32B', command=lambda: codes.Set_BlockSize(32), variable=codes.GetBlockSize['32'])
ConfigBlockSizeBar.add_checkbutton(label='64B', command=lambda: codes.Set_BlockSize(64), variable=codes.GetBlockSize['64'])
ConfigBlockSizeBar.add_checkbutton(label='128B', command=lambda: codes.Set_BlockSize(128), variable=codes.GetBlockSize['128'])
## ConfigBar-BlockSizeBar
ConfigAssociativityBar = Menu(ConfigBar, tearoff=0)
ConfigBar.add_cascade(label='Associativity', menu=ConfigAssociativityBar)
ConfigAssociativityBar.add_checkbutton(label='1', command=lambda: codes.Set_Associativity(1), variable=codes.GetAssociativity['1'])
ConfigAssociativityBar.add_checkbutton(label='2', command=lambda: codes.Set_Associativity(2), variable=codes.GetAssociativity['2'])
ConfigAssociativityBar.add_checkbutton(label='4', command=lambda: codes.Set_Associativity(4), variable=codes.GetAssociativity['4'])
ConfigAssociativityBar.add_checkbutton(label='8', command=lambda: codes.Set_Associativity(8), variable=codes.GetAssociativity['8'])
# MenuBar-Config
root.config(menu=MenuBar)
# KeyBoard
root.bind("<Control-KeyPress-o>", lambda x: codes.ReadCodeByFile(DebugText, StatisticsText, CacheText, ClockText, BreakpointText))
root.bind("<Control-KeyPress-r>", lambda x: codes.reset_DLX())
root.bind("<Control-KeyPress-R>", lambda x: codes.reset())
root.bind("<Control-KeyPress-Q>", lambda x: root.quit())
root.bind("<Key-F7>", lambda x: codes.NextStep())
root.bind("<Key-F8>", lambda x: codes.NextNStep())
root.bind("<Key-F9>", lambda x: codes.Back())
root.bind("<Key-F5>", lambda x: codes.Run())
root.bind("<Key-F6>", lambda x: codes.RunTo())
root.bind("<Control-KeyPress-b>", lambda x: codes.Set_Breakpoint())

# Run
root.mainloop()